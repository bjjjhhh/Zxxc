.class public final Lcom/google/android/gms/common/Scopes;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static APP_STATE:Ljava/lang/String;

.field public static CLOUD_SAVE:Ljava/lang/String;

.field public static DRIVE_APPFOLDER:Ljava/lang/String;

.field public static DRIVE_APPS:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static DRIVE_FILE:Ljava/lang/String;

.field public static DRIVE_FULL:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static EMAIL:Ljava/lang/String;

.field public static GAMES:Ljava/lang/String;

.field public static GAMES_LITE:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static LEGACY_USERINFO_EMAIL:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static LEGACY_USERINFO_PROFILE:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static OPEN_ID:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static PLUS_LOGIN:Ljava/lang/String;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static PLUS_ME:Ljava/lang/String;

.field public static PROFILE:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "https://www.googleapis.com/auth/appstate"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->APP_STATE:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/datastoremobile"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->CLOUD_SAVE:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/drive.appdata"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->DRIVE_APPFOLDER:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/drive.apps"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->DRIVE_APPS:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/drive.file"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->DRIVE_FILE:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/drive"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->DRIVE_FULL:Ljava/lang/String;

    const-string v0, "email"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->EMAIL:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/games"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->GAMES:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/games_lite"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->GAMES_LITE:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/userinfo.email"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->LEGACY_USERINFO_EMAIL:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/userinfo.profile"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->LEGACY_USERINFO_PROFILE:Ljava/lang/String;

    const-string v0, "openid"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->OPEN_ID:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/plus.login"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->PLUS_LOGIN:Ljava/lang/String;

    const-string v0, "https://www.googleapis.com/auth/plus.me"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->PLUS_ME:Ljava/lang/String;

    const-string v0, "profile"

    sput-object v0, Lcom/google/android/gms/common/Scopes;->PROFILE:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
