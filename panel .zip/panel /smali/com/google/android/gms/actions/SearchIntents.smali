.class public Lcom/google/android/gms/actions/SearchIntents;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static ACTION_SEARCH:Ljava/lang/String;

.field public static EXTRA_QUERY:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "com.google.android.gms.actions.SEARCH_ACTION"

    sput-object v0, Lcom/google/android/gms/actions/SearchIntents;->ACTION_SEARCH:Ljava/lang/String;

    const-string v0, "query"

    sput-object v0, Lcom/google/android/gms/actions/SearchIntents;->EXTRA_QUERY:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
