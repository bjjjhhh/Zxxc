.class public Lcom/google/android/gms/actions/NoteIntents;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static ACTION_APPEND_NOTE:Ljava/lang/String;

.field public static ACTION_CREATE_NOTE:Ljava/lang/String;

.field public static ACTION_DELETE_NOTE:Ljava/lang/String;

.field public static EXTRA_NAME:Ljava/lang/String;

.field public static EXTRA_NOTE_QUERY:Ljava/lang/String;

.field public static EXTRA_TEXT:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "com.google.android.gms.actions.APPEND_NOTE"

    sput-object v0, Lcom/google/android/gms/actions/NoteIntents;->ACTION_APPEND_NOTE:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.CREATE_NOTE"

    sput-object v0, Lcom/google/android/gms/actions/NoteIntents;->ACTION_CREATE_NOTE:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.DELETE_NOTE"

    sput-object v0, Lcom/google/android/gms/actions/NoteIntents;->ACTION_DELETE_NOTE:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.extra.NAME"

    sput-object v0, Lcom/google/android/gms/actions/NoteIntents;->EXTRA_NAME:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.extra.NOTE_QUERY"

    sput-object v0, Lcom/google/android/gms/actions/NoteIntents;->EXTRA_NOTE_QUERY:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.extra.TEXT"

    sput-object v0, Lcom/google/android/gms/actions/NoteIntents;->EXTRA_TEXT:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
