.class public Lcom/google/android/gms/actions/ItemListIntents;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static ACTION_ACCEPT_ITEM:Ljava/lang/String;

.field public static ACTION_APPEND_ITEM_LIST:Ljava/lang/String;

.field public static ACTION_CREATE_ITEM_LIST:Ljava/lang/String;

.field public static ACTION_DELETE_ITEM:Ljava/lang/String;

.field public static ACTION_DELETE_ITEM_LIST:Ljava/lang/String;

.field public static ACTION_REJECT_ITEM:Ljava/lang/String;

.field public static EXTRA_ITEM_NAME:Ljava/lang/String;

.field public static EXTRA_ITEM_NAMES:Ljava/lang/String;

.field public static EXTRA_ITEM_QUERY:Ljava/lang/String;

.field public static EXTRA_LIST_NAME:Ljava/lang/String;

.field public static EXTRA_LIST_QUERY:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "com.google.android.gms.actions.ACCEPT_ITEM"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->ACTION_ACCEPT_ITEM:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.APPEND_ITEM_LIST"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->ACTION_APPEND_ITEM_LIST:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.CREATE_ITEM_LIST"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->ACTION_CREATE_ITEM_LIST:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.DELETE_ITEM"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->ACTION_DELETE_ITEM:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.DELETE_ITEM_LIST"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->ACTION_DELETE_ITEM_LIST:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.REJECT_ITEM"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->ACTION_REJECT_ITEM:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.extra.ITEM_NAME"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->EXTRA_ITEM_NAME:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.extra.ITEM_NAMES"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->EXTRA_ITEM_NAMES:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.extra.ITEM_QUERY"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->EXTRA_ITEM_QUERY:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.extra.LIST_NAME"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->EXTRA_LIST_NAME:Ljava/lang/String;

    const-string v0, "com.google.android.gms.actions.extra.LIST_QUERY"

    sput-object v0, Lcom/google/android/gms/actions/ItemListIntents;->EXTRA_LIST_QUERY:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
