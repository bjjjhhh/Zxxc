.class public Lcom/google/android/gms/actions/ReserveIntents;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static ACTION_RESERVE_TAXI_RESERVATION:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "com.google.android.gms.actions.RESERVE_TAXI_RESERVATION"

    sput-object v0, Lcom/google/android/gms/actions/ReserveIntents;->ACTION_RESERVE_TAXI_RESERVATION:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
