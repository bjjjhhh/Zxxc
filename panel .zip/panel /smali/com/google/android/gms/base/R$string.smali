.class public final Lcom/google/android/gms/base/R$string;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/base/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static common_google_play_services_enable_button:I = 0x7f100028

.field public static common_google_play_services_enable_text:I = 0x7f100029

.field public static common_google_play_services_enable_title:I = 0x7f10002a

.field public static common_google_play_services_install_button:I = 0x7f10002b

.field public static common_google_play_services_install_text:I = 0x7f10002c

.field public static common_google_play_services_install_title:I = 0x7f10002d

.field public static common_google_play_services_notification_channel_name:I = 0x7f10002e

.field public static common_google_play_services_notification_ticker:I = 0x7f10002f

.field public static common_google_play_services_unsupported_text:I = 0x7f100031

.field public static common_google_play_services_update_button:I = 0x7f100032

.field public static common_google_play_services_update_text:I = 0x7f100033

.field public static common_google_play_services_update_title:I = 0x7f100034

.field public static common_google_play_services_updating_text:I = 0x7f100035

.field public static common_google_play_services_wear_update_text:I = 0x7f100036

.field public static common_open_on_phone:I = 0x7f100037

.field public static common_signin_button_text:I = 0x7f100038

.field public static common_signin_button_text_long:I = 0x7f100039


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
