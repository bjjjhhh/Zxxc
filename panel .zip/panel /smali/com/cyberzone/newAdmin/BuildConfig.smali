.class public final Lcom/cyberzone/newAdmin/BuildConfig;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static APPLICATION_ID:Ljava/lang/String; = null

.field public static BUILD_TYPE:Ljava/lang/String; = null

.field public static final DEBUG:Z = false

.field public static ENCRYPTED_SERVER_KEY:Ljava/lang/String; = null

.field public static ORIG_API_KEY:Ljava/lang/String; = null

.field public static ORIG_APP_ID:Ljava/lang/String; = null

.field public static ORIG_DB_URL:Ljava/lang/String; = null

.field public static ORIG_PROJECT_ID:Ljava/lang/String; = null

.field public static ORIG_STORAGE_BUCKET:Ljava/lang/String; = null

.field public static final VERSION_CODE:I = 0x1

.field public static VERSION_NAME:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const-string v0, "ScKit-8baeb0b0e263f98242e1d44da535fbff73a96c2486e8cb9e10a4208db05158b2"

    const-string v2, "ScKit-693184bc54a93880"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->APPLICATION_ID:Ljava/lang/String;

    const-string v0, "ScKit-b8c3909fbb516aae11d0c8464b3da1f3"

    const-string v2, "ScKit-db29aab90f5f8b3c"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->BUILD_TYPE:Ljava/lang/String;

    const-string v0, "ScKit-e1436da7a7f0f2092e4fe198f99765530fce6cb504d06ea7ee451021ebbd2b6a"

    const-string v2, "ScKit-db29aab90f5f8b3c"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->ENCRYPTED_SERVER_KEY:Ljava/lang/String;

    const-string v0, "ScKit-cbc42b016e6694c05ad772b2a87d1d0537fbd845db0b8082cce187e059cdc6c3814017f4d2046e74f8d76d2a3870fc0d"

    const-string v2, "ScKit-db29aab90f5f8b3c"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->ORIG_API_KEY:Ljava/lang/String;

    const-string v0, "ScKit-1a7aa8c4a89e987d3e9e522e6a7e8c1fe6f8028fb91429e2d3e736ddd2ad8342efa9f0c6918d733316c11f151ef54896"

    const-string v2, "ScKit-db29aab90f5f8b3c"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->ORIG_APP_ID:Ljava/lang/String;

    const-string v0, "ScKit-1a02543f11cdaf453e8875deba9e52bab3d5465c0929be0e2f72cd79f2890d5f0bf035312354914ad367617598614765b5061be6e0478c8cd2e12884a38c6a35"

    const-string v2, "ScKit-db29aab90f5f8b3c"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->ORIG_DB_URL:Ljava/lang/String;

    const-string v0, "ScKit-e1b6dea6f73c47c578aea6c02b04faea"

    const-string v2, "ScKit-db29aab90f5f8b3c"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->ORIG_PROJECT_ID:Ljava/lang/String;

    const-string v0, "ScKit-1766fc202b9c3c20974483e2c14f32b5fa969180de43b6e3f9063f863bd718d60159bc80ece946fbbfdaaebb48e80db2"

    const-string v2, "ScKit-db29aab90f5f8b3c"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->ORIG_STORAGE_BUCKET:Ljava/lang/String;

    const-string v0, "ScKit-f5d01751a8a4385131b8825df220d903"

    const-string v2, "ScKit-db29aab90f5f8b3c"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/BuildConfig;->VERSION_NAME:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method
