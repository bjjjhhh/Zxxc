.class public final Lcom/cyberzone/newAdmin/R$layout;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static activity_app_spread:I = 0x7f0b001c

.field public static activity_card_details:I = 0x7f0b001d

.field public static activity_main:I = 0x7f0b001e

.field public static admin_login:I = 0x7f0b001f

.field public static agreement:I = 0x7f0b0020

.field public static card_item:I = 0x7f0b0021

.field public static client_adopter:I = 0x7f0b0022

.field public static details:I = 0x7f0b0033

.field public static forwarding_system:I = 0x7f0b0034

.field public static sms_adaptor:I = 0x7f0b0071


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
