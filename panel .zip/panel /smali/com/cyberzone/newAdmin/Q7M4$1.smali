.class Lcom/cyberzone/newAdmin/Q7M4$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljavax/net/ssl/X509TrustManager;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cyberzone/newAdmin/Q7M4;->createPinnedSSLSocketFactory()Ljavax/net/ssl/SSLSocketFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method


# virtual methods
.method public checkClientTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;)V
    .locals 6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    return-void
.end method

.method public checkServerTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;)V
    .locals 6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    .line 1
    if-eqz v1, :cond_2

    .line 2
    .line 3
    array-length v2, v1

    .line 4
    if-eqz v2, :cond_2

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aget-object v1, v1, v2

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/security/cert/X509Certificate;->getIssuerDN()Ljava/security/Principal;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-interface {v1}, Ljava/security/Principal;->toString()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v2, "ScKit-7749e8a98b58caf157e8ddafa300385e"

    .line 22
    const-string v4, "ScKit-4fb715d38d21a505"

    move-object/from16 v3, v2

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 23
    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    if-nez v2, :cond_1

    .line 28
    .line 29
    const-string v2, "ScKit-3ac06b74eb74dc3248211fe6c8374c2e"

    .line 30
    const-string v4, "ScKit-4fb715d38d21a505"

    move-object/from16 v3, v2

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 31
    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    if-nez v2, :cond_1

    .line 36
    .line 37
    const-string v2, "ScKit-be19a724479ca335ac551e75b45c83a7"

    .line 38
    const-string v4, "ScKit-4fb715d38d21a505"

    move-object/from16 v3, v2

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 39
    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_0

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    new-instance v1, Ljava/security/cert/CertificateException;

    .line 47
    .line 48
    const-string v2, "ScKit-96a7bc5222af49be7839334f566c686d4b3ca8b85f4505cc9bcef1414d6c497f"

    .line 49
    const-string v4, "ScKit-4fb715d38d21a505"

    move-object/from16 v3, v2

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 50
    invoke-direct {v1, v2}, Ljava/security/cert/CertificateException;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    throw v1

    .line 54
    :cond_1
    :goto_0
    return-void

    .line 55
    :cond_2
    new-instance v1, Ljava/security/cert/CertificateException;

    .line 56
    .line 57
    const-string v2, "ScKit-e863b2b1a5a32d859b0e61b675c5d318"

    .line 58
    const-string v4, "ScKit-4fb715d38d21a505"

    move-object/from16 v3, v2

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 59
    invoke-direct {v1, v2}, Ljava/security/cert/CertificateException;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    throw v1
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method public getAcceptedIssuers()[Ljava/security/cert/X509Certificate;
    .locals 5

    move-object/from16 v1, p0

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Ljava/security/cert/X509Certificate;

    .line 3
    .line 4
    return-object v0
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method
