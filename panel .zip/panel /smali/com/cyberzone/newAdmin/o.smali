.class public final synthetic Lcom/cyberzone/newAdmin/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/cyberzone/newAdmin/MainActivity$2;

.field public final synthetic b:F

.field public final synthetic c:F


# direct methods
.method public synthetic constructor <init>(Lcom/cyberzone/newAdmin/MainActivity$2;FF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/cyberzone/newAdmin/o;->a:Lcom/cyberzone/newAdmin/MainActivity$2;

    iput p2, p0, Lcom/cyberzone/newAdmin/o;->b:F

    iput p3, p0, Lcom/cyberzone/newAdmin/o;->c:F

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget v0, p0, Lcom/cyberzone/newAdmin/o;->c:F

    iget-object v1, p0, Lcom/cyberzone/newAdmin/o;->a:Lcom/cyberzone/newAdmin/MainActivity$2;

    iget v2, p0, Lcom/cyberzone/newAdmin/o;->b:F

    invoke-static {v1, v2, v0}, Lcom/cyberzone/newAdmin/MainActivity$2;->a(Lcom/cyberzone/newAdmin/MainActivity$2;FF)V

    return-void
.end method
