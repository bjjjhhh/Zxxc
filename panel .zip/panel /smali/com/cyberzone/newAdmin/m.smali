.class public final synthetic Lcom/cyberzone/newAdmin/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/tasks/OnCompleteListener;


# instance fields
.field public final synthetic a:Lcom/cyberzone/newAdmin/DetailsActivity$17;

.field public final synthetic b:J


# direct methods
.method public synthetic constructor <init>(Lcom/cyberzone/newAdmin/DetailsActivity$17;J)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/cyberzone/newAdmin/m;->a:Lcom/cyberzone/newAdmin/DetailsActivity$17;

    iput-wide p2, p0, Lcom/cyberzone/newAdmin/m;->b:J

    return-void
.end method


# virtual methods
.method public final onComplete(Lcom/google/android/gms/tasks/Task;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/cyberzone/newAdmin/m;->a:Lcom/cyberzone/newAdmin/DetailsActivity$17;

    iget-wide v1, p0, Lcom/cyberzone/newAdmin/m;->b:J

    invoke-static {v0, v1, v2, p1}, Lcom/cyberzone/newAdmin/DetailsActivity$17;->a(Lcom/cyberzone/newAdmin/DetailsActivity$17;JLcom/google/android/gms/tasks/Task;)V

    return-void
.end method
