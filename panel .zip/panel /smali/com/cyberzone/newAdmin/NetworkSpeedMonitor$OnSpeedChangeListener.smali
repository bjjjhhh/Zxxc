.class public interface abstract Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$OnSpeedChangeListener;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnSpeedChangeListener"
.end annotation


# virtual methods
.method public abstract onSpeedChange(FF)V
.end method
