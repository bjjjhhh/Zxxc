.class Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/DetailsActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BankBalanceInfo"
.end annotation


# instance fields
.field balance:D

.field bankFullName:Ljava/lang/String;

.field bankShortName:Ljava/lang/String;

.field dateTime:Ljava/lang/String;

.field fullMessage:Ljava/lang/String;

.field sender:Ljava/lang/String;


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;-><init>()V

    return-void
.end method
