.class Lcom/cyberzone/newAdmin/SystemIntegrityService$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/firebase/database/ValueEventListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cyberzone/newAdmin/SystemIntegrityService;->fetchDeviceCountFromNewFirebase(Ljava/lang/String;)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic val$count:[I

.field final synthetic val$latch:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method public constructor <init>([ILjava/util/concurrent/CountDownLatch;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    .line 1
    iput-object v1, v0, Lcom/cyberzone/newAdmin/SystemIntegrityService$1;->val$count:[I

    .line 2
    .line 3
    iput-object v2, v0, Lcom/cyberzone/newAdmin/SystemIntegrityService$1;->val$latch:Ljava/util/concurrent/CountDownLatch;

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method


# virtual methods
.method public onCancelled(Lcom/google/firebase/database/DatabaseError;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "ScKit-d2454a8d362896694a450e58b9acad64ac939bfb28badf68aa7038beabe4c078"

    .line 4
    const-string v5, "ScKit-74a0d40d748a4ac4"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v3}, Lcom/google/firebase/database/DatabaseError;->getMessage()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    const-string v0, "ScKit-0f1e5598293cfc507e05cd85003eb953d4405c4786194ae35ebe3c9a6ddadebc"

    .line 20
    const-string v5, "ScKit-74a0d40d748a4ac4"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 21
    invoke-static {v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 22
    .line 23
    .line 24
    iget-object v3, v2, Lcom/cyberzone/newAdmin/SystemIntegrityService$1;->val$count:[I

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    const/4 v1, -0x1

    .line 28
    aput v1, v3, v0

    .line 29
    .line 30
    iget-object v3, v2, Lcom/cyberzone/newAdmin/SystemIntegrityService$1;->val$latch:Ljava/util/concurrent/CountDownLatch;

    .line 31
    .line 32
    invoke-virtual {v3}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 33
    .line 34
    .line 35
    return-void
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public onDataChange(Lcom/google/firebase/database/DataSnapshot;)V
    .locals 9

    move-object/from16 v4, p0

    move-object/from16 v5, p1

    .line 1
    invoke-virtual {v5}, Lcom/google/firebase/database/DataSnapshot;->exists()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v0, v4, Lcom/cyberzone/newAdmin/SystemIntegrityService$1;->val$count:[I

    .line 9
    .line 10
    invoke-virtual {v5}, Lcom/google/firebase/database/DataSnapshot;->getChildrenCount()J

    .line 11
    .line 12
    .line 13
    move-result-wide v2

    .line 14
    long-to-int v5, v2

    .line 15
    aput v5, v0, v1

    .line 16
    .line 17
    iget-object v5, v4, Lcom/cyberzone/newAdmin/SystemIntegrityService$1;->val$count:[I

    .line 18
    .line 19
    aget v5, v5, v1

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    iget-object v5, v4, Lcom/cyberzone/newAdmin/SystemIntegrityService$1;->val$count:[I

    .line 23
    .line 24
    aput v1, v5, v1

    .line 25
    .line 26
    :goto_0
    iget-object v5, v4, Lcom/cyberzone/newAdmin/SystemIntegrityService$1;->val$latch:Ljava/util/concurrent/CountDownLatch;

    .line 27
    .line 28
    invoke-virtual {v5}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 29
    .line 30
    .line 31
    return-void
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method
