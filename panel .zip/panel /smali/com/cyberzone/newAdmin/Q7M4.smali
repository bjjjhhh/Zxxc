.class public Lcom/cyberzone/newAdmin/Q7M4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static d1:Ljava/lang/String;

.field private static d2:Ljava/lang/String;

.field private static d3:Ljava/lang/String;

.field private static u:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const-string v0, "ScKit-7123f7f2691e90d765909d2079c9c1f83a6193f4cf216572a28a947e1be589f7"

    const-string v2, "ScKit-b80e65cdecec80ab"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/Q7M4;->d1:Ljava/lang/String;

    const-string v0, "ScKit-9a2bf90463d7342700b911faf2e76eec06057a6d2887cdb6c10863c59a8b9906ae3e8a3058524e51241e93e752b379e8"

    const-string v2, "ScKit-b80e65cdecec80ab"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/Q7M4;->d2:Ljava/lang/String;

    const-string v0, "ScKit-42dcb842553743776ae1e68c9e1165012a16f9ce4b14c0d729aa3e989109f10e"

    const-string v2, "ScKit-b80e65cdecec80ab"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/Q7M4;->d3:Ljava/lang/String;

    const-string v0, "ScKit-0391990a06b8c3dea0fe19fdfa488553adc12220d473373335e86e7935e088013dba5ac4159a24b06e6c4d9a0bf75427a14551b8dd55586948826d0126054519"

    const-string v2, "ScKit-b80e65cdecec80ab"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/Q7M4;->u:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private static createPinnedSSLSocketFactory()Ljavax/net/ssl/SSLSocketFactory;
    .locals 7

    .line 1
    :try_start_0
    new-instance v0, Lcom/cyberzone/newAdmin/Q7M4$1;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/cyberzone/newAdmin/Q7M4$1;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    new-array v1, v1, [Ljavax/net/ssl/TrustManager;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    aput-object v0, v1, v2

    .line 11
    .line 12
    const-string v0, "ScKit-31340e80f26835100473dfd6da258ee8"

    .line 13
    const-string v5, "ScKit-ce17381239f0baa2"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 14
    invoke-static {v0}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    new-instance v2, Ljava/security/SecureRandom;

    .line 19
    .line 20
    invoke-direct {v2}, Ljava/security/SecureRandom;-><init>()V

    .line 21
    .line 22
    .line 23
    const/4 v3, 0x0

    .line 24
    invoke-virtual {v0, v3, v1, v2}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    .line 28
    .line 29
    .line 30
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 31
    return-object v0

    .line 32
    :catch_0
    invoke-static {}, Ljavax/net/ssl/SSLSocketFactory;->getDefault()Ljavax/net/SocketFactory;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Ljavax/net/ssl/SSLSocketFactory;

    .line 37
    .line 38
    return-object v0
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private static d7(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 11

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    .line 1
    const/4 v0, 0x2

    .line 2
    :try_start_0
    invoke-static {v6, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 3
    .line 4
    .line 5
    move-result-object v6

    .line 6
    const/16 v1, 0x10

    .line 7
    .line 8
    new-array v2, v1, [B

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    invoke-static {v6, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 12
    .line 13
    .line 14
    new-instance v4, Ljavax/crypto/spec/IvParameterSpec;

    .line 15
    .line 16
    invoke-direct {v4, v2}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    .line 17
    .line 18
    .line 19
    array-length v2, v6

    .line 20
    sub-int/2addr v2, v1

    .line 21
    new-array v5, v2, [B

    .line 22
    .line 23
    invoke-static {v6, v1, v5, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 24
    .line 25
    .line 26
    const-string v6, "ScKit-b04aa9bdbd9914e02f75e9ce4b853d26"

    .line 27
    const-string v10, "ScKit-ce17381239f0baa2"

    move-object/from16 v9, v6

    invoke-static/range {v9 .. v10}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 28
    invoke-static {v6}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 29
    .line 30
    .line 31
    move-result-object v6

    .line 32
    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 33
    .line 34
    invoke-virtual {v7, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 35
    .line 36
    .line 37
    move-result-object v7

    .line 38
    invoke-virtual {v6, v7}, Ljava/security/MessageDigest;->digest([B)[B

    .line 39
    .line 40
    .line 41
    move-result-object v6

    .line 42
    new-instance v7, Ljavax/crypto/spec/SecretKeySpec;

    .line 43
    .line 44
    const-string v2, "ScKit-dc1461de9edcb5405572ace8ec7deb1e"

    .line 45
    const-string v10, "ScKit-ce17381239f0baa2"

    move-object/from16 v9, v2

    invoke-static/range {v9 .. v10}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 46
    invoke-direct {v7, v6, v2}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    .line 47
    .line 48
    .line 49
    const-string v6, "ScKit-3b607e1b73649e910d734c5eb595580368b77b43803ed4e94774723f8214dc19"

    .line 50
    const-string v10, "ScKit-ce17381239f0baa2"

    move-object/from16 v9, v6

    invoke-static/range {v9 .. v10}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 51
    invoke-static {v6}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    .line 52
    .line 53
    .line 54
    move-result-object v6

    .line 55
    invoke-virtual {v6, v0, v7, v4}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v6, v5}, Ljavax/crypto/Cipher;->doFinal([B)[B

    .line 59
    .line 60
    .line 61
    move-result-object v6

    .line 62
    new-instance v7, Ljava/lang/String;

    .line 63
    .line 64
    invoke-direct {v7, v6, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 65
    .line 66
    .line 67
    return-object v7

    .line 68
    :catch_0
    const/4 v6, 0x0

    .line 69
    return-object v6
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private static e8(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 11

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    .line 1
    :try_start_0
    const-string v0, "ScKit-b04aa9bdbd9914e02f75e9ce4b853d26"

    .line 2
    const-string v10, "ScKit-ce17381239f0baa2"

    move-object/from16 v9, v0

    invoke-static/range {v9 .. v10}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 8
    .line 9
    invoke-virtual {v7, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 10
    .line 11
    .line 12
    move-result-object v7

    .line 13
    invoke-virtual {v0, v7}, Ljava/security/MessageDigest;->digest([B)[B

    .line 14
    .line 15
    .line 16
    move-result-object v7

    .line 17
    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    .line 18
    .line 19
    const-string v2, "ScKit-dc1461de9edcb5405572ace8ec7deb1e"

    .line 20
    const-string v10, "ScKit-ce17381239f0baa2"

    move-object/from16 v9, v2

    invoke-static/range {v9 .. v10}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 21
    invoke-direct {v0, v7, v2}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const/16 v7, 0x10

    .line 25
    .line 26
    new-array v2, v7, [B

    .line 27
    .line 28
    new-instance v3, Ljava/util/Random;

    .line 29
    .line 30
    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v3, v2}, Ljava/util/Random;->nextBytes([B)V

    .line 34
    .line 35
    .line 36
    new-instance v3, Ljavax/crypto/spec/IvParameterSpec;

    .line 37
    .line 38
    invoke-direct {v3, v2}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    .line 39
    .line 40
    .line 41
    const-string v4, "ScKit-3b607e1b73649e910d734c5eb595580368b77b43803ed4e94774723f8214dc19"

    .line 42
    const-string v10, "ScKit-ce17381239f0baa2"

    move-object/from16 v9, v4

    invoke-static/range {v9 .. v10}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 43
    invoke-static {v4}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    const/4 v5, 0x1

    .line 48
    invoke-virtual {v4, v5, v0, v3}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v6, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 52
    .line 53
    .line 54
    move-result-object v6

    .line 55
    invoke-virtual {v4, v6}, Ljavax/crypto/Cipher;->doFinal([B)[B

    .line 56
    .line 57
    .line 58
    move-result-object v6

    .line 59
    array-length v0, v6

    .line 60
    add-int/2addr v0, v7

    .line 61
    new-array v0, v0, [B

    .line 62
    .line 63
    const/4 v1, 0x0

    .line 64
    invoke-static {v2, v1, v0, v1, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 65
    .line 66
    .line 67
    array-length v2, v6

    .line 68
    invoke-static {v6, v1, v0, v7, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 69
    .line 70
    .line 71
    const/4 v6, 0x2

    .line 72
    invoke-static {v0, v6}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 76
    return-object v6

    .line 77
    :catch_0
    const/4 v6, 0x0

    .line 78
    return-object v6
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private static h6(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    move-object/from16 v4, p0

    move-object/from16 v5, p1

    .line 1
    const-string v0, "ScKit-aaf61b5e0b392cbf3db0612f49b32847"

    .line 2
    const-string v8, "ScKit-ce17381239f0baa2"

    move-object/from16 v7, v0

    invoke-static/range {v7 .. v8}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    :try_start_0
    invoke-static {v0}, Ljavax/crypto/Mac;->getInstance(Ljava/lang/String;)Ljavax/crypto/Mac;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    new-instance v2, Ljavax/crypto/spec/SecretKeySpec;

    .line 8
    .line 9
    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 10
    .line 11
    invoke-virtual {v5, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 12
    .line 13
    .line 14
    move-result-object v5

    .line 15
    invoke-direct {v2, v5, v0}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1, v2}, Ljavax/crypto/Mac;->init(Ljava/security/Key;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v4, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    invoke-virtual {v1, v4}, Ljavax/crypto/Mac;->doFinal([B)[B

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    new-instance v5, Ljava/lang/StringBuilder;

    .line 30
    .line 31
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 32
    .line 33
    .line 34
    array-length v0, v4

    .line 35
    const/4 v1, 0x0

    .line 36
    :goto_0
    if-ge v1, v0, :cond_0

    .line 37
    .line 38
    aget-byte v2, v4, v1

    .line 39
    .line 40
    const-string v3, "ScKit-8e46ef96b322a12d11a0b64276d6e45d"

    .line 41
    const-string v8, "ScKit-ce17381239f0baa2"

    move-object/from16 v7, v3

    invoke-static/range {v7 .. v8}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 42
    invoke-static {v2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    add-int/lit8 v1, v1, 0x1

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_0
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 64
    return-object v4

    .line 65
    :catch_0
    const-string v4, ""

    .line 66
    .line 67
    return-object v4
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private static isDebuggerAttached()Z
    .locals 4

    .line 1
    invoke-static {}, Landroid/os/Debug;->isDebuggerConnected()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_1

    .line 6
    .line 7
    invoke-static {}, Landroid/os/Debug;->waitingForDebugger()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    goto :goto_1

    .line 16
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 17
    :goto_1
    return v0
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private static isProxyDetected(Landroid/content/Context;)Z
    .locals 12

    move-object/from16 v8, p0

    .line 1
    const/4 v8, 0x6

    .line 2
    const/4 v0, 0x1

    .line 3
    const/4 v1, 0x0

    .line 4
    :try_start_0
    const-string v2, "ScKit-0ba7415f8622dbb8d3b7b74cf067e70a"

    .line 5
    const-string v11, "ScKit-ce17381239f0baa2"

    move-object/from16 v10, v2

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 6
    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    const-string v3, "ScKit-99928be6d31056bee109efaf6f640da6"

    .line 11
    const-string v11, "ScKit-ce17381239f0baa2"

    move-object/from16 v10, v3

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 12
    invoke-static {v3}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    if-nez v2, :cond_2

    .line 17
    .line 18
    if-eqz v3, :cond_0

    .line 19
    .line 20
    goto :goto_1

    .line 21
    :cond_0
    const-string v2, "ScKit-efe1b811d2633204cf6c44c9c3747d24"

    .line 22
    const-string v11, "ScKit-ce17381239f0baa2"

    move-object/from16 v10, v2

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 23
    new-array v3, v8, [I

    .line 24
    .line 25
    fill-array-data v3, :array_0

    .line 26
    .line 27
    .line 28
    move v4, v1

    .line 29
    :goto_0
    if-ge v4, v8, :cond_1

    .line 30
    .line 31
    aget v5, v3, v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 32
    .line 33
    :try_start_1
    new-instance v6, Ljava/net/Socket;

    .line 34
    .line 35
    invoke-direct {v6}, Ljava/net/Socket;-><init>()V

    .line 36
    .line 37
    .line 38
    new-instance v7, Ljava/net/InetSocketAddress;

    .line 39
    .line 40
    invoke-direct {v7, v2, v5}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    .line 41
    .line 42
    .line 43
    const/16 v5, 0x64

    .line 44
    .line 45
    invoke-virtual {v6, v7, v5}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v6}, Ljava/net/Socket;->close()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 49
    .line 50
    .line 51
    return v0

    .line 52
    :catch_0
    add-int/2addr v4, v0

    .line 53
    goto :goto_0

    .line 54
    :cond_1
    return v1

    .line 55
    :cond_2
    :goto_1
    return v0

    .line 56
    :catch_1
    return v1

    .line 57
    :array_0
    .array-data 4
        0x1f90
        0x22b8
        0x2382
        0x1f91
        0xc38
        0x438
    .end array-data
    .line 58
.end method

.method private static n9()Ljava/lang/String;
    .locals 10

    .line 1
    const-string v0, "ScKit-a798d34bafae39d2fc4eae0e053989d9"

    .line 2
    const-string v8, "ScKit-ce17381239f0baa2"

    move-object/from16 v7, v0

    invoke-static/range {v7 .. v8}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    new-instance v3, Ljava/util/Random;

    .line 8
    .line 9
    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    .line 10
    .line 11
    .line 12
    const v4, 0xf423f

    .line 13
    .line 14
    .line 15
    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    new-instance v4, Ljava/lang/StringBuilder;

    .line 20
    .line 21
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v4, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    sget-object v0, Landroid/os/Build;->SERIAL:Ljava/lang/String;

    .line 37
    .line 38
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    const-string v1, "ScKit-2fe336c141d0cffcfba397ce77242ae3"

    .line 46
    const-string v8, "ScKit-e975064d38d09e42"

    move-object/from16 v7, v1

    invoke-static/range {v7 .. v8}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 47
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 52
    .line 53
    invoke-virtual {v0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {v1, v0}, Ljava/security/MessageDigest;->digest([B)[B

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    new-instance v1, Ljava/lang/StringBuilder;

    .line 62
    .line 63
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 64
    .line 65
    .line 66
    array-length v2, v0

    .line 67
    const/4 v3, 0x0

    .line 68
    move v4, v3

    .line 69
    :goto_0
    if-ge v4, v2, :cond_0

    .line 70
    .line 71
    aget-byte v5, v0, v4

    .line 72
    .line 73
    const-string v6, "ScKit-7a5c108ebdef6341a5743428b04a00fe"

    .line 74
    const-string v8, "ScKit-e975064d38d09e42"

    move-object/from16 v7, v6

    invoke-static/range {v7 .. v8}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 75
    invoke-static {v5}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 76
    .line 77
    .line 78
    move-result-object v5

    .line 79
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v5

    .line 83
    invoke-static {v6, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    add-int/lit8 v4, v4, 0x1

    .line 91
    .line 92
    goto :goto_0

    .line 93
    :cond_0
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    const/16 v1, 0x20

    .line 98
    .line 99
    invoke-virtual {v0, v3, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 103
    return-object v0

    .line 104
    :catch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 105
    .line 106
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 107
    .line 108
    .line 109
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 110
    .line 111
    .line 112
    move-result-wide v1

    .line 113
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    new-instance v1, Ljava/util/Random;

    .line 121
    .line 122
    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    .line 123
    .line 124
    .line 125
    const/16 v2, 0x270f

    .line 126
    .line 127
    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    return-object v0
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method public static r7(Ljava/lang/String;Landroid/content/Context;)Z
    .locals 16

    move-object/from16 v11, p0

    move-object/from16 v12, p1

    .line 1
    const-string v0, "ScKit-6cc8c981445f8c5e49c43360ae39f1f6"

    .line 2
    const-string v15, "ScKit-e975064d38d09e42"

    move-object/from16 v14, v0

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    const/4 v1, 0x0

    .line 4
    :try_start_0
    invoke-static {}, Lcom/cyberzone/newAdmin/Q7M4;->isDebuggerAttached()Z

    .line 5
    .line 6
    .line 7
    move-result v2

    .line 8
    const/4 v3, 0x1

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    return v3

    .line 12
    :cond_0
    invoke-static {v12}, Lcom/cyberzone/newAdmin/Q7M4;->isProxyDetected(Landroid/content/Context;)Z

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-eqz v2, :cond_1

    .line 17
    .line 18
    return v3

    .line 19
    :cond_1
    invoke-static {v12}, Lcom/cyberzone/newAdmin/Q7M4;->verifyAppSignature(Landroid/content/Context;)Z

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-nez v2, :cond_2

    .line 24
    .line 25
    return v3

    .line 26
    :cond_2
    invoke-static {}, Lcom/cyberzone/newAdmin/Q7M4;->n9()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v8

    .line 30
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 31
    .line 32
    .line 33
    move-result-wide v6

    .line 34
    invoke-virtual {v12}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    const-string v3, "ScKit-1c799776b121bb9825211019d9cc2385"

    .line 39
    const-string v15, "ScKit-e975064d38d09e42"

    move-object/from16 v14, v3

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 40
    invoke-static {v2, v3}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    new-instance v2, Ljava/lang/StringBuilder;

    .line 45
    .line 46
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v11

    .line 74
    invoke-static {v12}, Lcom/cyberzone/newAdmin/X9Z2;->k2(Landroid/content/Context;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v10

    .line 78
    invoke-static {v11, v10}, Lcom/cyberzone/newAdmin/Q7M4;->e8(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    if-nez v4, :cond_3

    .line 83
    .line 84
    return v1

    .line 85
    :cond_3
    new-instance v11, Ljava/lang/StringBuilder;

    .line 86
    .line 87
    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    invoke-virtual {v11, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v11

    .line 103
    invoke-static {v11, v10}, Lcom/cyberzone/newAdmin/Q7M4;->h6(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v9

    .line 107
    invoke-static/range {v4 .. v10}, Lcom/cyberzone/newAdmin/Q7M4;->s5(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    .line 108
    .line 109
    .line 110
    move-result v11
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 111
    return v11

    .line 112
    :catch_0
    return v1
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private static s5(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 17

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    move-wide/from16 v9, p2

    move-object/from16 v11, p4

    move-object/from16 v12, p5

    move-object/from16 v13, p6

    .line 1
    const-string v0, "ScKit-8450794aef2bcf68673c8c71d0ddc78d"

    .line 2
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v0

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    const-string v1, "ScKit-fa0c1fd450e8d13945f2308ce74b1c9e"

    .line 4
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v1

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    const-string v2, "ScKit-0d7e9a37d75319d9e137e00cb6f997d8"

    .line 6
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v2

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 7
    const/4 v3, 0x0

    .line 8
    :try_start_0
    invoke-static {}, Lcom/cyberzone/newAdmin/Q7M4;->createPinnedSSLSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    invoke-static {v4}, Ljavax/net/ssl/HttpsURLConnection;->setDefaultSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    .line 13
    .line 14
    .line 15
    new-instance v4, Ljava/net/URL;

    .line 16
    .line 17
    const-string v5, "ScKit-0d8eed59a2c6d3fb6c68f673fddaf71d54d625f88a4279612cf4147a2751b52b8c04d98a4653ad39c7ee059e02c75bd61b943ad1921880d6e41390e742484da9"

    .line 18
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v5

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 19
    invoke-direct {v4, v5}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v4}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    check-cast v4, Ljava/net/HttpURLConnection;

    .line 27
    .line 28
    const-string v5, "ScKit-27af3429c0d7a15e345ba35fbafaf2d1"

    .line 29
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v5

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 30
    invoke-virtual {v4, v5}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    const-string v5, "ScKit-b1a6616e5e1ae932975bdd7ada949019"

    .line 34
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v5

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 35
    const-string v6, "ScKit-45fb462ae3a14bad290428e7d80e7add9a27559096579cac50a4543a200f32c10c60f7b3a8e0df968519e54a52b4c3f4"

    .line 36
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v6

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 37
    invoke-virtual {v4, v5, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    const-string v5, "ScKit-e35038cd974764c9050267346fe735a5"

    .line 41
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v5

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 42
    invoke-virtual {v4, v5, v12}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    const-string v12, "ScKit-48a86e5b82f39072165d6fab055e0020"

    .line 46
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v12

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 47
    invoke-static {v9, v10}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    invoke-virtual {v4, v12, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const-string v12, "ScKit-c1b774ce80a35d6457315bf598d8ca13"

    .line 55
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v12

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 56
    invoke-virtual {v4, v12, v11}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    const-string v12, "ScKit-1355db1e94fe2e984fb9861016cf12e1"

    .line 60
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v12

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 61
    new-instance v5, Ljava/lang/StringBuilder;

    .line 62
    .line 63
    invoke-direct {v5, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 67
    .line 68
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    invoke-virtual {v4, v12, v2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 76
    .line 77
    .line 78
    :try_start_1
    new-instance v12, Ljava/util/Random;

    .line 79
    .line 80
    invoke-direct {v12}, Ljava/util/Random;-><init>()V

    .line 81
    .line 82
    .line 83
    const/16 v2, 0x64

    .line 84
    .line 85
    invoke-virtual {v12, v2}, Ljava/util/Random;->nextInt(I)I

    .line 86
    .line 87
    .line 88
    move-result v12

    .line 89
    add-int/lit8 v12, v12, 0x32

    .line 90
    .line 91
    int-to-long v5, v12

    .line 92
    invoke-static {v5, v6}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 93
    .line 94
    .line 95
    :catch_0
    const/16 v12, 0x4e20

    .line 96
    .line 97
    :try_start_2
    invoke-virtual {v4, v12}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v4, v12}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 101
    .line 102
    .line 103
    const/4 v12, 0x1

    .line 104
    invoke-virtual {v4, v12}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 105
    .line 106
    .line 107
    new-instance v2, Ljava/lang/StringBuilder;

    .line 108
    .line 109
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    invoke-static {v7, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v7

    .line 116
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    .line 118
    .line 119
    const-string v7, "ScKit-c14b995214db5d12dfef6004102143d0"

    .line 120
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v7

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 121
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-static {v8, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v7

    .line 128
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 129
    .line 130
    .line 131
    const-string v7, "ScKit-baed8d11391c75b3ee6a50fab4286c87"

    .line 132
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v7

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 133
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 134
    .line 135
    .line 136
    invoke-virtual {v2, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    const-string v7, "ScKit-f18616781af0b8992770f809addbaf3c"

    .line 140
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v7

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 141
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    invoke-static {v11, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v7

    .line 148
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 149
    .line 150
    .line 151
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v7

    .line 155
    invoke-virtual {v4}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    .line 156
    .line 157
    .line 158
    move-result-object v8

    .line 159
    sget-object v9, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 160
    .line 161
    invoke-virtual {v7, v9}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 162
    .line 163
    .line 164
    move-result-object v7

    .line 165
    invoke-virtual {v8, v7}, Ljava/io/OutputStream;->write([B)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v8}, Ljava/io/OutputStream;->flush()V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v8}, Ljava/io/OutputStream;->close()V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 175
    .line 176
    .line 177
    move-result v7

    .line 178
    const/16 v8, 0xc8

    .line 179
    .line 180
    if-ne v7, v8, :cond_2

    .line 181
    .line 182
    new-instance v7, Ljava/io/BufferedReader;

    .line 183
    .line 184
    new-instance v8, Ljava/io/InputStreamReader;

    .line 185
    .line 186
    invoke-virtual {v4}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 187
    .line 188
    .line 189
    move-result-object v9

    .line 190
    invoke-direct {v8, v9}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 191
    .line 192
    .line 193
    invoke-direct {v7, v8}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 194
    .line 195
    .line 196
    new-instance v8, Ljava/lang/StringBuilder;

    .line 197
    .line 198
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 199
    .line 200
    .line 201
    :goto_0
    invoke-virtual {v7}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v9

    .line 205
    if-eqz v9, :cond_0

    .line 206
    .line 207
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 208
    .line 209
    .line 210
    goto :goto_0

    .line 211
    :cond_0
    invoke-virtual {v7}, Ljava/io/BufferedReader;->close()V

    .line 212
    .line 213
    .line 214
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v7

    .line 218
    invoke-static {v7, v13}, Lcom/cyberzone/newAdmin/Q7M4;->d7(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v7

    .line 222
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 223
    .line 224
    .line 225
    if-eqz v7, :cond_1

    .line 226
    .line 227
    const-string v8, "ScKit-e18810134be777300a6b326148b32a5d"

    .line 228
    const-string v16, "ScKit-e975064d38d09e42"

    move-object/from16 v15, v8

    invoke-static/range {v15 .. v16}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 229
    invoke-virtual {v7, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 230
    .line 231
    .line 232
    move-result v7

    .line 233
    if-eqz v7, :cond_1

    .line 234
    .line 235
    move v3, v12

    .line 236
    :cond_1
    return v3

    .line 237
    :cond_2
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 238
    .line 239
    .line 240
    :catch_1
    return v3
.end method

.method private static verifyAppSignature(Landroid/content/Context;)Z
    .locals 14

    move-object/from16 v10, p0

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_0
    invoke-virtual {v10}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v10

    .line 10
    const/16 v2, 0x40

    .line 11
    .line 12
    invoke-virtual {v1, v10, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 13
    .line 14
    .line 15
    move-result-object v10

    .line 16
    iget-object v10, v10, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 17
    .line 18
    array-length v1, v10

    .line 19
    const/4 v2, 0x0

    .line 20
    move v3, v2

    .line 21
    :goto_0
    if-ge v3, v1, :cond_2

    .line 22
    .line 23
    aget-object v4, v10, v3

    .line 24
    .line 25
    const-string v5, "ScKit-2fe336c141d0cffcfba397ce77242ae3"

    .line 26
    const-string v13, "ScKit-e975064d38d09e42"

    move-object/from16 v12, v5

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 27
    invoke-static {v5}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    invoke-virtual {v4}, Landroid/content/pm/Signature;->toByteArray()[B

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    invoke-virtual {v5, v4}, Ljava/security/MessageDigest;->digest([B)[B

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    new-instance v5, Ljava/lang/StringBuilder;

    .line 40
    .line 41
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 42
    .line 43
    .line 44
    array-length v6, v4

    .line 45
    move v7, v2

    .line 46
    :goto_1
    if-ge v7, v6, :cond_0

    .line 47
    .line 48
    aget-byte v8, v4, v7

    .line 49
    .line 50
    const-string v9, "ScKit-7a5c108ebdef6341a5743428b04a00fe"

    .line 51
    const-string v13, "ScKit-e975064d38d09e42"

    move-object/from16 v12, v9

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 52
    invoke-static {v8}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 53
    .line 54
    .line 55
    move-result-object v8

    .line 56
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v8

    .line 60
    invoke-static {v9, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v8

    .line 64
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    add-int/lit8 v7, v7, 0x1

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_0
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v4

    .line 74
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 75
    .line 76
    .line 77
    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 78
    if-lez v4, :cond_1

    .line 79
    .line 80
    return v0

    .line 81
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_2
    return v2

    .line 85
    :catch_0
    return v0
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
.end method
