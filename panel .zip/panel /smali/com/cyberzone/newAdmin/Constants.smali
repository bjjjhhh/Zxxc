.class public Lcom/cyberzone/newAdmin/Constants;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static DB_URL:Ljava/lang/String;

.field private static key:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const-string v0, "ScKit-4297dc89885a093a36c916ce9fb94ac347bf9dddb0ab9923da05b2891214b7e1"

    const-string v3, "ScKit-7836b6a0d002ab25"

    move-object/from16 v2, v0

    invoke-static/range {v2 .. v3}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/Constants;->key:Ljava/lang/String;

    .line 1
    const-string v0, "ScKit-4297dc89885a093a36c916ce9fb94ac347bf9dddb0ab9923da05b2891214b7e1"

    .line 2
    const-string v3, "ScKit-7836b6a0d002ab25"

    move-object/from16 v2, v0

    invoke-static/range {v2 .. v3}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    const-string v1, "ScKit-284952effbb6b12e1265b704179542f0d6f962135a9e24cf731ab2cdb3a7ebc337183ae49fbdece013012b6234daa996d4311e8ab4ef1e64d3202d9c6947d2b9ed1213ded48771ff18f4839efbace88b8668bd8a8b9df2229e90a24ed89d8ff7"

    .line 4
    const-string v3, "ScKit-7836b6a0d002ab25"

    move-object/from16 v2, v1

    invoke-static/range {v2 .. v3}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-static {v1, v0}, Lcom/cyberzone/newAdmin/CryptoUtil;->decrypt(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, Lcom/cyberzone/newAdmin/Constants;->DB_URL:Ljava/lang/String;

    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public constructor <init>()V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method
