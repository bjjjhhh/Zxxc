.class Lcom/cyberzone/newAdmin/DetailsActivity$14;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/firebase/database/ValueEventListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cyberzone/newAdmin/DetailsActivity;->loadDeviceData()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cyberzone/newAdmin/DetailsActivity;


# direct methods
.method public constructor <init>(Lcom/cyberzone/newAdmin/DetailsActivity;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public static synthetic a(Lcom/cyberzone/newAdmin/DetailsActivity$14;[Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/cyberzone/newAdmin/DetailsActivity$14;->lambda$onDataChange$1([Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic b(Lcom/cyberzone/newAdmin/DetailsActivity$14;Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/cyberzone/newAdmin/DetailsActivity$14;->lambda$onDataChange$0(Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic c(Lcom/cyberzone/newAdmin/DetailsActivity$14;[Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/cyberzone/newAdmin/DetailsActivity$14;->lambda$onDataChange$2([Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method private synthetic lambda$onDataChange$0(Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    .line 1
    iget-object p2, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 2
    .line 3
    invoke-static {p2, p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->v0(Lcom/cyberzone/newAdmin/DetailsActivity;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private synthetic lambda$onDataChange$1([Ljava/lang/String;Landroid/view/View;)V
    .locals 3

    .line 1
    const/4 p2, 0x0

    .line 2
    aget-object v0, p1, p2

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 11
    .line 12
    const-string v1, "clipboard"

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Landroid/content/ClipboardManager;

    .line 19
    .line 20
    const-string v1, "SIM1 Number"

    .line 21
    .line 22
    aget-object v2, p1, p2

    .line 23
    .line 24
    invoke-static {v1, v2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v0, v1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 32
    .line 33
    new-instance v1, Ljava/lang/StringBuilder;

    .line 34
    .line 35
    const-string v2, "\ud83d\udccb SIM1 number copied: "

    .line 36
    .line 37
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    aget-object p1, p1, p2

    .line 41
    .line 42
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-static {v0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_0
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 58
    .line 59
    const-string v0, "\u274c No SIM1 number available"

    .line 60
    .line 61
    invoke-static {p1, v0, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 66
    .line 67
    .line 68
    :goto_0
    return-void
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private synthetic lambda$onDataChange$2([Ljava/lang/String;Landroid/view/View;)V
    .locals 3

    .line 1
    const/4 p2, 0x0

    .line 2
    aget-object v0, p1, p2

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 11
    .line 12
    const-string v1, "clipboard"

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Landroid/content/ClipboardManager;

    .line 19
    .line 20
    const-string v1, "SIM2 Number"

    .line 21
    .line 22
    aget-object v2, p1, p2

    .line 23
    .line 24
    invoke-static {v1, v2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v0, v1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 32
    .line 33
    new-instance v1, Ljava/lang/StringBuilder;

    .line 34
    .line 35
    const-string v2, "\ud83d\udccb SIM2 number copied: "

    .line 36
    .line 37
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    aget-object p1, p1, p2

    .line 41
    .line 42
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-static {v0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_0
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 58
    .line 59
    const-string v0, "\u274c No SIM2 number available"

    .line 60
    .line 61
    invoke-static {p1, v0, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 66
    .line 67
    .line 68
    :goto_0
    return-void
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method


# virtual methods
.method public onCancelled(Lcom/google/firebase/database/DatabaseError;)V
    .locals 2

    .line 1
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 2
    .line 3
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->l0(Lcom/cyberzone/newAdmin/DetailsActivity;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 7
    .line 8
    const-string v0, "Failed to load device data"

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 16
    .line 17
    .line 18
    return-void
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public onDataChange(Lcom/google/firebase/database/DataSnapshot;)V
    .locals 11

    .line 1
    const-string v0, "joined"

    .line 2
    .line 3
    const-string v1, "modelName"

    .line 4
    .line 5
    const-string v2, "upipin"

    .line 6
    .line 7
    const-string v3, "label"

    .line 8
    .line 9
    const-string v4, "Date: "

    .line 10
    .line 11
    const-string v5, "Model: "

    .line 12
    .line 13
    const-string v6, "UPI Pin: "

    .line 14
    .line 15
    const-string v7, "Notes: "

    .line 16
    .line 17
    const-string v8, "Unexpected data type from Firebase for device: "

    .line 18
    .line 19
    const/4 v9, 0x0

    .line 20
    :try_start_0
    invoke-virtual {p1}, Lcom/google/firebase/database/DataSnapshot;->exists()Z

    .line 21
    .line 22
    .line 23
    move-result v10

    .line 24
    if-eqz v10, :cond_15

    .line 25
    .line 26
    invoke-virtual {p1}, Lcom/google/firebase/database/DataSnapshot;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    instance-of v10, p1, Ljava/util/Map;

    .line 31
    .line 32
    if-nez v10, :cond_0

    .line 33
    .line 34
    const-string p1, "DetailsActivity"

    .line 35
    .line 36
    new-instance v0, Ljava/lang/StringBuilder;

    .line 37
    .line 38
    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    iget-object v1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 42
    .line 43
    invoke-static {v1}, Lcom/cyberzone/newAdmin/DetailsActivity;->Q(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 58
    .line 59
    const-string v0, "Invalid device data format"

    .line 60
    .line 61
    invoke-static {p1, v0, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 66
    .line 67
    .line 68
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 69
    .line 70
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 71
    .line 72
    .line 73
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 74
    .line 75
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->l0(Lcom/cyberzone/newAdmin/DetailsActivity;)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :catchall_0
    move-exception p1

    .line 80
    goto/16 :goto_a

    .line 81
    .line 82
    :catch_0
    move-exception p1

    .line 83
    goto/16 :goto_8

    .line 84
    .line 85
    :cond_0
    :try_start_1
    iget-object v8, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 86
    .line 87
    check-cast p1, Ljava/util/Map;

    .line 88
    .line 89
    invoke-static {v8, p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->j0(Lcom/cyberzone/newAdmin/DetailsActivity;Ljava/util/Map;)V

    .line 90
    .line 91
    .line 92
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 93
    .line 94
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    if-eqz p1, :cond_16

    .line 99
    .line 100
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 101
    .line 102
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    invoke-interface {p1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 110
    const-string v8, ""

    .line 111
    .line 112
    if-eqz p1, :cond_1

    .line 113
    .line 114
    :try_start_2
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 115
    .line 116
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    invoke-interface {p1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 129
    .line 130
    .line 131
    move-result p1

    .line 132
    if-nez p1, :cond_1

    .line 133
    .line 134
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 135
    .line 136
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    invoke-interface {p1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    goto :goto_0

    .line 149
    :cond_1
    move-object p1, v8

    .line 150
    :goto_0
    iget-object v3, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 151
    .line 152
    invoke-static {v3}, Lcom/cyberzone/newAdmin/DetailsActivity;->Z(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 153
    .line 154
    .line 155
    move-result-object v3

    .line 156
    if-eqz v3, :cond_3

    .line 157
    .line 158
    iget-object v3, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 159
    .line 160
    invoke-static {v3}, Lcom/cyberzone/newAdmin/DetailsActivity;->Z(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 161
    .line 162
    .line 163
    move-result-object v3

    .line 164
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 165
    .line 166
    .line 167
    move-result v10

    .line 168
    if-eqz v10, :cond_2

    .line 169
    .line 170
    const-string v10, "Tap to add notes..."

    .line 171
    .line 172
    goto :goto_1

    .line 173
    :cond_2
    move-object v10, p1

    .line 174
    :goto_1
    invoke-virtual {v7, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v7

    .line 178
    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 179
    .line 180
    .line 181
    iget-object v3, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 182
    .line 183
    invoke-static {v3}, Lcom/cyberzone/newAdmin/DetailsActivity;->Z(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 184
    .line 185
    .line 186
    move-result-object v3

    .line 187
    new-instance v7, Lcom/cyberzone/newAdmin/i;

    .line 188
    .line 189
    const/4 v10, 0x1

    .line 190
    invoke-direct {v7, p0, v10, p1}, Lcom/cyberzone/newAdmin/i;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v3, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 194
    .line 195
    .line 196
    :cond_3
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 197
    .line 198
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->e0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 199
    .line 200
    .line 201
    move-result-object p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 202
    const-string v3, "N/A"

    .line 203
    .line 204
    if-eqz p1, :cond_5

    .line 205
    .line 206
    :try_start_3
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 207
    .line 208
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->e0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 209
    .line 210
    .line 211
    move-result-object p1

    .line 212
    new-instance v7, Ljava/lang/StringBuilder;

    .line 213
    .line 214
    invoke-direct {v7, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    iget-object v6, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 218
    .line 219
    invoke-static {v6}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 220
    .line 221
    .line 222
    move-result-object v6

    .line 223
    invoke-interface {v6, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v6

    .line 227
    if-eqz v6, :cond_4

    .line 228
    .line 229
    iget-object v6, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 230
    .line 231
    invoke-static {v6}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 232
    .line 233
    .line 234
    move-result-object v6

    .line 235
    invoke-interface {v6, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v6

    .line 239
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v6

    .line 243
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    .line 244
    .line 245
    .line 246
    move-result v6

    .line 247
    if-nez v6, :cond_4

    .line 248
    .line 249
    iget-object v6, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 250
    .line 251
    invoke-static {v6}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 252
    .line 253
    .line 254
    move-result-object v6

    .line 255
    invoke-interface {v6, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    move-result-object v2

    .line 259
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 260
    .line 261
    .line 262
    move-result-object v2

    .line 263
    goto :goto_2

    .line 264
    :cond_4
    move-object v2, v3

    .line 265
    :goto_2
    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 266
    .line 267
    .line 268
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 269
    .line 270
    .line 271
    move-result-object v2

    .line 272
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 273
    .line 274
    .line 275
    :cond_5
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 276
    .line 277
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->d0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 278
    .line 279
    .line 280
    move-result-object p1

    .line 281
    if-eqz p1, :cond_7

    .line 282
    .line 283
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 284
    .line 285
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->d0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 286
    .line 287
    .line 288
    move-result-object p1

    .line 289
    new-instance v2, Ljava/lang/StringBuilder;

    .line 290
    .line 291
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 292
    .line 293
    .line 294
    iget-object v5, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 295
    .line 296
    invoke-static {v5}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 297
    .line 298
    .line 299
    move-result-object v5

    .line 300
    invoke-interface {v5, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    move-result-object v5

    .line 304
    if-eqz v5, :cond_6

    .line 305
    .line 306
    iget-object v5, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 307
    .line 308
    invoke-static {v5}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 309
    .line 310
    .line 311
    move-result-object v5

    .line 312
    invoke-interface {v5, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 313
    .line 314
    .line 315
    move-result-object v5

    .line 316
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object v5

    .line 320
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    .line 321
    .line 322
    .line 323
    move-result v5

    .line 324
    if-nez v5, :cond_6

    .line 325
    .line 326
    iget-object v5, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 327
    .line 328
    invoke-static {v5}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 329
    .line 330
    .line 331
    move-result-object v5

    .line 332
    invoke-interface {v5, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 333
    .line 334
    .line 335
    move-result-object v1

    .line 336
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 337
    .line 338
    .line 339
    move-result-object v1

    .line 340
    goto :goto_3

    .line 341
    :cond_6
    move-object v1, v3

    .line 342
    :goto_3
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 343
    .line 344
    .line 345
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 346
    .line 347
    .line 348
    move-result-object v1

    .line 349
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 350
    .line 351
    .line 352
    :cond_7
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 353
    .line 354
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->a0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 355
    .line 356
    .line 357
    move-result-object p1

    .line 358
    if-eqz p1, :cond_9

    .line 359
    .line 360
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 361
    .line 362
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->a0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 363
    .line 364
    .line 365
    move-result-object p1

    .line 366
    new-instance v1, Ljava/lang/StringBuilder;

    .line 367
    .line 368
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 369
    .line 370
    .line 371
    iget-object v2, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 372
    .line 373
    invoke-static {v2}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 374
    .line 375
    .line 376
    move-result-object v2

    .line 377
    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v2

    .line 381
    if-eqz v2, :cond_8

    .line 382
    .line 383
    iget-object v2, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 384
    .line 385
    invoke-static {v2}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 386
    .line 387
    .line 388
    move-result-object v2

    .line 389
    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 390
    .line 391
    .line 392
    move-result-object v2

    .line 393
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 394
    .line 395
    .line 396
    move-result-object v2

    .line 397
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    .line 398
    .line 399
    .line 400
    move-result v2

    .line 401
    if-nez v2, :cond_8

    .line 402
    .line 403
    iget-object v2, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 404
    .line 405
    invoke-static {v2}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 406
    .line 407
    .line 408
    move-result-object v2

    .line 409
    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 414
    .line 415
    .line 416
    move-result-object v3

    .line 417
    :cond_8
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 418
    .line 419
    .line 420
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 421
    .line 422
    .line 423
    move-result-object v0

    .line 424
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 425
    .line 426
    .line 427
    :cond_9
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 428
    .line 429
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->P(Lcom/cyberzone/newAdmin/DetailsActivity;)Ljava/util/Map;

    .line 430
    .line 431
    .line 432
    move-result-object p1

    .line 433
    const-string v0, "sims"

    .line 434
    .line 435
    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 436
    .line 437
    .line 438
    move-result-object p1

    .line 439
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 440
    .line 441
    invoke-static {v0}, Lcom/cyberzone/newAdmin/DetailsActivity;->b0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 442
    .line 443
    .line 444
    move-result-object v0

    .line 445
    if-eqz v0, :cond_a

    .line 446
    .line 447
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 448
    .line 449
    invoke-static {v0}, Lcom/cyberzone/newAdmin/DetailsActivity;->b0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 450
    .line 451
    .line 452
    move-result-object v0

    .line 453
    const-string v1, "Sim1: Not Available"

    .line 454
    .line 455
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 456
    .line 457
    .line 458
    :cond_a
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 459
    .line 460
    invoke-static {v0}, Lcom/cyberzone/newAdmin/DetailsActivity;->c0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 461
    .line 462
    .line 463
    move-result-object v0

    .line 464
    if-eqz v0, :cond_b

    .line 465
    .line 466
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 467
    .line 468
    invoke-static {v0}, Lcom/cyberzone/newAdmin/DetailsActivity;->c0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 469
    .line 470
    .line 471
    move-result-object v0

    .line 472
    const-string v1, "Sim2: Not Available"

    .line 473
    .line 474
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 475
    .line 476
    .line 477
    :cond_b
    const/4 v0, 0x1

    .line 478
    new-array v1, v0, [Ljava/lang/String;

    .line 479
    .line 480
    aput-object v8, v1, v9

    .line 481
    .line 482
    new-array v2, v0, [Ljava/lang/String;

    .line 483
    .line 484
    aput-object v8, v2, v9

    .line 485
    .line 486
    instance-of v3, p1, Ljava/util/List;

    .line 487
    .line 488
    if-eqz v3, :cond_12

    .line 489
    .line 490
    check-cast p1, Ljava/util/List;

    .line 491
    .line 492
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 493
    .line 494
    .line 495
    move-result-object p1

    .line 496
    :cond_c
    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 497
    .line 498
    .line 499
    move-result v3

    .line 500
    if-eqz v3, :cond_12

    .line 501
    .line 502
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 503
    .line 504
    .line 505
    move-result-object v3

    .line 506
    instance-of v4, v3, Ljava/util/Map;

    .line 507
    .line 508
    if-eqz v4, :cond_c

    .line 509
    .line 510
    check-cast v3, Ljava/util/Map;

    .line 511
    .line 512
    const-string v4, "simSlotIndex"

    .line 513
    .line 514
    invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 515
    .line 516
    .line 517
    move-result-object v4

    .line 518
    const-string v5, "phoneNumber"

    .line 519
    .line 520
    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 521
    .line 522
    .line 523
    move-result-object v5

    .line 524
    const-string v6, "carrierName"

    .line 525
    .line 526
    invoke-interface {v3, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 527
    .line 528
    .line 529
    move-result-object v3

    .line 530
    instance-of v6, v4, Ljava/lang/Number;

    .line 531
    .line 532
    if-eqz v6, :cond_d

    .line 533
    .line 534
    check-cast v4, Ljava/lang/Number;

    .line 535
    .line 536
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 537
    .line 538
    .line 539
    move-result v4

    .line 540
    goto :goto_5

    .line 541
    :cond_d
    instance-of v6, v4, Ljava/lang/String;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 542
    .line 543
    const/4 v7, -0x1

    .line 544
    if-eqz v6, :cond_e

    .line 545
    .line 546
    :try_start_4
    check-cast v4, Ljava/lang/String;

    .line 547
    .line 548
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 549
    .line 550
    .line 551
    move-result v4
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 552
    goto :goto_5

    .line 553
    :catch_1
    :cond_e
    move v4, v7

    .line 554
    :goto_5
    const-string v6, "Unknown"

    .line 555
    .line 556
    if-eqz v5, :cond_f

    .line 557
    .line 558
    :try_start_5
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 559
    .line 560
    .line 561
    move-result-object v7

    .line 562
    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    .line 563
    .line 564
    .line 565
    move-result v7

    .line 566
    if-nez v7, :cond_f

    .line 567
    .line 568
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 569
    .line 570
    .line 571
    move-result-object v5

    .line 572
    goto :goto_6

    .line 573
    :cond_f
    move-object v5, v6

    .line 574
    :goto_6
    if-eqz v3, :cond_10

    .line 575
    .line 576
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 577
    .line 578
    .line 579
    move-result-object v7

    .line 580
    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    .line 581
    .line 582
    .line 583
    move-result v7

    .line 584
    if-nez v7, :cond_10

    .line 585
    .line 586
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 587
    .line 588
    .line 589
    move-result-object v6
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 590
    :cond_10
    const-string v3, " - "

    .line 591
    .line 592
    if-nez v4, :cond_11

    .line 593
    .line 594
    :try_start_6
    iget-object v7, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 595
    .line 596
    invoke-static {v7}, Lcom/cyberzone/newAdmin/DetailsActivity;->b0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 597
    .line 598
    .line 599
    move-result-object v7

    .line 600
    if-eqz v7, :cond_11

    .line 601
    .line 602
    iget-object v4, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 603
    .line 604
    invoke-static {v4}, Lcom/cyberzone/newAdmin/DetailsActivity;->b0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 605
    .line 606
    .line 607
    move-result-object v4

    .line 608
    new-instance v7, Ljava/lang/StringBuilder;

    .line 609
    .line 610
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 611
    .line 612
    .line 613
    const-string v8, "Sim1: "

    .line 614
    .line 615
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 616
    .line 617
    .line 618
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 619
    .line 620
    .line 621
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 622
    .line 623
    .line 624
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 625
    .line 626
    .line 627
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 628
    .line 629
    .line 630
    move-result-object v3

    .line 631
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 632
    .line 633
    .line 634
    iget-object v3, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 635
    .line 636
    invoke-static {v3, v5}, Lcom/cyberzone/newAdmin/DetailsActivity;->m0(Lcom/cyberzone/newAdmin/DetailsActivity;Ljava/lang/String;)Ljava/lang/String;

    .line 637
    .line 638
    .line 639
    move-result-object v3

    .line 640
    aput-object v3, v1, v9

    .line 641
    .line 642
    goto/16 :goto_4

    .line 643
    .line 644
    :cond_11
    if-ne v4, v0, :cond_c

    .line 645
    .line 646
    iget-object v4, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 647
    .line 648
    invoke-static {v4}, Lcom/cyberzone/newAdmin/DetailsActivity;->c0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 649
    .line 650
    .line 651
    move-result-object v4

    .line 652
    if-eqz v4, :cond_c

    .line 653
    .line 654
    iget-object v4, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 655
    .line 656
    invoke-static {v4}, Lcom/cyberzone/newAdmin/DetailsActivity;->c0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 657
    .line 658
    .line 659
    move-result-object v4

    .line 660
    new-instance v7, Ljava/lang/StringBuilder;

    .line 661
    .line 662
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 663
    .line 664
    .line 665
    const-string v8, "Sim2: "

    .line 666
    .line 667
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 668
    .line 669
    .line 670
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 671
    .line 672
    .line 673
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 674
    .line 675
    .line 676
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 677
    .line 678
    .line 679
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 680
    .line 681
    .line 682
    move-result-object v3

    .line 683
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 684
    .line 685
    .line 686
    iget-object v3, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 687
    .line 688
    invoke-static {v3, v5}, Lcom/cyberzone/newAdmin/DetailsActivity;->m0(Lcom/cyberzone/newAdmin/DetailsActivity;Ljava/lang/String;)Ljava/lang/String;

    .line 689
    .line 690
    .line 691
    move-result-object v3

    .line 692
    aput-object v3, v2, v9

    .line 693
    .line 694
    goto/16 :goto_4

    .line 695
    .line 696
    :cond_12
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 697
    .line 698
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->b0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 699
    .line 700
    .line 701
    move-result-object p1

    .line 702
    if-eqz p1, :cond_13

    .line 703
    .line 704
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 705
    .line 706
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->b0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 707
    .line 708
    .line 709
    move-result-object p1

    .line 710
    new-instance v0, Lcom/cyberzone/newAdmin/k;

    .line 711
    .line 712
    const/4 v3, 0x0

    .line 713
    invoke-direct {v0, p0, v1, v3}, Lcom/cyberzone/newAdmin/k;-><init>(Lcom/cyberzone/newAdmin/DetailsActivity$14;[Ljava/lang/String;I)V

    .line 714
    .line 715
    .line 716
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 717
    .line 718
    .line 719
    :cond_13
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 720
    .line 721
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->c0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 722
    .line 723
    .line 724
    move-result-object p1

    .line 725
    if-eqz p1, :cond_14

    .line 726
    .line 727
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 728
    .line 729
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->c0(Lcom/cyberzone/newAdmin/DetailsActivity;)Landroid/widget/TextView;

    .line 730
    .line 731
    .line 732
    move-result-object p1

    .line 733
    new-instance v0, Lcom/cyberzone/newAdmin/k;

    .line 734
    .line 735
    const/4 v1, 0x1

    .line 736
    invoke-direct {v0, p0, v2, v1}, Lcom/cyberzone/newAdmin/k;-><init>(Lcom/cyberzone/newAdmin/DetailsActivity$14;[Ljava/lang/String;I)V

    .line 737
    .line 738
    .line 739
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 740
    .line 741
    .line 742
    :cond_14
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 743
    .line 744
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->q0(Lcom/cyberzone/newAdmin/DetailsActivity;)V

    .line 745
    .line 746
    .line 747
    goto :goto_7

    .line 748
    :cond_15
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 749
    .line 750
    const-string v0, "Device data not found"

    .line 751
    .line 752
    invoke-static {p1, v0, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 753
    .line 754
    .line 755
    move-result-object p1

    .line 756
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 757
    .line 758
    .line 759
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 760
    .line 761
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 762
    .line 763
    .line 764
    :cond_16
    :goto_7
    iget-object p1, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 765
    .line 766
    invoke-static {p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->l0(Lcom/cyberzone/newAdmin/DetailsActivity;)V

    .line 767
    .line 768
    .line 769
    goto :goto_9

    .line 770
    :goto_8
    :try_start_7
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 771
    .line 772
    .line 773
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 774
    .line 775
    new-instance v1, Ljava/lang/StringBuilder;

    .line 776
    .line 777
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 778
    .line 779
    .line 780
    const-string v2, "Error loading device data: "

    .line 781
    .line 782
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 783
    .line 784
    .line 785
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 786
    .line 787
    .line 788
    move-result-object p1

    .line 789
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 790
    .line 791
    .line 792
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 793
    .line 794
    .line 795
    move-result-object p1

    .line 796
    invoke-static {v0, p1, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 797
    .line 798
    .line 799
    move-result-object p1

    .line 800
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 801
    .line 802
    .line 803
    goto :goto_7

    .line 804
    :goto_9
    return-void

    .line 805
    :goto_a
    iget-object v0, p0, Lcom/cyberzone/newAdmin/DetailsActivity$14;->this$0:Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 806
    .line 807
    invoke-static {v0}, Lcom/cyberzone/newAdmin/DetailsActivity;->l0(Lcom/cyberzone/newAdmin/DetailsActivity;)V

    .line 808
    .line 809
    .line 810
    throw p1
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
.end method
