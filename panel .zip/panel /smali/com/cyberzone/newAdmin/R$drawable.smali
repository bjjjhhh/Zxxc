.class public final Lcom/cyberzone/newAdmin/R$drawable;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static devider:I = 0x7f070099

.field public static devider1:I = 0x7f07009a

.field public static filter_button_bg:I = 0x7f07009b

.field public static ic_arrow_back_black:I = 0x7f07009e

.field public static ic_chrome:I = 0x7f0700a0

.field public static ic_content_copy_black:I = 0x7f0700a3

.field public static ic_delete_black:I = 0x7f0700a4

.field public static ic_info_black:I = 0x7f0700a5

.field public static ic_launcher_background:I = 0x7f0700a7

.field public static ic_launcher_foreground:I = 0x7f0700a8

.field public static ic_search_black:I = 0x7f0700b0

.field public static ic_settings_black:I = 0x7f0700b2

.field public static ic_sync_refresh:I = 0x7f0700b3

.field public static ic_thumb_up_black:I = 0x7f0700b4

.field public static loki_logo:I = 0x7f0700b5

.field public static menuicon:I = 0x7f0700cc


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
