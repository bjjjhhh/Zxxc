.class public interface abstract Lcom/cyberzone/newAdmin/DataUsageUtil$DataUsageCallback;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/DataUsageUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "DataUsageCallback"
.end annotation

.annotation runtime Ljava/lang/FunctionalInterface;
.end annotation


# virtual methods
.method public abstract onDataUsageUpdated(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public onError(Ljava/lang/String;)V
    .locals 0

    return-void
.end method
