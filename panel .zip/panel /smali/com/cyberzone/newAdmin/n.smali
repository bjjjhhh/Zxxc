.class public final synthetic Lcom/cyberzone/newAdmin/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/cyberzone/newAdmin/ForwardingActivity$3;

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/cyberzone/newAdmin/ForwardingActivity$3;ILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/cyberzone/newAdmin/n;->a:Lcom/cyberzone/newAdmin/ForwardingActivity$3;

    iput p2, p0, Lcom/cyberzone/newAdmin/n;->b:I

    iput-object p3, p0, Lcom/cyberzone/newAdmin/n;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/cyberzone/newAdmin/n;->c:Ljava/lang/String;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/n;->a:Lcom/cyberzone/newAdmin/ForwardingActivity$3;

    iget v2, p0, Lcom/cyberzone/newAdmin/n;->b:I

    invoke-static {v1, v2, v0}, Lcom/cyberzone/newAdmin/ForwardingActivity$3;->b(Lcom/cyberzone/newAdmin/ForwardingActivity$3;ILjava/lang/String;)V

    return-void
.end method
