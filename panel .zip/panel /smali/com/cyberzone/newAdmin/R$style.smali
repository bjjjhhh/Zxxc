.class public final Lcom/cyberzone/newAdmin/R$style;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static Base_Theme_AdminPanel:I = 0x7f11004b

.field public static RedButton:I = 0x7f110145

.field public static Theme_AdminPanel:I = 0x7f11020d


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
