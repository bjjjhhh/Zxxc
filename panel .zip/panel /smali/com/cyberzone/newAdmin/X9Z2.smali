.class public Lcom/cyberzone/newAdmin/X9Z2;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static fake1:Ljava/lang/String;

.field private static fake2:Ljava/lang/String;

.field private static p1:Ljava/lang/String;

.field private static p2:Ljava/lang/String;

.field private static p3:Ljava/lang/String;

.field private static p4:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const-string v0, "ScKit-41a8186c4001d8b5c44f5151822246a345ddd9c8b512b8243f24e4b5b4979544"

    const-string v2, "ScKit-9220f642e45c758b"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/X9Z2;->fake1:Ljava/lang/String;

    const-string v0, "ScKit-094df0be8c687f8389ca57425a2eb57145ddd9c8b512b8243f24e4b5b4979544"

    const-string v2, "ScKit-9220f642e45c758b"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/X9Z2;->fake2:Ljava/lang/String;

    const-string v0, "ScKit-b98600b498126c606134bff4af6ff5f645ddd9c8b512b8243f24e4b5b4979544"

    const-string v2, "ScKit-9220f642e45c758b"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/X9Z2;->p1:Ljava/lang/String;

    const-string v0, "ScKit-47deed77ab8e3262cc88d7e797bf8a5945ddd9c8b512b8243f24e4b5b4979544"

    const-string v2, "ScKit-9220f642e45c758b"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/X9Z2;->p2:Ljava/lang/String;

    const-string v0, "ScKit-8dbbe874d85106ee1cc3c721d6b00a1445ddd9c8b512b8243f24e4b5b4979544"

    const-string v2, "ScKit-9220f642e45c758b"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/X9Z2;->p3:Ljava/lang/String;

    const-string v0, "ScKit-92dc90fdeec7cdfdb6c57885d026be7845ddd9c8b512b8243f24e4b5b4979544"

    const-string v2, "ScKit-9220f642e45c758b"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/X9Z2;->p4:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public static k()Ljava/lang/String;
    .locals 4

    .line 1
    const-string v0, "ScKit-b98600b498126c606134bff4af6ff5f647deed77ab8e3262cc88d7e797bf8a598dbbe874d85106ee1cc3c721d6b00a1492dc90fdeec7cdfdb6c57885d026be7845ddd9c8b512b8243f24e4b5b4979544"

    .line 2
    const-string v2, "ScKit-9220f642e45c758b"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public static k2(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    move-object/from16 v1, p0

    .line 1
    :try_start_0
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 2
    .line 3
    .line 4
    move-result-object v1

    .line 5
    const-string v0, "ScKit-764659cff5c26ddf0ec05ee670d12d85"

    .line 6
    const-string v4, "ScKit-9220f642e45c758b"

    move-object/from16 v3, v0

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 7
    invoke-static {v1, v0}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    const/4 v0, 0x1

    .line 18
    if-ge v1, v0, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    invoke-static {}, Lcom/cyberzone/newAdmin/X9Z2;->k()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    return-object v1

    .line 26
    :cond_1
    :goto_0
    const-string v1, "ScKit-dd2fd2d1308b60fba219eb655f5c1cd1"

    .line 27
    const-string v4, "ScKit-9220f642e45c758b"

    move-object/from16 v3, v1

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 28
    return-object v1

    .line 29
    :catch_0
    invoke-static {}, Lcom/cyberzone/newAdmin/X9Z2;->k()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    return-object v1
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method
