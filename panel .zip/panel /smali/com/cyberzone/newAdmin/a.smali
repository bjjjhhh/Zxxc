.class public final synthetic Lcom/cyberzone/newAdmin/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/tasks/OnCompleteListener;


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lcom/cyberzone/newAdmin/AppSpreadActivity$SendCallback;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/cyberzone/newAdmin/AppSpreadActivity$SendCallback;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/cyberzone/newAdmin/a;->a:Ljava/lang/String;

    iput-object p2, p0, Lcom/cyberzone/newAdmin/a;->b:Ljava/lang/String;

    iput-object p3, p0, Lcom/cyberzone/newAdmin/a;->c:Lcom/cyberzone/newAdmin/AppSpreadActivity$SendCallback;

    return-void
.end method


# virtual methods
.method public final onComplete(Lcom/google/android/gms/tasks/Task;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/cyberzone/newAdmin/a;->c:Lcom/cyberzone/newAdmin/AppSpreadActivity$SendCallback;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/a;->a:Ljava/lang/String;

    iget-object v2, p0, Lcom/cyberzone/newAdmin/a;->b:Ljava/lang/String;

    invoke-static {v1, v2, v0, p1}, Lcom/cyberzone/newAdmin/AppSpreadActivity;->i(Ljava/lang/String;Ljava/lang/String;Lcom/cyberzone/newAdmin/AppSpreadActivity$SendCallback;Lcom/google/android/gms/tasks/Task;)V

    return-void
.end method
