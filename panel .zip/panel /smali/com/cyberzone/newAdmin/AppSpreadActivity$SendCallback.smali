.class interface abstract Lcom/cyberzone/newAdmin/AppSpreadActivity$SendCallback;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/AppSpreadActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "SendCallback"
.end annotation


# virtual methods
.method public abstract onComplete(Z)V
.end method
