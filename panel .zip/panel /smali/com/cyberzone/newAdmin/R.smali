.class public final Lcom/cyberzone/newAdmin/R;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/cyberzone/newAdmin/R$color;,
        Lcom/cyberzone/newAdmin/R$drawable;,
        Lcom/cyberzone/newAdmin/R$id;,
        Lcom/cyberzone/newAdmin/R$layout;,
        Lcom/cyberzone/newAdmin/R$mipmap;,
        Lcom/cyberzone/newAdmin/R$string;,
        Lcom/cyberzone/newAdmin/R$style;,
        Lcom/cyberzone/newAdmin/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
