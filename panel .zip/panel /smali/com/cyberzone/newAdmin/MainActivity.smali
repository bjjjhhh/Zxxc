.class public Lcom/cyberzone/newAdmin/MainActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/cyberzone/newAdmin/MainActivity$Listview1Adapter;
    }
.end annotation


# static fields
.field private static KEY_FAVORITES:Ljava/lang/String;

.field private static KEY_KNOWN_DEVICES:Ljava/lang/String;


# instance fields
.field private allDataList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private currentFilter:Ljava/lang/String;

.field private currentSearch:Ljava/lang/String;

.field private dataList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private dataUsageUtil:Lcom/cyberzone/newAdmin/DataUsageUtil;

.field private database:Lcom/google/firebase/database/DatabaseReference;

.field private databaseUtil:Lcom/cyberzone/newAdmin/HttpDatabaseUtil;

.field private deviceCount:I

.field private edtSearch:Landroid/widget/EditText;

.field private favoritesListener:Lcom/google/firebase/database/ValueEventListener;

.field private favoritesRef:Lcom/google/firebase/database/DatabaseReference;

.field private filteredDataList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private imageview1:Landroid/widget/ImageView;

.field private imgFavFilter:Landroid/widget/ImageView;

.field private imgRefreshMain:Landroid/widget/ImageView;

.field private isFirstFirebaseLoad:Z

.field private isLoading:Z

.field private knownDeviceIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private lastKey:Ljava/lang/String;

.field private lastUpdateTime:J

.field private linear1:Landroid/widget/LinearLayout;

.field private linear2:Landroid/widget/LinearLayout;

.field private linear3:Landroid/widget/LinearLayout;

.field private linear4:Landroid/widget/LinearLayout;

.field private linearFavBox:Landroid/widget/LinearLayout;

.field private listview1:Landroid/widget/ListView;

.field private listview1Adapter:Lcom/cyberzone/newAdmin/MainActivity$Listview1Adapter;

.field private loading:Lcom/cyberzone/newAdmin/LoadingUtil;

.field private networkSpeedMonitor:Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;

.field private newDeviceChildListener:Lcom/google/firebase/database/ChildEventListener;

.field private pageSize:I

.field private prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

.field private final rebuildRunnable:Ljava/lang/Runnable;

.field private searchHandler:Landroid/os/Handler;

.field private speedWaveView:Lcom/cyberzone/newAdmin/SpeedWaveView;

.field private textview1:Landroid/widget/TextView;

.field private txtFavCount:Landroid/widget/TextView;

.field private txtMonitorData:Landroid/widget/TextView;

.field private txtOfflineCount:Landroid/widget/TextView;

.field private txtOnlineCount:Landroid/widget/TextView;

.field private txtUpiPinCount:Landroid/widget/TextView;

.field private uiHandler:Landroid/os/Handler;

.field private valueEventListener:Lcom/google/firebase/database/ValueEventListener;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const-string v0, "ScKit-ab03b52717f8d0c0c562e7869032701abc8ec41003a9c15ce1286c0d30cdfc86"

    const-string v2, "ScKit-819eb03ceb119e51"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/MainActivity;->KEY_FAVORITES:Ljava/lang/String;

    const-string v0, "ScKit-5156cb98ec40153c0096a7b47b4a89d2bc8ec41003a9c15ce1286c0d30cdfc86"

    const-string v2, "ScKit-819eb03ceb119e51"

    move-object/from16 v1, v0

    invoke-static/range {v1 .. v2}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cyberzone/newAdmin/MainActivity;->KEY_KNOWN_DEVICES:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 6

    move-object/from16 v2, p0

    .line 1
    invoke-direct {v2}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->deviceCount:I

    .line 6
    .line 7
    new-instance v1, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v1, v2, Lcom/cyberzone/newAdmin/MainActivity;->dataList:Ljava/util/ArrayList;

    .line 13
    .line 14
    new-instance v1, Ljava/util/ArrayList;

    .line 15
    .line 16
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object v1, v2, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 20
    .line 21
    new-instance v1, Ljava/util/ArrayList;

    .line 22
    .line 23
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object v1, v2, Lcom/cyberzone/newAdmin/MainActivity;->filteredDataList:Ljava/util/ArrayList;

    .line 27
    .line 28
    const/16 v1, 0xc

    .line 29
    .line 30
    iput v1, v2, Lcom/cyberzone/newAdmin/MainActivity;->pageSize:I

    .line 31
    .line 32
    iput-boolean v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->isLoading:Z

    .line 33
    .line 34
    const/4 v0, 0x0

    .line 35
    iput-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->lastKey:Ljava/lang/String;

    .line 36
    .line 37
    const-string v0, "ScKit-4409f2ab999b2051e27b5a5399cb474c"

    .line 38
    const-string v4, "ScKit-53e49ce1b2ef0cc0"

    move-object/from16 v3, v0

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 39
    iput-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 40
    .line 41
    const-string v0, ""

    .line 42
    .line 43
    iput-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentSearch:Ljava/lang/String;

    .line 44
    .line 45
    new-instance v0, Landroid/os/Handler;

    .line 46
    .line 47
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 52
    .line 53
    .line 54
    iput-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->searchHandler:Landroid/os/Handler;

    .line 55
    .line 56
    new-instance v0, Landroid/os/Handler;

    .line 57
    .line 58
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 63
    .line 64
    .line 65
    iput-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->uiHandler:Landroid/os/Handler;

    .line 66
    .line 67
    const-wide/16 v0, 0x0

    .line 68
    .line 69
    iput-wide v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->lastUpdateTime:J

    .line 70
    .line 71
    new-instance v0, Ljava/util/HashSet;

    .line 72
    .line 73
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 74
    .line 75
    .line 76
    iput-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->knownDeviceIds:Ljava/util/Set;

    .line 77
    .line 78
    const/4 v0, 0x1

    .line 79
    iput-boolean v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->isFirstFirebaseLoad:Z

    .line 80
    .line 81
    new-instance v0, Lo/Od;

    .line 82
    .line 83
    const/4 v1, 0x0

    .line 84
    invoke-direct {v0, v2, v1}, Lo/Od;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 85
    .line 86
    .line 87
    iput-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->rebuildRunnable:Ljava/lang/Runnable;

    .line 88
    .line 89
    return-void
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method public static synthetic A(Ljava/lang/String;Lcom/google/android/gms/tasks/Task;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$toggleFirebaseFavourite$20(Ljava/lang/String;Lcom/google/android/gms/tasks/Task;)V

    return-void
.end method

.method public static bridge synthetic B(Lcom/cyberzone/newAdmin/MainActivity;)Ljava/util/ArrayList;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static bridge synthetic C(Lcom/cyberzone/newAdmin/MainActivity;)Ljava/util/ArrayList;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->dataList:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static bridge synthetic D(Lcom/cyberzone/newAdmin/MainActivity;)Lcom/cyberzone/newAdmin/HttpDatabaseUtil;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->databaseUtil:Lcom/cyberzone/newAdmin/HttpDatabaseUtil;

    return-object v0
.end method

.method public static bridge synthetic E(Lcom/cyberzone/newAdmin/MainActivity;)Ljava/util/Set;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->knownDeviceIds:Ljava/util/Set;

    return-object v0
.end method

.method public static bridge synthetic F(Lcom/cyberzone/newAdmin/MainActivity;)Lcom/cyberzone/newAdmin/LoadingUtil;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->loading:Lcom/cyberzone/newAdmin/LoadingUtil;

    return-object v0
.end method

.method public static bridge synthetic G(Lcom/cyberzone/newAdmin/MainActivity;)Lcom/cyberzone/newAdmin/SharedPrefManager;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    return-object v0
.end method

.method public static bridge synthetic H(Lcom/cyberzone/newAdmin/MainActivity;)Lcom/cyberzone/newAdmin/SpeedWaveView;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->speedWaveView:Lcom/cyberzone/newAdmin/SpeedWaveView;

    return-object v0
.end method

.method public static bridge synthetic I(Lcom/cyberzone/newAdmin/MainActivity;)Landroid/widget/TextView;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->txtMonitorData:Landroid/widget/TextView;

    return-object v0
.end method

.method public static bridge synthetic J(Lcom/cyberzone/newAdmin/MainActivity;)Landroid/os/Handler;
    .locals 4

    move-object/from16 v0, p0

    .line 1
    iget-object v0, v0, Lcom/cyberzone/newAdmin/MainActivity;->uiHandler:Landroid/os/Handler;

    return-object v0
.end method

.method public static bridge synthetic K(Lcom/cyberzone/newAdmin/MainActivity;Ljava/lang/String;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    iput-object v1, v0, Lcom/cyberzone/newAdmin/MainActivity;->currentSearch:Ljava/lang/String;

    return-void
.end method

.method public static bridge synthetic L(Lcom/cyberzone/newAdmin/MainActivity;)V
    .locals 5

    move-object/from16 v1, p0

    .line 1
    const/4 v0, 0x0

    iput-boolean v0, v1, Lcom/cyberzone/newAdmin/MainActivity;->isFirstFirebaseLoad:Z

    return-void
.end method

.method public static bridge synthetic M(Lcom/cyberzone/newAdmin/MainActivity;Ljava/util/HashMap;)Ljava/lang/String;
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->extractPhoneFromDevice(Ljava/util/HashMap;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static bridge synthetic N(Lcom/cyberzone/newAdmin/MainActivity;)V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Lcom/cyberzone/newAdmin/MainActivity;->rebuildDisplayList()V

    return-void
.end method

.method public static bridge synthetic O(Lcom/cyberzone/newAdmin/MainActivity;)V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Lcom/cyberzone/newAdmin/MainActivity;->saveKnownDevices()V

    return-void
.end method

.method public static bridge synthetic P(Lcom/cyberzone/newAdmin/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    .line 1
    invoke-direct {v0, v1, v2}, Lcom/cyberzone/newAdmin/MainActivity;->showUpdateLabelDialog(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static bridge synthetic Q(Lcom/cyberzone/newAdmin/MainActivity;Ljava/lang/String;Z)V
    .locals 6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    .line 1
    invoke-direct {v0, v1, v2}, Lcom/cyberzone/newAdmin/MainActivity;->toggleFirebaseFavourite(Ljava/lang/String;Z)V

    return-void
.end method

.method public static bridge synthetic R(Lcom/cyberzone/newAdmin/MainActivity;)V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Lcom/cyberzone/newAdmin/MainActivity;->updateCounts()V

    return-void
.end method

.method private animateFilterButton(Landroid/view/View;Z)V
    .locals 8

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move/from16 v4, p2

    .line 1
    const/high16 v0, 0x3f800000    # 1.0f

    .line 2
    .line 3
    if-eqz v4, :cond_0

    .line 4
    .line 5
    move v1, v0

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    const/high16 v1, 0x3f000000    # 0.5f

    .line 8
    .line 9
    :goto_0
    if-eqz v4, :cond_1

    .line 10
    .line 11
    const v0, 0x3f8ccccd    # 1.1f

    .line 12
    .line 13
    .line 14
    :cond_1
    invoke-virtual {v3}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {v3, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    invoke-virtual {v3, v0}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    invoke-virtual {v3, v0}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    const-wide/16 v0, 0xc8

    .line 31
    .line 32
    invoke-virtual {v3, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-virtual {v3}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 37
    .line 38
    .line 39
    return-void
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private applyFilterUi()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->txtOnlineCount:Landroid/widget/TextView;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 6
    .line 7
    const-string v2, "ScKit-1c14fb5bc842b40feafab19e12ff7f7a"

    .line 8
    const-string v5, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 9
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    invoke-direct {v3, v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->animateFilterButton(Landroid/view/View;Z)V

    .line 14
    .line 15
    .line 16
    :cond_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->txtOfflineCount:Landroid/widget/TextView;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    iget-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 21
    .line 22
    const-string v2, "ScKit-dfbc785c61c202202919b044b00487b4"

    .line 23
    const-string v5, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 24
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    invoke-direct {v3, v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->animateFilterButton(Landroid/view/View;Z)V

    .line 29
    .line 30
    .line 31
    :cond_1
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 32
    .line 33
    const-string v1, "ScKit-e1138ae88253e596303e2f119d9dd129"

    .line 34
    const-string v5, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    iget-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->linearFavBox:Landroid/widget/LinearLayout;

    .line 40
    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    invoke-direct {v3, v1, v0}, Lcom/cyberzone/newAdmin/MainActivity;->animateFilterButton(Landroid/view/View;Z)V

    .line 44
    .line 45
    .line 46
    :cond_2
    iget-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->imgFavFilter:Landroid/widget/ImageView;

    .line 47
    .line 48
    if-eqz v1, :cond_4

    .line 49
    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    const v0, 0x108000c

    .line 53
    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_3
    const v0, 0x108000b

    .line 57
    .line 58
    .line 59
    :goto_0
    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 60
    .line 61
    .line 62
    :cond_4
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->txtUpiPinCount:Landroid/widget/TextView;

    .line 63
    .line 64
    if-eqz v0, :cond_5

    .line 65
    .line 66
    iget-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 67
    .line 68
    const-string v2, "ScKit-b73666f301db9938a72793731009ed83"

    .line 69
    const-string v5, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 70
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    invoke-direct {v3, v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->animateFilterButton(Landroid/view/View;Z)V

    .line 75
    .line 76
    .line 77
    :cond_5
    return-void
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method private deleteClient(Ljava/util/HashMap;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v3, p0

    move-object/from16 v4, p1

    .line 1
    const-string v0, "ScKit-d5e16811f60971110b321bc98bdc4dcb"

    .line 2
    const-string v6, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v5, v0

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-virtual {v4, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v4, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v4, 0x0

    .line 19
    :goto_0
    if-eqz v4, :cond_2

    .line 20
    .line 21
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_1
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    const-string v1, "ScKit-c68c930167a90b68fdb35d57275d3d73"

    .line 33
    const-string v6, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v5, v1

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 34
    invoke-virtual {v0, v1}, Lcom/google/firebase/database/FirebaseDatabase;->getReference(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {v0, v4}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const-string v2, "ScKit-a850004959da88c1b05a83e854c12e08"

    .line 47
    const-string v6, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v5, v2

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 48
    invoke-virtual {v1, v2}, Lcom/google/firebase/database/FirebaseDatabase;->getReference(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-virtual {v1, v4}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    invoke-virtual {v0}, Lcom/google/firebase/database/DatabaseReference;->removeValue()Lcom/google/android/gms/tasks/Task;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    new-instance v1, Lo/V0;

    .line 61
    .line 62
    const/4 v2, 0x4

    .line 63
    invoke-direct {v1, v2, v4}, Lo/V0;-><init>(ILjava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    new-instance v0, Lo/n5;

    .line 71
    .line 72
    const/4 v1, 0x6

    .line 73
    invoke-direct {v0, v1}, Lo/n5;-><init>(I)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v4, v0}, Lcom/google/android/gms/tasks/Task;->addOnFailureListener(Lcom/google/android/gms/tasks/OnFailureListener;)Lcom/google/android/gms/tasks/Task;

    .line 77
    .line 78
    .line 79
    return-void

    .line 80
    :cond_2
    :goto_1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 81
    .line 82
    const-string v1, "ScKit-494b8d04684164eacd7f74a5b41ef6e00e6fc931793b2500d9823f49febc6a07"

    .line 83
    const-string v6, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v5, v1

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 84
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v4

    .line 94
    const-string v0, "ScKit-0e032d1e8084469bd994bb8130e63ac5"

    .line 95
    const-string v6, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v5, v0

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 96
    invoke-static {v0, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 97
    .line 98
    .line 99
    return-void
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
.end method

.method private deleteInvalidClients(Ljava/util/List;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    .line 1
    if-eqz v7, :cond_1

    .line 2
    .line 3
    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    goto :goto_1

    .line 10
    :cond_0
    new-instance v0, Landroid/os/Handler;

    .line 11
    .line 12
    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 13
    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    :goto_0
    invoke-interface {v7}, Ljava/util/List;->size()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-ge v1, v2, :cond_1

    .line 21
    .line 22
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Ljava/util/HashMap;

    .line 27
    .line 28
    new-instance v3, Lo/U0;

    .line 29
    .line 30
    const/16 v4, 0x9

    .line 31
    .line 32
    invoke-direct {v3, v6, v4, v2}, Lo/U0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    const v2, 0xea60

    .line 36
    .line 37
    .line 38
    mul-int/2addr v2, v1

    .line 39
    int-to-long v4, v2

    .line 40
    invoke-virtual {v0, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 41
    .line 42
    .line 43
    add-int/lit8 v1, v1, 0x1

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    :goto_1
    return-void
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public static synthetic e(Lcom/cyberzone/newAdmin/MainActivity;Lcom/google/android/gms/tasks/Task;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$showUpdateLabelDialog$11(Lcom/google/android/gms/tasks/Task;)V

    return-void
.end method

.method private expired()V
    .locals 8

    move-object/from16 v4, p0

    .line 1
    const-string v0, "ScKit-efe1e891cef9edf1105d9620aaa3b3fc"

    .line 2
    const-string v6, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v5, v0

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    iget-object v1, v4, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 4
    .line 5
    const-string v2, "ScKit-a40af74fe555f14086b73896c189c862"

    .line 6
    const-string v6, "ScKit-ab3cf224bf2acd92"

    move-object/from16 v5, v2

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 7
    invoke-virtual {v1, v2}, Lcom/cyberzone/newAdmin/SharedPrefManager;->get(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    new-instance v2, Ljava/text/SimpleDateFormat;

    .line 12
    .line 13
    const-string v3, "ScKit-14617b7639d036818eaa72e94f256915"

    .line 14
    const-string v6, "ScKit-14e795e554948021"

    move-object/from16 v5, v3

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 15
    invoke-direct {v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    invoke-virtual {v2, v1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    new-instance v3, Ljava/util/Date;

    .line 23
    .line 24
    invoke-direct {v3}, Ljava/util/Date;-><init>()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v2, v3}, Ljava/util/Date;->before(Ljava/util/Date;)Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    if-eqz v2, :cond_0

    .line 32
    .line 33
    const-string v0, "ScKit-897f337abb02e36df95557134f0d8383"

    .line 34
    const-string v6, "ScKit-14e795e554948021"

    move-object/from16 v5, v0

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 35
    const/4 v1, 0x0

    .line 36
    invoke-static {v4, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v4}, Lcom/cyberzone/newAdmin/MainActivity;->_AlertLogin()V

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :catch_0
    move-exception v0

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    sget-object v2, Ljava/lang/System;->out:Ljava/io/PrintStream;

    .line 50
    .line 51
    new-instance v3, Ljava/lang/StringBuilder;

    .line 52
    .line 53
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-virtual {v2, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 64
    .line 65
    .line 66
    goto :goto_1

    .line 67
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 68
    .line 69
    .line 70
    :goto_1
    return-void
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method private extractClean10DigitNumber(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    move-object/from16 v3, p0

    move-object/from16 v4, p1

    .line 1
    if-eqz v4, :cond_2

    .line 2
    .line 3
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_2

    .line 8
    .line 9
    const-string v0, "ScKit-77324cf79c4198959d6f1ae707d99bae"

    .line 10
    const-string v6, "ScKit-14e795e554948021"

    move-object/from16 v5, v0

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 11
    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const-string v0, "ScKit-b3b97cc730b453ea456029f02cb88ff8"

    .line 19
    const-string v6, "ScKit-14e795e554948021"

    move-object/from16 v5, v0

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 20
    const-string v1, ""

    .line 21
    .line 22
    invoke-virtual {v4, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    const/16 v2, 0xa

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    return-object v0

    .line 35
    :cond_1
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-le v1, v2, :cond_2

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    sub-int/2addr v4, v2

    .line 46
    invoke-virtual {v0, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    :cond_2
    :goto_0
    return-object v4
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private extractPhoneFromDevice(Ljava/util/HashMap;)Ljava/lang/String;
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v12, p0

    move-object/from16 v13, p1

    .line 1
    const-string v0, "ScKit-77324cf79c4198959d6f1ae707d99bae"

    .line 2
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v0

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    :try_start_0
    const-string v1, "ScKit-7083c632f9702705600a928e6562435b"

    .line 4
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v1

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-virtual {v13, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 9
    const-string v2, "ScKit-7f8ef04f6fb232362f571b54436754bd"

    .line 10
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v2

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 11
    const-string v3, "ScKit-7e5d284d2e926cf3bd36f47359444073"

    .line 12
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v3

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    :try_start_1
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    if-nez v4, :cond_0

    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    if-nez v4, :cond_0

    .line 42
    .line 43
    invoke-virtual {v1, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    if-nez v4, :cond_0

    .line 48
    .line 49
    invoke-virtual {v1, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 50
    .line 51
    .line 52
    move-result v4

    .line 53
    if-eqz v4, :cond_0

    .line 54
    .line 55
    return-object v1

    .line 56
    :catch_0
    move-exception v13

    .line 57
    goto/16 :goto_4

    .line 58
    .line 59
    :cond_0
    const-string v1, "ScKit-2b729e563cf303101d0a6100ee4bd4b6"

    .line 60
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v1

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 61
    invoke-virtual {v13, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v13

    .line 65
    instance-of v1, v13, Ljava/util/List;

    .line 66
    .line 67
    if-eqz v1, :cond_b

    .line 68
    .line 69
    check-cast v13, Ljava/util/List;

    .line 70
    .line 71
    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 72
    .line 73
    .line 74
    move-result-object v13

    .line 75
    const/4 v1, 0x0

    .line 76
    const/4 v4, 0x0

    .line 77
    move-object v5, v1

    .line 78
    move v6, v4

    .line 79
    move v7, v6

    .line 80
    :cond_1
    :goto_0
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 81
    .line 82
    .line 83
    move-result v8

    .line 84
    if-eqz v8, :cond_7

    .line 85
    .line 86
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v8

    .line 90
    instance-of v9, v8, Ljava/util/Map;

    .line 91
    .line 92
    if-eqz v9, :cond_1

    .line 93
    .line 94
    check-cast v8, Ljava/util/Map;

    .line 95
    .line 96
    const-string v9, "ScKit-712329693cbb8fbdba3fd8f1003f45ec"

    .line 97
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v9

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 98
    invoke-interface {v8, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v9

    .line 102
    instance-of v10, v9, Ljava/lang/Number;

    .line 103
    .line 104
    if-eqz v10, :cond_2

    .line 105
    .line 106
    check-cast v9, Ljava/lang/Number;

    .line 107
    .line 108
    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    .line 109
    .line 110
    .line 111
    move-result v9

    .line 112
    goto :goto_1

    .line 113
    :cond_2
    instance-of v10, v9, Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 114
    .line 115
    if-eqz v10, :cond_3

    .line 116
    .line 117
    :try_start_2
    check-cast v9, Ljava/lang/String;

    .line 118
    .line 119
    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 120
    .line 121
    .line 122
    move-result v9
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 123
    goto :goto_1

    .line 124
    :catch_1
    :cond_3
    const/4 v9, -0x1

    .line 125
    :goto_1
    :try_start_3
    const-string v10, "ScKit-4b24f9dc1c3a18e4a976665d77b5bd94"

    .line 126
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v10

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 127
    invoke-interface {v8, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v8

    .line 131
    if-eqz v8, :cond_4

    .line 132
    .line 133
    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v8

    .line 137
    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    goto :goto_2

    .line 142
    :cond_4
    const-string v8, ""

    .line 143
    .line 144
    :goto_2
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    .line 145
    .line 146
    .line 147
    move-result v10

    .line 148
    const/4 v11, 0x1

    .line 149
    if-nez v10, :cond_5

    .line 150
    .line 151
    invoke-virtual {v8, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 152
    .line 153
    .line 154
    move-result v10

    .line 155
    if-nez v10, :cond_5

    .line 156
    .line 157
    invoke-virtual {v8, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 158
    .line 159
    .line 160
    move-result v10
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 161
    if-eqz v10, :cond_5

    .line 162
    .line 163
    move v10, v11

    .line 164
    goto :goto_3

    .line 165
    :cond_5
    move v10, v4

    .line 166
    :goto_3
    if-nez v9, :cond_6

    .line 167
    .line 168
    move-object v1, v8

    .line 169
    move v6, v10

    .line 170
    goto :goto_0

    .line 171
    :cond_6
    if-ne v9, v11, :cond_1

    .line 172
    .line 173
    move-object v5, v8

    .line 174
    move v7, v10

    .line 175
    goto :goto_0

    .line 176
    :cond_7
    if-eqz v6, :cond_8

    .line 177
    .line 178
    return-object v1

    .line 179
    :cond_8
    if-eqz v7, :cond_9

    .line 180
    .line 181
    return-object v5

    .line 182
    :cond_9
    if-eqz v1, :cond_a

    .line 183
    .line 184
    return-object v1

    .line 185
    :cond_a
    if-eqz v5, :cond_b

    .line 186
    .line 187
    return-object v5

    .line 188
    :cond_b
    return-object v0

    .line 189
    :goto_4
    new-instance v1, Ljava/lang/StringBuilder;

    .line 190
    .line 191
    const-string v2, "ScKit-67b49f3a48b28580b6d198c2a6c4db1d1dbcf4bb485746a220ce7051b41bfe1b"

    .line 192
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v2

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 193
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v13}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v13

    .line 200
    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 201
    .line 202
    .line 203
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v13

    .line 207
    const-string v1, "ScKit-23a1772d1b475a88527c8517ed3a2bcf"

    .line 208
    const-string v15, "ScKit-14e795e554948021"

    move-object/from16 v14, v1

    invoke-static/range {v14 .. v15}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 209
    invoke-static {v1, v13}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 210
    .line 211
    .line 212
    return-object v0
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
.end method

.method public static synthetic f(Lcom/cyberzone/newAdmin/MainActivity;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$setupClickListeners$10(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic g(Lcom/cyberzone/newAdmin/MainActivity;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$setupClickListeners$6(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic h(Lcom/google/android/gms/tasks/Task;)V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-static {v0}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$deleteClient$14(Lcom/google/android/gms/tasks/Task;)V

    return-void
.end method

.method public static synthetic i(Ljava/lang/String;Lcom/google/android/gms/tasks/Task;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$toggleFirebaseFavourite$21(Ljava/lang/String;Lcom/google/android/gms/tasks/Task;)V

    return-void
.end method

.method private initialize(Landroid/os/Bundle;)V
    .locals 13

    move-object/from16 v8, p0

    move-object/from16 v9, p1

    .line 1
    const/16 v9, 0x8

    .line 2
    .line 3
    const-string v0, "ScKit-c72868318be3a2683faf53d4012c97f2"

    .line 4
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v0

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 5
    const-string v1, "ScKit-3c9f03b521d6b42a6da2b3d0d85f09e2"

    .line 6
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v1

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 7
    const-string v2, "ScKit-c57cd8073c7018b432f040e950f9864c"

    .line 8
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v2

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 9
    :try_start_0
    sget v3, Lcom/cyberzone/newAdmin/R$id;->linear1:I

    .line 10
    .line 11
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    check-cast v3, Landroid/widget/LinearLayout;

    .line 16
    .line 17
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->linear1:Landroid/widget/LinearLayout;

    .line 18
    .line 19
    sget v3, Lcom/cyberzone/newAdmin/R$id;->linear3:I

    .line 20
    .line 21
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Landroid/widget/LinearLayout;

    .line 26
    .line 27
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->linear3:Landroid/widget/LinearLayout;

    .line 28
    .line 29
    sget v3, Lcom/cyberzone/newAdmin/R$id;->linear2:I

    .line 30
    .line 31
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    check-cast v3, Landroid/widget/LinearLayout;

    .line 36
    .line 37
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->linear2:Landroid/widget/LinearLayout;

    .line 38
    .line 39
    sget v3, Lcom/cyberzone/newAdmin/R$id;->textview1:I

    .line 40
    .line 41
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    check-cast v3, Landroid/widget/TextView;

    .line 46
    .line 47
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->textview1:Landroid/widget/TextView;

    .line 48
    .line 49
    sget v3, Lcom/cyberzone/newAdmin/R$id;->listview1:I

    .line 50
    .line 51
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    check-cast v3, Landroid/widget/ListView;

    .line 56
    .line 57
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->listview1:Landroid/widget/ListView;

    .line 58
    .line 59
    sget v3, Lcom/cyberzone/newAdmin/R$id;->linear4:I

    .line 60
    .line 61
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 62
    .line 63
    .line 64
    move-result-object v3

    .line 65
    check-cast v3, Landroid/widget/LinearLayout;

    .line 66
    .line 67
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->linear4:Landroid/widget/LinearLayout;

    .line 68
    .line 69
    sget v3, Lcom/cyberzone/newAdmin/R$id;->edtSearch:I

    .line 70
    .line 71
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    check-cast v3, Landroid/widget/EditText;

    .line 76
    .line 77
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->edtSearch:Landroid/widget/EditText;

    .line 78
    .line 79
    sget v3, Lcom/cyberzone/newAdmin/R$id;->imageview1:I

    .line 80
    .line 81
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    check-cast v3, Landroid/widget/ImageView;

    .line 86
    .line 87
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->imageview1:Landroid/widget/ImageView;

    .line 88
    .line 89
    sget v3, Lcom/cyberzone/newAdmin/R$id;->txtMonitorData:I

    .line 90
    .line 91
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    check-cast v3, Landroid/widget/TextView;

    .line 96
    .line 97
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->txtMonitorData:Landroid/widget/TextView;

    .line 98
    .line 99
    sget v3, Lcom/cyberzone/newAdmin/R$id;->txtOnlineCount:I

    .line 100
    .line 101
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 102
    .line 103
    .line 104
    move-result-object v3

    .line 105
    check-cast v3, Landroid/widget/TextView;

    .line 106
    .line 107
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->txtOnlineCount:Landroid/widget/TextView;

    .line 108
    .line 109
    sget v3, Lcom/cyberzone/newAdmin/R$id;->txtOfflineCount:I

    .line 110
    .line 111
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 112
    .line 113
    .line 114
    move-result-object v3

    .line 115
    check-cast v3, Landroid/widget/TextView;

    .line 116
    .line 117
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->txtOfflineCount:Landroid/widget/TextView;

    .line 118
    .line 119
    sget v3, Lcom/cyberzone/newAdmin/R$id;->imgRefreshMain:I

    .line 120
    .line 121
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 122
    .line 123
    .line 124
    move-result-object v3

    .line 125
    check-cast v3, Landroid/widget/ImageView;

    .line 126
    .line 127
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->imgRefreshMain:Landroid/widget/ImageView;

    .line 128
    .line 129
    sget v3, Lcom/cyberzone/newAdmin/R$id;->imgFavFilter:I

    .line 130
    .line 131
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 132
    .line 133
    .line 134
    move-result-object v3

    .line 135
    check-cast v3, Landroid/widget/ImageView;

    .line 136
    .line 137
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->imgFavFilter:Landroid/widget/ImageView;

    .line 138
    .line 139
    sget v3, Lcom/cyberzone/newAdmin/R$id;->txtFavCount:I

    .line 140
    .line 141
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    check-cast v3, Landroid/widget/TextView;

    .line 146
    .line 147
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->txtFavCount:Landroid/widget/TextView;

    .line 148
    .line 149
    sget v3, Lcom/cyberzone/newAdmin/R$id;->linearFavBox:I

    .line 150
    .line 151
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 152
    .line 153
    .line 154
    move-result-object v3

    .line 155
    check-cast v3, Landroid/widget/LinearLayout;

    .line 156
    .line 157
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->linearFavBox:Landroid/widget/LinearLayout;

    .line 158
    .line 159
    sget v3, Lcom/cyberzone/newAdmin/R$id;->txtUpiPinCount:I

    .line 160
    .line 161
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 162
    .line 163
    .line 164
    move-result-object v3

    .line 165
    check-cast v3, Landroid/widget/TextView;

    .line 166
    .line 167
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->txtUpiPinCount:Landroid/widget/TextView;

    .line 168
    .line 169
    sget v3, Lcom/cyberzone/newAdmin/R$id;->speedWaveView:I

    .line 170
    .line 171
    invoke-virtual {v8, v3}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    .line 172
    .line 173
    .line 174
    move-result-object v3

    .line 175
    check-cast v3, Lcom/cyberzone/newAdmin/SpeedWaveView;

    .line 176
    .line 177
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->speedWaveView:Lcom/cyberzone/newAdmin/SpeedWaveView;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    .line 178
    .line 179
    :try_start_1
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    .line 180
    .line 181
    .line 182
    move-result-object v3

    .line 183
    invoke-virtual {v3}, Lcom/google/firebase/database/FirebaseDatabase;->getReference()Lcom/google/firebase/database/DatabaseReference;

    .line 184
    .line 185
    .line 186
    move-result-object v3

    .line 187
    const-string v4, "ScKit-bfd2b9e0262ff16d6970fb5f0052db44"

    .line 188
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v4

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 189
    invoke-virtual {v3, v4}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 190
    .line 191
    .line 192
    move-result-object v3

    .line 193
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->database:Lcom/google/firebase/database/DatabaseReference;

    .line 194
    .line 195
    if-nez v3, :cond_0

    .line 196
    .line 197
    const-string v9, "ScKit-2192e38900cba24b92e3c185c580ca56c7c5cce8f35e946c3391918b3a4719cc00db2109436bc23b7a8215cdd5913fb8"

    .line 198
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v9

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 199
    invoke-direct {v8, v9}, Lcom/cyberzone/newAdmin/MainActivity;->showErrorToast(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 200
    .line 201
    .line 202
    return-void

    .line 203
    :catch_0
    move-exception v9

    .line 204
    goto/16 :goto_7

    .line 205
    .line 206
    :cond_0
    :try_start_2
    new-instance v3, Lcom/cyberzone/newAdmin/DataUsageUtil;

    .line 207
    .line 208
    invoke-direct {v3}, Lcom/cyberzone/newAdmin/DataUsageUtil;-><init>()V

    .line 209
    .line 210
    .line 211
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->dataUsageUtil:Lcom/cyberzone/newAdmin/DataUsageUtil;

    .line 212
    .line 213
    new-instance v3, Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 214
    .line 215
    invoke-direct {v3, v8}, Lcom/cyberzone/newAdmin/SharedPrefManager;-><init>(Landroid/content/Context;)V

    .line 216
    .line 217
    .line 218
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 219
    .line 220
    new-instance v3, Lcom/cyberzone/newAdmin/LoadingUtil;

    .line 221
    .line 222
    invoke-direct {v3, v8}, Lcom/cyberzone/newAdmin/LoadingUtil;-><init>(Landroid/content/Context;)V

    .line 223
    .line 224
    .line 225
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->loading:Lcom/cyberzone/newAdmin/LoadingUtil;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_4

    .line 226
    .line 227
    :try_start_3
    sget-object v3, Lcom/cyberzone/newAdmin/Constants;->DB_URL:Ljava/lang/String;

    .line 228
    .line 229
    invoke-static {v3}, Lcom/cyberzone/newAdmin/HttpDatabaseUtil;->getInstance(Ljava/lang/String;)Lcom/cyberzone/newAdmin/HttpDatabaseUtil;

    .line 230
    .line 231
    .line 232
    move-result-object v3

    .line 233
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->databaseUtil:Lcom/cyberzone/newAdmin/HttpDatabaseUtil;

    .line 234
    .line 235
    if-nez v3, :cond_1

    .line 236
    .line 237
    const-string v3, "ScKit-9754aa1d6a3148baa0126165d6235fed8f2ba5baaa70ff6162e2c3c7837466a4918232d6f31884752a275a71d63e7654"

    .line 238
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v3

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 239
    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 240
    .line 241
    .line 242
    goto :goto_0

    .line 243
    :catch_1
    move-exception v3

    .line 244
    :try_start_4
    const-string v4, "ScKit-9754aa1d6a3148baa0126165d6235fed2c582c76cabfaa3316709c5f688b4fbefaf5c38cb19cec7624ac3658ddc656c7"

    .line 245
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v4

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 246
    invoke-static {v2, v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    .line 247
    .line 248
    .line 249
    :cond_1
    :goto_0
    :try_start_5
    new-instance v3, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;

    .line 250
    .line 251
    invoke-direct {v3}, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;-><init>()V

    .line 252
    .line 253
    .line 254
    iput-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->networkSpeedMonitor:Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;

    .line 255
    .line 256
    new-instance v4, Lcom/cyberzone/newAdmin/MainActivity$2;

    .line 257
    .line 258
    invoke-direct {v4, v8}, Lcom/cyberzone/newAdmin/MainActivity$2;-><init>(Lcom/cyberzone/newAdmin/MainActivity;)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v3, v4}, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->setSpeedListener(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$OnSpeedChangeListener;)V

    .line 262
    .line 263
    .line 264
    iget-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->networkSpeedMonitor:Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;

    .line 265
    .line 266
    invoke-virtual {v3}, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->startMonitoring()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    .line 267
    .line 268
    .line 269
    goto :goto_1

    .line 270
    :catch_2
    move-exception v3

    .line 271
    :try_start_6
    const-string v4, "ScKit-5b6909bdd3647113b54fc8e2af5519f1e15fb0ca1cfb367c4bcc5bbc5dcdbf23"

    .line 272
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v4

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 273
    invoke-static {v2, v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 274
    .line 275
    .line 276
    :goto_1
    invoke-static {v8}, Lcom/cyberzone/newAdmin/NetworkUtil;->isNetworkConnected(Landroid/content/Context;)Z

    .line 277
    .line 278
    .line 279
    move-result v3
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    .line 280
    if-eqz v3, :cond_2

    .line 281
    .line 282
    :try_start_7
    iget-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->dataUsageUtil:Lcom/cyberzone/newAdmin/DataUsageUtil;

    .line 283
    .line 284
    new-instance v4, Lcom/cyberzone/newAdmin/MainActivity$3;

    .line 285
    .line 286
    invoke-direct {v4, v8}, Lcom/cyberzone/newAdmin/MainActivity$3;-><init>(Lcom/cyberzone/newAdmin/MainActivity;)V

    .line 287
    .line 288
    .line 289
    const-wide/16 v5, 0x3e8

    .line 290
    .line 291
    invoke-virtual {v3, v4, v5, v6}, Lcom/cyberzone/newAdmin/DataUsageUtil;->startMonitoring(Lcom/cyberzone/newAdmin/DataUsageUtil$DataUsageCallback;J)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    .line 292
    .line 293
    .line 294
    goto :goto_2

    .line 295
    :catch_3
    move-exception v3

    .line 296
    :try_start_8
    const-string v4, "ScKit-f3001d85c663e13a4c06f08b0cad95f8676961964e0a5435913d3fa4d2abb7a9"

    .line 297
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v4

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 298
    invoke-static {v2, v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 299
    .line 300
    .line 301
    goto :goto_2

    .line 302
    :catch_4
    move-exception v9

    .line 303
    goto/16 :goto_8

    .line 304
    .line 305
    :cond_2
    const-string v3, "ScKit-57e9a7046bcb546ee1d847c21b19acf2fbae0ef80321144befa5706be270b3ba"

    .line 306
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v3

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 307
    const/4 v4, 0x0

    .line 308
    invoke-static {v8, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 309
    .line 310
    .line 311
    move-result-object v3

    .line 312
    invoke-virtual {v3}, Landroid/widget/Toast;->show()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_4

    .line 313
    .line 314
    .line 315
    :goto_2
    :try_start_9
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 316
    .line 317
    .line 318
    move-result v3

    .line 319
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 320
    .line 321
    .line 322
    move-result v4

    .line 323
    filled-new-array {v3, v4}, [I

    .line 324
    .line 325
    .line 326
    move-result-object v3

    .line 327
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    .line 328
    .line 329
    sget-object v5, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    .line 330
    .line 331
    invoke-direct {v4, v5, v3}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 332
    .line 333
    .line 334
    new-array v3, v9, [F

    .line 335
    .line 336
    fill-array-data v3, :array_0

    .line 337
    .line 338
    .line 339
    invoke-virtual {v4, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 340
    .line 341
    .line 342
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 343
    .line 344
    .line 345
    move-result v3

    .line 346
    const/4 v6, 0x1

    .line 347
    invoke-virtual {v4, v6, v3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 348
    .line 349
    .line 350
    iget-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->linear4:Landroid/widget/LinearLayout;

    .line 351
    .line 352
    const/high16 v7, 0x40a00000    # 5.0f

    .line 353
    .line 354
    if-eqz v3, :cond_3

    .line 355
    .line 356
    invoke-virtual {v3, v7}, Landroid/view/View;->setElevation(F)V

    .line 357
    .line 358
    .line 359
    iget-object v3, v8, Lcom/cyberzone/newAdmin/MainActivity;->linear4:Landroid/widget/LinearLayout;

    .line 360
    .line 361
    invoke-virtual {v3, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 362
    .line 363
    .line 364
    goto :goto_3

    .line 365
    :catch_5
    move-exception v9

    .line 366
    goto :goto_4

    .line 367
    :cond_3
    :goto_3
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 368
    .line 369
    .line 370
    move-result v3

    .line 371
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 372
    .line 373
    .line 374
    move-result v1

    .line 375
    filled-new-array {v3, v1}, [I

    .line 376
    .line 377
    .line 378
    move-result-object v1

    .line 379
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    .line 380
    .line 381
    invoke-direct {v3, v5, v1}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 382
    .line 383
    .line 384
    new-array v9, v9, [F

    .line 385
    .line 386
    fill-array-data v9, :array_1

    .line 387
    .line 388
    .line 389
    invoke-virtual {v3, v9}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 390
    .line 391
    .line 392
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 393
    .line 394
    .line 395
    move-result v9

    .line 396
    invoke-virtual {v3, v6, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 397
    .line 398
    .line 399
    iget-object v9, v8, Lcom/cyberzone/newAdmin/MainActivity;->linear3:Landroid/widget/LinearLayout;

    .line 400
    .line 401
    if-eqz v9, :cond_4

    .line 402
    .line 403
    invoke-virtual {v9, v7}, Landroid/view/View;->setElevation(F)V

    .line 404
    .line 405
    .line 406
    iget-object v9, v8, Lcom/cyberzone/newAdmin/MainActivity;->linear3:Landroid/widget/LinearLayout;

    .line 407
    .line 408
    invoke-virtual {v9, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_5

    .line 409
    .line 410
    .line 411
    goto :goto_5

    .line 412
    :goto_4
    :try_start_a
    const-string v0, "ScKit-bcbe44be9c17175a35bfd29cab79cf69a4bc1f66bad41d3e583c81b821ad4921"

    .line 413
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v0

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 414
    invoke-static {v2, v0, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_4

    .line 415
    .line 416
    .line 417
    :cond_4
    :goto_5
    :try_start_b
    new-instance v9, Lcom/cyberzone/newAdmin/MainActivity$Listview1Adapter;

    .line 418
    .line 419
    iget-object v0, v8, Lcom/cyberzone/newAdmin/MainActivity;->dataList:Ljava/util/ArrayList;

    .line 420
    .line 421
    invoke-direct {v9, v8, v0}, Lcom/cyberzone/newAdmin/MainActivity$Listview1Adapter;-><init>(Lcom/cyberzone/newAdmin/MainActivity;Ljava/util/ArrayList;)V

    .line 422
    .line 423
    .line 424
    iput-object v9, v8, Lcom/cyberzone/newAdmin/MainActivity;->listview1Adapter:Lcom/cyberzone/newAdmin/MainActivity$Listview1Adapter;

    .line 425
    .line 426
    iget-object v0, v8, Lcom/cyberzone/newAdmin/MainActivity;->listview1:Landroid/widget/ListView;

    .line 427
    .line 428
    if-eqz v0, :cond_5

    .line 429
    .line 430
    invoke-virtual {v0, v9}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 431
    .line 432
    .line 433
    iget-object v9, v8, Lcom/cyberzone/newAdmin/MainActivity;->listview1:Landroid/widget/ListView;

    .line 434
    .line 435
    invoke-virtual {v8}, Landroidx/appcompat/app/AppCompatActivity;->getResources()Landroid/content/res/Resources;

    .line 436
    .line 437
    .line 438
    move-result-object v0

    .line 439
    sget v1, Lcom/cyberzone/newAdmin/R$drawable;->devider:I

    .line 440
    .line 441
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 442
    .line 443
    .line 444
    move-result-object v0

    .line 445
    invoke-virtual {v9, v0}, Landroid/widget/ListView;->setDivider(Landroid/graphics/drawable/Drawable;)V

    .line 446
    .line 447
    .line 448
    iget-object v9, v8, Lcom/cyberzone/newAdmin/MainActivity;->listview1:Landroid/widget/ListView;

    .line 449
    .line 450
    const/16 v0, 0xa

    .line 451
    .line 452
    invoke-virtual {v9, v0}, Landroid/widget/ListView;->setDividerHeight(I)V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_6

    .line 453
    .line 454
    .line 455
    goto :goto_6

    .line 456
    :catch_6
    move-exception v9

    .line 457
    :try_start_c
    const-string v0, "ScKit-7a72281dfa9cf1350f023d6b1120d2545fb36d1edc38ec050084d98cdb47f93f"

    .line 458
    const-string v11, "ScKit-96a707ceb0ef2761"

    move-object/from16 v10, v0

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 459
    invoke-static {v2, v0, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 460
    .line 461
    .line 462
    :cond_5
    :goto_6
    invoke-direct {v8}, Lcom/cyberzone/newAdmin/MainActivity;->setupClickListeners()V

    .line 463
    .line 464
    .line 465
    invoke-direct {v8}, Lcom/cyberzone/newAdmin/MainActivity;->setupSearchListener()V

    .line 466
    .line 467
    .line 468
    invoke-direct {v8}, Lcom/cyberzone/newAdmin/MainActivity;->setupScrollListener()V

    .line 469
    .line 470
    .line 471
    invoke-direct {v8}, Lcom/cyberzone/newAdmin/MainActivity;->applyFilterUi()V

    .line 472
    .line 473
    .line 474
    goto :goto_9

    .line 475
    :goto_7
    const-string v0, "ScKit-6164943f599296a931202465ed2c6009f0116ac0a857e932e0951dbff50f0e99"

    .line 476
    const-string v11, "ScKit-b6811ed7000ea092"

    move-object/from16 v10, v0

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 477
    invoke-static {v2, v0, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 478
    .line 479
    .line 480
    const-string v9, "ScKit-5f3547cf0b8aecff2ed771dd7f865db2f617468659f56d0f30b392902528b1a8509f76f82d1d64ab6115c338aba1d8cd"

    .line 481
    const-string v11, "ScKit-b6811ed7000ea092"

    move-object/from16 v10, v9

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 482
    invoke-direct {v8, v9}, Lcom/cyberzone/newAdmin/MainActivity;->showErrorToast(Ljava/lang/String;)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_4

    .line 483
    .line 484
    .line 485
    return-void

    .line 486
    :goto_8
    const-string v0, "ScKit-afcfe3d8996f1eeb8873eb32d244533eb3a715d8dd98bb536c7e816ca9f76bbe"

    .line 487
    const-string v11, "ScKit-b6811ed7000ea092"

    move-object/from16 v10, v0

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 488
    invoke-static {v2, v0, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 489
    .line 490
    .line 491
    const-string v9, "ScKit-ce4d983f88ee5a63a32fc4b6652543c55c3dc2f17c85efe44e15edd30ce7089325ec1ea2a57417f8c3e001cfeb6c25ced6fdca26ae9782df31415e7d9c2260db"

    .line 492
    const-string v11, "ScKit-b6811ed7000ea092"

    move-object/from16 v10, v9

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 493
    invoke-direct {v8, v9}, Lcom/cyberzone/newAdmin/MainActivity;->showErrorToast(Ljava/lang/String;)V

    .line 494
    .line 495
    .line 496
    :goto_9
    return-void

    .line 497
    :array_0
    .array-data 4
        0x41c80000    # 25.0f
        0x41c80000    # 25.0f
        0x41c80000    # 25.0f
        0x41c80000    # 25.0f
        0x41c80000    # 25.0f
        0x41c80000    # 25.0f
        0x41c80000    # 25.0f
        0x41c80000    # 25.0f
    .end array-data

    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    :array_1
    .array-data 4
        0x40c00000    # 6.0f
        0x40c00000    # 6.0f
        0x40c00000    # 6.0f
        0x40c00000    # 6.0f
        0x40c00000    # 6.0f
        0x40c00000    # 6.0f
        0x40c00000    # 6.0f
        0x40c00000    # 6.0f
    .end array-data
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
.end method

.method private initializeLogic()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    invoke-static {v3}, Lcom/cyberzone/newAdmin/NetworkUtil;->isNetworkConnected(Landroid/content/Context;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->loading:Lcom/cyberzone/newAdmin/LoadingUtil;

    .line 8
    .line 9
    const-string v1, "ScKit-11ce120bbeab738fffbb1f75a4e3c4cad30e842171fb0f35876d7636856db7ee"

    .line 10
    const-string v5, "ScKit-b6811ed7000ea092"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 11
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/LoadingUtil;->showLoading(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    new-instance v0, Lcom/cyberzone/newAdmin/MainActivity$4;

    .line 15
    .line 16
    invoke-direct {v0, v3}, Lcom/cyberzone/newAdmin/MainActivity$4;-><init>(Lcom/cyberzone/newAdmin/MainActivity;)V

    .line 17
    .line 18
    .line 19
    iput-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->valueEventListener:Lcom/google/firebase/database/ValueEventListener;

    .line 20
    .line 21
    iget-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->database:Lcom/google/firebase/database/DatabaseReference;

    .line 22
    .line 23
    invoke-virtual {v1, v0}, Lcom/google/firebase/database/Query;->addValueEventListener(Lcom/google/firebase/database/ValueEventListener;)Lcom/google/firebase/database/ValueEventListener;

    .line 24
    .line 25
    .line 26
    invoke-direct {v3}, Lcom/cyberzone/newAdmin/MainActivity;->setupFirebaseFavouriteSync()V

    .line 27
    .line 28
    .line 29
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 30
    .line 31
    .line 32
    move-result-wide v0

    .line 33
    new-instance v2, Lcom/cyberzone/newAdmin/MainActivity$5;

    .line 34
    .line 35
    invoke-direct {v2, v3, v0, v1}, Lcom/cyberzone/newAdmin/MainActivity$5;-><init>(Lcom/cyberzone/newAdmin/MainActivity;J)V

    .line 36
    .line 37
    .line 38
    iput-object v2, v3, Lcom/cyberzone/newAdmin/MainActivity;->newDeviceChildListener:Lcom/google/firebase/database/ChildEventListener;

    .line 39
    .line 40
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->database:Lcom/google/firebase/database/DatabaseReference;

    .line 41
    .line 42
    invoke-virtual {v0, v2}, Lcom/google/firebase/database/Query;->addChildEventListener(Lcom/google/firebase/database/ChildEventListener;)Lcom/google/firebase/database/ChildEventListener;

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->loading:Lcom/cyberzone/newAdmin/LoadingUtil;

    .line 47
    .line 48
    invoke-virtual {v0}, Lcom/cyberzone/newAdmin/LoadingUtil;->dismissLoading()V

    .line 49
    .line 50
    .line 51
    const-string v0, "ScKit-450273d29312f2b1bc8ea829a62273fecab0593257b6aca800aac5e89129e85b"

    .line 52
    const-string v5, "ScKit-b6811ed7000ea092"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 53
    const/4 v1, 0x0

    .line 54
    invoke-static {v3, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 59
    .line 60
    .line 61
    :goto_0
    return-void
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method private static isDeviceConsideredOnline(Ljava/util/HashMap;)Z
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)Z"
        }
    .end annotation

    move-object/from16 v3, p0

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez v3, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    const-string v1, "ScKit-687426469eef1ddf1f0bece41a0f8a23"

    .line 6
    const-string v6, "ScKit-b6811ed7000ea092"

    move-object/from16 v5, v1

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 7
    invoke-virtual {v3, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    if-nez v3, :cond_1

    .line 12
    .line 13
    return v0

    .line 14
    :cond_1
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 15
    .line 16
    invoke-virtual {v1, v3}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/4 v2, 0x1

    .line 21
    if-eqz v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    instance-of v1, v3, Ljava/lang/String;

    .line 25
    .line 26
    if-eqz v1, :cond_5

    .line 27
    .line 28
    check-cast v3, Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    const-string v1, "ScKit-d0d6b97787b70e08b39df1ebe5465046"

    .line 35
    const-string v6, "ScKit-b6811ed7000ea092"

    move-object/from16 v5, v1

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 36
    invoke-virtual {v1, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-nez v1, :cond_3

    .line 41
    .line 42
    const-string v1, "ScKit-63a617e3abb5c2aa4d27e243f6019696"

    .line 43
    const-string v6, "ScKit-b6811ed7000ea092"

    move-object/from16 v5, v1

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 44
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    if-eqz v3, :cond_4

    .line 49
    .line 50
    :cond_3
    move v0, v2

    .line 51
    :cond_4
    return v0

    .line 52
    :cond_5
    instance-of v1, v3, Ljava/lang/Number;

    .line 53
    .line 54
    if-eqz v1, :cond_6

    .line 55
    .line 56
    check-cast v3, Ljava/lang/Number;

    .line 57
    .line 58
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    if-eqz v3, :cond_6

    .line 63
    .line 64
    move v0, v2

    .line 65
    :cond_6
    return v0
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
.end method

.method public static synthetic j(Lcom/cyberzone/newAdmin/MainActivity;Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 9

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move-wide/from16 v4, p4

    .line 1
    invoke-direct/range {v0 .. v5}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$setupClickListeners$3(Landroid/widget/AdapterView;Landroid/view/View;IJ)V

    return-void
.end method

.method public static synthetic k(Lcom/cyberzone/newAdmin/MainActivity;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$setupClickListeners$9(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic l(Lcom/google/firebase/database/DatabaseReference;Ljava/lang/Void;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$deleteClient$15(Lcom/google/firebase/database/DatabaseReference;Ljava/lang/Void;)V

    return-void
.end method

.method private static synthetic lambda$deleteClient$14(Lcom/google/android/gms/tasks/Task;)V
    .locals 6

    move-object/from16 v2, p0

    .line 1
    invoke-virtual {v2}, Lcom/google/android/gms/tasks/Task;->isSuccessful()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const-string v0, "ScKit-4797bf4cfa64f36eb71bf81475405acb3b7b3559a904be7dec5af3030a69bd98"

    .line 9
    const-string v5, "ScKit-b6811ed7000ea092"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 10
    invoke-virtual {v2}, Lcom/google/android/gms/tasks/Task;->getException()Ljava/lang/Exception;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const-string v1, "ScKit-faeb5073b5466c460944799174e2b08f"

    .line 15
    const-string v5, "ScKit-b6811ed7000ea092"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 16
    invoke-static {v1, v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 17
    .line 18
    .line 19
    :goto_0
    return-void
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private static synthetic lambda$deleteClient$15(Lcom/google/firebase/database/DatabaseReference;Ljava/lang/Void;)V
    .locals 6

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    .line 1
    invoke-virtual {v1}, Lcom/google/firebase/database/DatabaseReference;->removeValue()Lcom/google/android/gms/tasks/Task;

    .line 2
    .line 3
    .line 4
    move-result-object v1

    .line 5
    new-instance v2, Lo/n5;

    .line 6
    .line 7
    const/4 v0, 0x7

    .line 8
    invoke-direct {v2, v0}, Lo/n5;-><init>(I)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    .line 12
    .line 13
    .line 14
    return-void
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private static synthetic lambda$deleteClient$16(Ljava/lang/Exception;)V
    .locals 4

    move-object/from16 v0, p0

    return-void
.end method

.method private synthetic lambda$deleteInvalidClients$13(Ljava/util/HashMap;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->deleteClient(Ljava/util/HashMap;)V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private static synthetic lambda$rebuildDisplayListNow$0(Ljava/util/HashMap;Ljava/util/HashMap;)I
    .locals 10

    move-object/from16 v5, p0

    move-object/from16 v6, p1

    .line 1
    const-string v0, "ScKit-9e15a58000e1aca9baa1cb187926f152"

    .line 2
    const-string v9, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v8, v0

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    const-string v1, "ScKit-837c654ffa6c5fb5af324820dd190de1"

    .line 4
    const-string v9, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v8, v1

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    :try_start_0
    invoke-virtual {v5, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 9
    const-string v3, ""

    .line 10
    .line 11
    if-eqz v2, :cond_0

    .line 12
    .line 13
    :try_start_1
    invoke-virtual {v5, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    move-object v2, v3

    .line 23
    :goto_0
    invoke-virtual {v6, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    if-eqz v4, :cond_1

    .line 28
    .line 29
    invoke-virtual {v6, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    goto :goto_1

    .line 38
    :cond_1
    move-object v1, v3

    .line 39
    :goto_1
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    if-nez v4, :cond_2

    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 46
    .line 47
    .line 48
    move-result v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 49
    if-nez v4, :cond_2

    .line 50
    .line 51
    :try_start_2
    new-instance v5, Ljava/text/SimpleDateFormat;

    .line 52
    .line 53
    const-string v6, "ScKit-53d1233919b82020ee88784b5647d5c317ac3dafd5760c4339328de359bed7e6"

    .line 54
    const-string v9, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v8, v6

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 55
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-direct {v5, v6, v0}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v5, v2}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    invoke-virtual {v5, v1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    .line 67
    .line 68
    .line 69
    move-result-object v5

    .line 70
    invoke-virtual {v5, v6}, Ljava/util/Date;->compareTo(Ljava/util/Date;)I

    .line 71
    .line 72
    .line 73
    move-result v5
    :try_end_2
    .catch Ljava/text/ParseException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 74
    return v5

    .line 75
    :catch_0
    :try_start_3
    invoke-virtual {v1, v2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 76
    .line 77
    .line 78
    move-result v5

    .line 79
    return v5

    .line 80
    :cond_2
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    .line 81
    .line 82
    .line 83
    move-result v2

    .line 84
    if-nez v2, :cond_3

    .line 85
    .line 86
    const/4 v5, -0x1

    .line 87
    return v5

    .line 88
    :cond_3
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    if-nez v1, :cond_4

    .line 93
    .line 94
    const/4 v5, 0x1

    .line 95
    return v5

    .line 96
    :cond_4
    invoke-virtual {v5, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    if-eqz v1, :cond_5

    .line 101
    .line 102
    invoke-virtual {v5, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v5

    .line 110
    goto :goto_2

    .line 111
    :cond_5
    move-object v5, v3

    .line 112
    :goto_2
    invoke-virtual {v6, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    if-eqz v1, :cond_6

    .line 117
    .line 118
    invoke-virtual {v6, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v6

    .line 122
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    :cond_6
    invoke-virtual {v3, v5}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 127
    .line 128
    .line 129
    move-result v5
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 130
    return v5

    .line 131
    :catch_1
    const/4 v5, 0x0

    .line 132
    return v5
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
.end method

.method private synthetic lambda$rebuildDisplayListNow$1(Ljava/util/ArrayList;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    :try_start_0
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->dataList:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 4
    .line 5
    .line 6
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->dataList:Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 9
    .line 10
    .line 11
    iget-object v3, v2, Lcom/cyberzone/newAdmin/MainActivity;->listview1Adapter:Lcom/cyberzone/newAdmin/MainActivity$Listview1Adapter;

    .line 12
    .line 13
    if-eqz v3, :cond_0

    .line 14
    .line 15
    invoke-virtual {v3}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    .line 17
    .line 18
    goto :goto_0

    .line 19
    :catch_0
    move-exception v3

    .line 20
    const-string v0, "ScKit-249c116568d6f7ed1732fd2eb43637e6"

    .line 21
    const-string v5, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 22
    const-string v1, "ScKit-afb460d7c8dd89224b08e855c9b8706c35af12b0cf451bee0ff78d6bf659d0b5"

    .line 23
    const-string v5, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 24
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 25
    .line 26
    .line 27
    :cond_0
    :goto_0
    return-void
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$rebuildDisplayListNow$2()V
    .locals 15

    move-object/from16 v11, p0

    .line 1
    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, v11, Lcom/cyberzone/newAdmin/MainActivity;->currentSearch:Ljava/lang/String;

    .line 7
    .line 8
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    const/4 v3, 0x0

    .line 21
    if-nez v2, :cond_0

    .line 22
    .line 23
    new-instance v4, Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 26
    .line 27
    .line 28
    goto :goto_0

    .line 29
    :catch_0
    move-exception v0

    .line 30
    goto/16 :goto_4

    .line 31
    .line 32
    :cond_0
    move-object v4, v3

    .line 33
    :goto_0
    if-nez v2, :cond_1

    .line 34
    .line 35
    new-instance v3, Ljava/util/ArrayList;

    .line 36
    .line 37
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 38
    .line 39
    .line 40
    :cond_1
    iget-object v5, v11, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 41
    .line 42
    const-string v6, "ScKit-718e3952cbf23160714aaac302ebdf63399ced98c652686fb49655c7a3b93f15"

    .line 43
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v6

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 44
    invoke-virtual {v5, v6}, Lcom/cyberzone/newAdmin/SharedPrefManager;->getStringSet(Ljava/lang/String;)Ljava/util/Set;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    iget-object v6, v11, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 49
    .line 50
    monitor-enter v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 51
    :try_start_1
    new-instance v7, Ljava/util/ArrayList;

    .line 52
    .line 53
    iget-object v8, v11, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 54
    .line 55
    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 56
    .line 57
    .line 58
    monitor-exit v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 59
    :try_start_2
    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 60
    .line 61
    .line 62
    move-result-object v6

    .line 63
    :cond_2
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 64
    .line 65
    .line 66
    move-result v7

    .line 67
    if-eqz v7, :cond_a

    .line 68
    .line 69
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    check-cast v7, Ljava/util/HashMap;

    .line 74
    .line 75
    invoke-static {v7}, Lcom/cyberzone/newAdmin/MainActivity;->isDeviceConsideredOnline(Ljava/util/HashMap;)Z

    .line 76
    .line 77
    .line 78
    move-result v8

    .line 79
    iget-object v9, v11, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 80
    .line 81
    const-string v10, "ScKit-c8973d8c38e29480f0e06f3ee46b4032"

    .line 82
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v10

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 83
    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v9

    .line 87
    if-eqz v9, :cond_3

    .line 88
    .line 89
    if-nez v8, :cond_3

    .line 90
    .line 91
    goto :goto_1

    .line 92
    :cond_3
    iget-object v9, v11, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 93
    .line 94
    const-string v10, "ScKit-1eb3c7ad2f5bfe08a41b6f0a91c67fc0"

    .line 95
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v10

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 96
    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v9

    .line 100
    if-eqz v9, :cond_4

    .line 101
    .line 102
    if-eqz v8, :cond_4

    .line 103
    .line 104
    goto :goto_1

    .line 105
    :cond_4
    const-string v8, "ScKit-9e15a58000e1aca9baa1cb187926f152"

    .line 106
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v8

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 107
    invoke-virtual {v7, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v8

    .line 111
    if-eqz v8, :cond_5

    .line 112
    .line 113
    const-string v8, "ScKit-9e15a58000e1aca9baa1cb187926f152"

    .line 114
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v8

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 115
    invoke-virtual {v7, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v8

    .line 119
    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v8

    .line 123
    goto :goto_2

    .line 124
    :cond_5
    const-string v8, ""

    .line 125
    .line 126
    :goto_2
    iget-object v9, v11, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 127
    .line 128
    const-string v10, "ScKit-abb785f2283ef75941d1bf8ef38dc8eb"

    .line 129
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v10

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 130
    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v9

    .line 134
    if-eqz v9, :cond_6

    .line 135
    .line 136
    invoke-interface {v5, v8}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    move-result v8

    .line 140
    if-nez v8, :cond_6

    .line 141
    .line 142
    goto :goto_1

    .line 143
    :cond_6
    iget-object v8, v11, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 144
    .line 145
    const-string v9, "ScKit-a84b47fd72e12f4e1e17eb1d16c94885"

    .line 146
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v9

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 147
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    move-result v8

    .line 151
    if-eqz v8, :cond_7

    .line 152
    .line 153
    const-string v8, "ScKit-a84b47fd72e12f4e1e17eb1d16c94885"

    .line 154
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v8

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 155
    invoke-virtual {v7, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v8

    .line 159
    if-eqz v8, :cond_2

    .line 160
    .line 161
    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object v8

    .line 165
    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object v8

    .line 169
    const-string v9, "ScKit-d720988ff342693fa3e61d305e42575a"

    .line 170
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v9

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 171
    invoke-virtual {v8, v9}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 172
    .line 173
    .line 174
    move-result v9

    .line 175
    if-eqz v9, :cond_2

    .line 176
    .line 177
    const-string v9, "ScKit-e3638ea1e42c5dcb90c2a51e73457ceb"

    .line 178
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v9

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 179
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result v9

    .line 183
    if-nez v9, :cond_2

    .line 184
    .line 185
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    .line 186
    .line 187
    .line 188
    move-result v8

    .line 189
    if-nez v8, :cond_2

    .line 190
    .line 191
    :cond_7
    if-nez v2, :cond_9

    .line 192
    .line 193
    invoke-direct {v11, v7, v1}, Lcom/cyberzone/newAdmin/MainActivity;->matchesSearch(Ljava/util/HashMap;Ljava/lang/String;)Z

    .line 194
    .line 195
    .line 196
    move-result v8

    .line 197
    if-eqz v8, :cond_8

    .line 198
    .line 199
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 200
    .line 201
    .line 202
    goto/16 :goto_1

    .line 203
    .line 204
    :cond_8
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 205
    .line 206
    .line 207
    goto/16 :goto_1

    .line 208
    .line 209
    :cond_9
    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 210
    .line 211
    .line 212
    goto/16 :goto_1

    .line 213
    .line 214
    :cond_a
    if-nez v2, :cond_b

    .line 215
    .line 216
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 217
    .line 218
    .line 219
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 220
    .line 221
    .line 222
    goto :goto_3

    .line 223
    :cond_b
    new-instance v1, Lo/C7;

    .line 224
    .line 225
    const/4 v2, 0x2

    .line 226
    invoke-direct {v1, v2}, Lo/C7;-><init>(I)V

    .line 227
    .line 228
    .line 229
    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 230
    .line 231
    .line 232
    :goto_3
    iget-object v1, v11, Lcom/cyberzone/newAdmin/MainActivity;->uiHandler:Landroid/os/Handler;

    .line 233
    .line 234
    new-instance v2, Lo/U0;

    .line 235
    .line 236
    const/16 v3, 0x8

    .line 237
    .line 238
    invoke-direct {v2, v11, v3, v0}, Lo/U0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 239
    .line 240
    .line 241
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 242
    .line 243
    .line 244
    goto :goto_5

    .line 245
    :catchall_0
    move-exception v0

    .line 246
    :try_start_3
    monitor-exit v6
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 247
    :try_start_4
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 248
    :goto_4
    const-string v1, "ScKit-249c116568d6f7ed1732fd2eb43637e6"

    .line 249
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v1

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 250
    const-string v2, "ScKit-85ce1b0180ed1f09e008ffc6061c446e54cce4bd63641ccc7fdc9ac080372b18"

    .line 251
    const-string v13, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v12, v2

    invoke-static/range {v12 .. v13}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 252
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 253
    .line 254
    .line 255
    :goto_5
    return-void
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method private synthetic lambda$setupClickListeners$10(Landroid/view/View;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    :try_start_0
    iget-object v3, v2, Lcom/cyberzone/newAdmin/MainActivity;->edtSearch:Landroid/widget/EditText;

    .line 2
    .line 3
    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 4
    .line 5
    .line 6
    move-result-object v3

    .line 7
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    iput-object v3, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentSearch:Ljava/lang/String;

    .line 16
    .line 17
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->rebuildDisplayList()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 18
    .line 19
    .line 20
    goto :goto_0

    .line 21
    :catch_0
    move-exception v3

    .line 22
    const-string v0, "ScKit-249c116568d6f7ed1732fd2eb43637e6"

    .line 23
    const-string v5, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 24
    const-string v1, "ScKit-83d2424314db7065e71b4968b2420ca36f6309b5f294577212adce69701d0319"

    .line 25
    const-string v5, "ScKit-2bf5ba9987eee6c3"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 26
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 27
    .line 28
    .line 29
    :goto_0
    return-void
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$setupClickListeners$3(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 9

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move-wide/from16 v4, p4

    .line 1
    :try_start_0
    iget-object v1, v0, Lcom/cyberzone/newAdmin/MainActivity;->dataList:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Ljava/util/HashMap;

    .line 8
    .line 9
    const-string v2, "ScKit-b33b5c02718c97f78572f694ffcf1c31"

    .line 10
    const-string v7, "ScKit-023823c391eb21b8"

    move-object/from16 v6, v2

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 11
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Ljava/lang/String;

    .line 16
    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    new-instance v2, Landroid/content/Intent;

    .line 20
    .line 21
    const-class v3, Lcom/cyberzone/newAdmin/DetailsActivity;

    .line 22
    .line 23
    invoke-direct {v2, v0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 24
    .line 25
    .line 26
    const-string v3, "ScKit-0a38efd2e89a941662a1ea3d322e0c9b"

    .line 27
    const-string v7, "ScKit-023823c391eb21b8"

    move-object/from16 v6, v3

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 28
    invoke-virtual {v2, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 32
    .line 33
    .line 34
    goto :goto_1

    .line 35
    :catch_0
    move-exception v1

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    const-string v1, "ScKit-1c43e750ce6d00d34c878dbc2aaeb2e655787f58114fc06517599040bbea3dd8"

    .line 38
    const-string v7, "ScKit-023823c391eb21b8"

    move-object/from16 v6, v1

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 39
    const/4 v2, 0x0

    .line 40
    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 45
    .line 46
    .line 47
    goto :goto_1

    .line 48
    :goto_0
    const-string v2, "ScKit-eea0d3f10ad3e53ab055dbf5f69c547b"

    .line 49
    const-string v7, "ScKit-023823c391eb21b8"

    move-object/from16 v6, v2

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 50
    const-string v3, "ScKit-f08ef07de5620192efae841675c8364411751aa1264cb982e197423ac1883fc3"

    .line 51
    const-string v7, "ScKit-023823c391eb21b8"

    move-object/from16 v6, v3

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 52
    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 53
    .line 54
    .line 55
    :goto_1
    return-void
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
.end method

.method private synthetic lambda$setupClickListeners$4(Landroid/view/View;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    :try_start_0
    const-string v3, "ScKit-7429d6f34d28d274e3c9dc6199296500"

    .line 2
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3
    iput-object v3, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 4
    .line 5
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->applyFilterUi()V

    .line 6
    .line 7
    .line 8
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->rebuildDisplayList()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :catch_0
    move-exception v3

    .line 13
    const-string v0, "ScKit-eea0d3f10ad3e53ab055dbf5f69c547b"

    .line 14
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 15
    const-string v1, "ScKit-3e06cbf3978db9d2dd516f64b1e174f8ea936767ec862b2e360c9038840cb421"

    .line 16
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 17
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 18
    .line 19
    .line 20
    :goto_0
    return-void
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$setupClickListeners$5(Landroid/view/View;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    const-string v3, "ScKit-723fda91b7af2050b6dbda085c7ab830"

    .line 2
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3
    :try_start_0
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const-string v3, "ScKit-7429d6f34d28d274e3c9dc6199296500"

    .line 12
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 13
    goto :goto_0

    .line 14
    :catch_0
    move-exception v3

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    :goto_0
    iput-object v3, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 17
    .line 18
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->applyFilterUi()V

    .line 19
    .line 20
    .line 21
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->rebuildDisplayList()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    .line 23
    .line 24
    goto :goto_2

    .line 25
    :goto_1
    const-string v0, "ScKit-eea0d3f10ad3e53ab055dbf5f69c547b"

    .line 26
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 27
    const-string v1, "ScKit-d36a54a8ad0ec0a79c74b5364f64676ca67a78ac41c2ce5505b0c884ea402d3f"

    .line 28
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 29
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 30
    .line 31
    .line 32
    :goto_2
    return-void
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$setupClickListeners$6(Landroid/view/View;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    const-string v3, "ScKit-72c0bb994fa31eb656edf82cdd74881c"

    .line 2
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3
    :try_start_0
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const-string v3, "ScKit-7429d6f34d28d274e3c9dc6199296500"

    .line 12
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 13
    goto :goto_0

    .line 14
    :catch_0
    move-exception v3

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    :goto_0
    iput-object v3, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 17
    .line 18
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->applyFilterUi()V

    .line 19
    .line 20
    .line 21
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->rebuildDisplayList()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    .line 23
    .line 24
    goto :goto_2

    .line 25
    :goto_1
    const-string v0, "ScKit-eea0d3f10ad3e53ab055dbf5f69c547b"

    .line 26
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 27
    const-string v1, "ScKit-f64a3d143065440a689034666eb8ebbc7bc90de09dccfc5a14e04d350df62b20"

    .line 28
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 29
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 30
    .line 31
    .line 32
    :goto_2
    return-void
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$setupClickListeners$7(Landroid/view/View;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    const-string v3, "ScKit-5fb9897a298229be1f84e7993eb7d96a"

    .line 2
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3
    :try_start_0
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const-string v3, "ScKit-7429d6f34d28d274e3c9dc6199296500"

    .line 12
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 13
    goto :goto_0

    .line 14
    :catch_0
    move-exception v3

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    :goto_0
    iput-object v3, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 17
    .line 18
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->applyFilterUi()V

    .line 19
    .line 20
    .line 21
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->rebuildDisplayList()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    .line 23
    .line 24
    goto :goto_2

    .line 25
    :goto_1
    const-string v0, "ScKit-eea0d3f10ad3e53ab055dbf5f69c547b"

    .line 26
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 27
    const-string v1, "ScKit-4da2abe71f96548f85debc0a2f3ccd68315edc0d8b7c28caf20ee0fe7bf21f0a"

    .line 28
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 29
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 30
    .line 31
    .line 32
    :goto_2
    return-void
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$setupClickListeners$8(Landroid/view/View;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    :try_start_0
    const-string v3, "ScKit-95e21d032e1bd7062e426d151aebf631d1a4883cf81c4953f01804e34c302abc"

    .line 2
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-static {v2, v3, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 5
    .line 6
    .line 7
    move-result-object v3

    .line 8
    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    .line 9
    .line 10
    .line 11
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->refreshMainPage()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :catch_0
    move-exception v3

    .line 16
    const-string v0, "ScKit-eea0d3f10ad3e53ab055dbf5f69c547b"

    .line 17
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 18
    const-string v1, "ScKit-f47a70647a2a6225e40e35adc454ec7ecc6eb4bc896f7c2b0337d6a880b4d93c"

    .line 19
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 20
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 21
    .line 22
    .line 23
    :goto_0
    return-void
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$setupClickListeners$9(Landroid/view/View;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    const-string v3, "ScKit-4dae85dd588193635d57d89082f25fa3"

    .line 2
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3
    :try_start_0
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const-string v3, "ScKit-7429d6f34d28d274e3c9dc6199296500"

    .line 12
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 13
    goto :goto_0

    .line 14
    :catch_0
    move-exception v3

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    :goto_0
    iput-object v3, v2, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 17
    .line 18
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->applyFilterUi()V

    .line 19
    .line 20
    .line 21
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->rebuildDisplayList()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    .line 23
    .line 24
    goto :goto_2

    .line 25
    :goto_1
    const-string v0, "ScKit-eea0d3f10ad3e53ab055dbf5f69c547b"

    .line 26
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 27
    const-string v1, "ScKit-6a2377b5898e7455f053da61f91569974ecaea3d9cf70c1b878054f1457094f7"

    .line 28
    const-string v5, "ScKit-023823c391eb21b8"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 29
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 30
    .line 31
    .line 32
    :goto_2
    return-void
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$showDeviceInfoDialog$17(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)V
    .locals 11

    move-object/from16 v3, p0

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    move-object/from16 v6, p3

    move-object/from16 v7, p4

    .line 1
    const-string v7, "ScKit-66bbcb8a6559b3325acd225a68b03afe"

    .line 2
    const-string v9, "ScKit-023823c391eb21b8"

    move-object/from16 v8, v7

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 3
    const/4 v0, 0x0

    .line 4
    :try_start_0
    const-string v1, "ScKit-82a141326bdd3bf74bc36a60a52d5c88"

    .line 5
    const-string v9, "ScKit-023823c391eb21b8"

    move-object/from16 v8, v1

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 6
    invoke-virtual {v4, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    check-cast v1, Landroid/content/ClipboardManager;

    .line 11
    .line 12
    if-eqz v1, :cond_2

    .line 13
    .line 14
    const-string v2, "ScKit-b729ae55328f7844a72838a5e8cc0fc6"

    .line 15
    const-string v9, "ScKit-e429c29f2a9186e4"

    move-object/from16 v8, v2

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 16
    invoke-virtual {v6, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-nez v2, :cond_0

    .line 21
    .line 22
    const-string v2, "ScKit-6592c50ed47bf6244b55d23c6ddb4cde"

    .line 23
    const-string v9, "ScKit-e429c29f2a9186e4"

    move-object/from16 v8, v2

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 24
    invoke-virtual {v6, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 25
    .line 26
    .line 27
    move-result v6

    .line 28
    if-eqz v6, :cond_1

    .line 29
    .line 30
    :cond_0
    invoke-direct {v3, v5}, Lcom/cyberzone/newAdmin/MainActivity;->extractClean10DigitNumber(Ljava/lang/String;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v5

    .line 34
    :cond_1
    const-string v6, "ScKit-dd981510b7455ecc869c39e1102f8504"

    .line 35
    const-string v9, "ScKit-e429c29f2a9186e4"

    move-object/from16 v8, v6

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 36
    invoke-static {v6, v5}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    .line 37
    .line 38
    .line 39
    move-result-object v6

    .line 40
    invoke-virtual {v1, v6}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 41
    .line 42
    .line 43
    new-instance v6, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    invoke-static {v4, v5, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 56
    .line 57
    .line 58
    move-result-object v5

    .line 59
    invoke-virtual {v5}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :catch_0
    const-string v5, "ScKit-8098255caf892b11eb018e9c8ab1e5dd"

    .line 64
    const-string v9, "ScKit-e429c29f2a9186e4"

    move-object/from16 v8, v5

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 65
    invoke-static {v4, v5, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    .line 70
    .line 71
    .line 72
    :cond_2
    :goto_0
    return-void
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
.end method

.method private static synthetic lambda$showDeviceInfoDialog$18([Landroid/app/AlertDialog;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    const/4 v1, 0x0

    .line 2
    aget-object v0, v0, v1

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    .line 7
    .line 8
    .line 9
    :cond_0
    return-void
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private static synthetic lambda$showDeviceInfoDialog$19([Landroid/app/AlertDialog;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    const/4 v1, 0x0

    .line 2
    aget-object v0, v0, v1

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    .line 7
    .line 8
    .line 9
    :cond_0
    return-void
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private synthetic lambda$showUpdateLabelDialog$11(Lcom/google/android/gms/tasks/Task;)V
    .locals 6

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    .line 1
    invoke-virtual {v2}, Lcom/google/android/gms/tasks/Task;->isSuccessful()Z

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    const/4 v0, 0x0

    .line 6
    if-eqz v2, :cond_0

    .line 7
    .line 8
    const-string v2, "ScKit-c164b902fad50fd9763a37b2fd207f04"

    .line 9
    const-string v4, "ScKit-e429c29f2a9186e4"

    move-object/from16 v3, v2

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 10
    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const-string v2, "ScKit-d76dee2ef9447221303b1150f9c16ba852f87e1870daaf1ffe261a047da967c5"

    .line 19
    const-string v4, "ScKit-e429c29f2a9186e4"

    move-object/from16 v3, v2

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 20
    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 25
    .line 26
    .line 27
    :goto_0
    return-void
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private synthetic lambda$showUpdateLabelDialog$12(Landroid/widget/EditText;Ljava/lang/String;Landroid/content/DialogInterface;I)V
    .locals 8

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move/from16 v4, p4

    .line 1
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 2
    .line 3
    .line 4
    move-result-object v1

    .line 5
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    if-nez v3, :cond_0

    .line 18
    .line 19
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    const-string v4, "ScKit-8fa86ca2eab819ead804778d292c5c45"

    .line 24
    const-string v6, "ScKit-e429c29f2a9186e4"

    move-object/from16 v5, v4

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 25
    invoke-virtual {v3, v4}, Lcom/google/firebase/database/FirebaseDatabase;->getReference(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    invoke-virtual {v3, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    const-string v3, "ScKit-3ba8045dacd0832cf7bde935eac77825"

    .line 34
    const-string v6, "ScKit-e429c29f2a9186e4"

    move-object/from16 v5, v3

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 35
    invoke-virtual {v2, v3}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    invoke-virtual {v2, v1}, Lcom/google/firebase/database/DatabaseReference;->setValue(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    new-instance v2, Lo/V0;

    .line 44
    .line 45
    const/4 v3, 0x5

    .line 46
    invoke-direct {v2, v3, v0}, Lo/V0;-><init>(ILjava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    .line 50
    .line 51
    .line 52
    :cond_0
    return-void
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
.end method

.method private static synthetic lambda$toggleFirebaseFavourite$20(Ljava/lang/String;Lcom/google/android/gms/tasks/Task;)V
    .locals 6

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    .line 1
    invoke-virtual {v2}, Lcom/google/android/gms/tasks/Task;->isSuccessful()Z

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    const-string v0, "ScKit-0c1ff493a0b2ecd6887547826308f6c436df701cb894d68d22e1e8385748df0e0ca6a91334900fb4b61d4146e46ac3b3"

    .line 11
    const-string v5, "ScKit-e429c29f2a9186e4"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 12
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const-string v2, "ScKit-f03dc80f4b434945fc2a8b5fb1be0abf"

    .line 23
    const-string v5, "ScKit-e429c29f2a9186e4"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 24
    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 25
    .line 26
    .line 27
    :goto_0
    return-void
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private static synthetic lambda$toggleFirebaseFavourite$21(Ljava/lang/String;Lcom/google/android/gms/tasks/Task;)V
    .locals 6

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    .line 1
    invoke-virtual {v2}, Lcom/google/android/gms/tasks/Task;->isSuccessful()Z

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    const-string v0, "ScKit-af6fda1c4d4e17081b9e16b3092440c2b968f9eb7f7904793d7c4dc933f9b7c3ab38597fa25f6d7d16e2a510d6187877"

    .line 11
    const-string v5, "ScKit-e429c29f2a9186e4"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 12
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const-string v2, "ScKit-f03dc80f4b434945fc2a8b5fb1be0abf"

    .line 23
    const-string v5, "ScKit-e429c29f2a9186e4"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 24
    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 25
    .line 26
    .line 27
    :goto_0
    return-void
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method private loadKnownDevices()V
    .locals 6

    move-object/from16 v2, p0

    .line 1
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 2
    .line 3
    const-string v1, "ScKit-9d99b478bb46ba35a5dbe657eacc7e4f6bb96180105aec74b66ec371e9b164fa"

    .line 4
    const-string v4, "ScKit-e429c29f2a9186e4"

    move-object/from16 v3, v1

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/SharedPrefManager;->getStringSet(Ljava/lang/String;)Ljava/util/Set;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    iget-object v1, v2, Lcom/cyberzone/newAdmin/MainActivity;->knownDeviceIds:Ljava/util/Set;

    .line 18
    .line 19
    invoke-interface {v1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 20
    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    iput-boolean v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->isFirstFirebaseLoad:Z

    .line 24
    .line 25
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->knownDeviceIds:Ljava/util/Set;

    .line 26
    .line 27
    invoke-interface {v0}, Ljava/util/Set;->size()I

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    const/4 v0, 0x1

    .line 32
    iput-boolean v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->isFirstFirebaseLoad:Z

    .line 33
    .line 34
    :goto_0
    return-void
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public static synthetic m(Lcom/cyberzone/newAdmin/MainActivity;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$setupClickListeners$4(Landroid/view/View;)V

    return-void
.end method

.method private matchesSearch(Ljava/util/HashMap;Ljava/lang/String;)Z
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    move-object/from16 v10, p0

    move-object/from16 v11, p1

    move-object/from16 v12, p2

    .line 1
    const-string v8, "ScKit-d2ced5126c013ad27a24243a2a1e391f"

    .line 2
    const-string v14, "ScKit-e429c29f2a9186e4"

    move-object/from16 v13, v8

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 3
    const-string v9, "ScKit-1e8a2f69daa2941c2c245f4847a3f8955064b89177e8776df12ddcbf090250e1"

    .line 4
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v9

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 5
    const-string v0, "ScKit-89a72262781447ad6330ddf72f6d149b"

    .line 6
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v0

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 7
    const-string v1, "ScKit-5898e8bf1f9274c5808ee4f274fa5b79"

    .line 8
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v1

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 9
    const-string v2, "ScKit-5f3713983b59f564f8cfa46642744e6d"

    .line 10
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v2

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 11
    const-string v3, "ScKit-23716bc6973751cab5ddfd0cce743f8a"

    .line 12
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v3

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 13
    const-string v4, "ScKit-1aa6495ac269fbbec251597ded65293c"

    .line 14
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v4

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 15
    const-string v5, "ScKit-fe2917b0c446e1f8a6af6cb2034efb39"

    .line 16
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v5

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 17
    const-string v6, "ScKit-acaafcb27c9d0170ed55b3c98122bedb"

    .line 18
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v6

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 19
    const-string v7, "ScKit-758627bc1711d55613459faea63e02ff"

    .line 20
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v7

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 21
    filled-new-array/range {v0 .. v9}, [Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    const/4 v1, 0x0

    .line 26
    move v2, v1

    .line 27
    :goto_0
    const/4 v3, 0x1

    .line 28
    const/16 v4, 0xa

    .line 29
    .line 30
    if-ge v2, v4, :cond_1

    .line 31
    .line 32
    aget-object v4, v0, v2

    .line 33
    .line 34
    invoke-virtual {v11, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    if-eqz v4, :cond_0

    .line 39
    .line 40
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    invoke-virtual {v4, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    if-eqz v4, :cond_0

    .line 53
    .line 54
    return v3

    .line 55
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    invoke-static {v11}, Lcom/cyberzone/newAdmin/MainActivity;->isDeviceConsideredOnline(Ljava/util/HashMap;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    const-string v2, "ScKit-565f9c6bd3542639e8e1a972a34335f9"

    .line 63
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v2

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 64
    invoke-virtual {v2, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    if-eqz v2, :cond_2

    .line 69
    .line 70
    if-eqz v0, :cond_2

    .line 71
    .line 72
    return v3

    .line 73
    :cond_2
    const-string v2, "ScKit-a8d31b157a749ec3736b7fc5e26891a5"

    .line 74
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v2

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 75
    invoke-virtual {v2, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 76
    .line 77
    .line 78
    move-result v2

    .line 79
    if-eqz v2, :cond_3

    .line 80
    .line 81
    if-nez v0, :cond_3

    .line 82
    .line 83
    return v3

    .line 84
    :cond_3
    const-string v0, "ScKit-20cc5d6d83a58284c470ff55d29d28b9"

    .line 85
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v0

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 86
    invoke-virtual {v11, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v11

    .line 90
    instance-of v0, v11, Ljava/util/List;

    .line 91
    .line 92
    if-eqz v0, :cond_6

    .line 93
    .line 94
    check-cast v11, Ljava/util/List;

    .line 95
    .line 96
    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 97
    .line 98
    .line 99
    move-result-object v11

    .line 100
    :cond_4
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_6

    .line 105
    .line 106
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    instance-of v2, v0, Ljava/util/Map;

    .line 111
    .line 112
    if-eqz v2, :cond_4

    .line 113
    .line 114
    check-cast v0, Ljava/util/Map;

    .line 115
    .line 116
    const-string v2, "ScKit-306a1bc866d947389d1e613a74ab4e83"

    .line 117
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v2

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 118
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v2

    .line 122
    if-eqz v2, :cond_5

    .line 123
    .line 124
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v2

    .line 128
    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v2

    .line 132
    invoke-virtual {v2, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 133
    .line 134
    .line 135
    move-result v2

    .line 136
    if-eqz v2, :cond_5

    .line 137
    .line 138
    return v3

    .line 139
    :cond_5
    const-string v2, "ScKit-f83f2b0eafec942539c950051c25feaa"

    .line 140
    const-string v14, "ScKit-e47625c446fcc7a8"

    move-object/from16 v13, v2

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 141
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    if-eqz v0, :cond_4

    .line 146
    .line 147
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    invoke-virtual {v0, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 156
    .line 157
    .line 158
    move-result v0

    .line 159
    if-eqz v0, :cond_4

    .line 160
    .line 161
    return v3

    .line 162
    :cond_6
    return v1
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
.end method

.method private mcbcFuckYou()Z
    .locals 6

    move-object/from16 v2, p0

    .line 1
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 2
    .line 3
    const-string v1, "ScKit-e479a7e56e83c237392345bdb34c091a"

    .line 4
    const-string v4, "ScKit-e47625c446fcc7a8"

    move-object/from16 v3, v1

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/SharedPrefManager;->getB(Ljava/lang/String;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 12
    .line 13
    const-string v1, "ScKit-509b2e40497e84fee6307c83897eb44e"

    .line 14
    const-string v4, "ScKit-e47625c446fcc7a8"

    move-object/from16 v3, v1

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 15
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/SharedPrefManager;->getB(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    iget-object v0, v2, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 22
    .line 23
    const-string v1, "ScKit-74fc50a4c7425b056538aea1e33e82a0"

    .line 24
    const-string v4, "ScKit-e47625c446fcc7a8"

    move-object/from16 v3, v1

    invoke-static/range {v3 .. v4}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 25
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/SharedPrefManager;->getB(Ljava/lang/String;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    const/4 v0, 0x1

    .line 32
    return v0

    .line 33
    :cond_0
    const/4 v0, 0x0

    .line 34
    return v0
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public static synthetic n(Lcom/cyberzone/newAdmin/MainActivity;)V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$rebuildDisplayListNow$2()V

    return-void
.end method

.method public static synthetic o(Lcom/cyberzone/newAdmin/MainActivity;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$setupClickListeners$8(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic p(Lcom/cyberzone/newAdmin/MainActivity;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$setupClickListeners$7(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic q(Lcom/cyberzone/newAdmin/MainActivity;Ljava/util/HashMap;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$deleteInvalidClients$13(Ljava/util/HashMap;)V

    return-void
.end method

.method public static synthetic r(Lcom/cyberzone/newAdmin/MainActivity;Landroid/widget/EditText;Ljava/lang/String;Landroid/content/DialogInterface;I)V
    .locals 8

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move/from16 v4, p4

    .line 1
    invoke-direct {v0, v1, v2, v3, v4}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$showUpdateLabelDialog$12(Landroid/widget/EditText;Ljava/lang/String;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method private rebuildDisplayList()V
    .locals 8

    move-object/from16 v4, p0

    .line 1
    iget-object v0, v4, Lcom/cyberzone/newAdmin/MainActivity;->uiHandler:Landroid/os/Handler;

    .line 2
    .line 3
    iget-object v1, v4, Lcom/cyberzone/newAdmin/MainActivity;->rebuildRunnable:Ljava/lang/Runnable;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, v4, Lcom/cyberzone/newAdmin/MainActivity;->uiHandler:Landroid/os/Handler;

    .line 9
    .line 10
    iget-object v1, v4, Lcom/cyberzone/newAdmin/MainActivity;->rebuildRunnable:Ljava/lang/Runnable;

    .line 11
    .line 12
    const-wide/16 v2, 0xfa

    .line 13
    .line 14
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 15
    .line 16
    .line 17
    return-void
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private rebuildDisplayListNow()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    new-instance v0, Ljava/lang/Thread;

    .line 2
    .line 3
    new-instance v1, Lo/Od;

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    invoke-direct {v1, v3, v2}, Lo/Od;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 7
    .line 8
    .line 9
    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 13
    .line 14
    .line 15
    return-void
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private refreshMainPage()V
    .locals 9

    move-object/from16 v5, p0

    .line 1
    const-string v0, ""

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    :try_start_0
    iget-object v2, v5, Lcom/cyberzone/newAdmin/MainActivity;->database:Lcom/google/firebase/database/DatabaseReference;

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    iget-object v4, v5, Lcom/cyberzone/newAdmin/MainActivity;->valueEventListener:Lcom/google/firebase/database/ValueEventListener;

    .line 10
    .line 11
    if-eqz v4, :cond_0

    .line 12
    .line 13
    invoke-virtual {v2, v4}, Lcom/google/firebase/database/Query;->removeEventListener(Lcom/google/firebase/database/ValueEventListener;)V

    .line 14
    .line 15
    .line 16
    iput-object v3, v5, Lcom/cyberzone/newAdmin/MainActivity;->valueEventListener:Lcom/google/firebase/database/ValueEventListener;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :catch_0
    move-exception v0

    .line 20
    goto :goto_1

    .line 21
    :cond_0
    :goto_0
    iget-object v2, v5, Lcom/cyberzone/newAdmin/MainActivity;->database:Lcom/google/firebase/database/DatabaseReference;

    .line 22
    .line 23
    if-eqz v2, :cond_1

    .line 24
    .line 25
    iget-object v4, v5, Lcom/cyberzone/newAdmin/MainActivity;->newDeviceChildListener:Lcom/google/firebase/database/ChildEventListener;

    .line 26
    .line 27
    if-eqz v4, :cond_1

    .line 28
    .line 29
    invoke-virtual {v2, v4}, Lcom/google/firebase/database/Query;->removeEventListener(Lcom/google/firebase/database/ChildEventListener;)V

    .line 30
    .line 31
    .line 32
    iput-object v3, v5, Lcom/cyberzone/newAdmin/MainActivity;->newDeviceChildListener:Lcom/google/firebase/database/ChildEventListener;

    .line 33
    .line 34
    :cond_1
    iget-object v2, v5, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 37
    .line 38
    .line 39
    iget-object v2, v5, Lcom/cyberzone/newAdmin/MainActivity;->dataList:Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 42
    .line 43
    .line 44
    const-string v2, "ScKit-42de7b68b542f2df710067950f557dfb"

    .line 45
    const-string v7, "ScKit-e47625c446fcc7a8"

    move-object/from16 v6, v2

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 46
    iput-object v2, v5, Lcom/cyberzone/newAdmin/MainActivity;->currentFilter:Ljava/lang/String;

    .line 47
    .line 48
    iput-object v0, v5, Lcom/cyberzone/newAdmin/MainActivity;->currentSearch:Ljava/lang/String;

    .line 49
    .line 50
    iget-object v2, v5, Lcom/cyberzone/newAdmin/MainActivity;->edtSearch:Landroid/widget/EditText;

    .line 51
    .line 52
    if-eqz v2, :cond_2

    .line 53
    .line 54
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 55
    .line 56
    .line 57
    :cond_2
    invoke-direct {v5}, Lcom/cyberzone/newAdmin/MainActivity;->updateCounts()V

    .line 58
    .line 59
    .line 60
    invoke-direct {v5}, Lcom/cyberzone/newAdmin/MainActivity;->applyFilterUi()V

    .line 61
    .line 62
    .line 63
    iget-object v0, v5, Lcom/cyberzone/newAdmin/MainActivity;->listview1Adapter:Lcom/cyberzone/newAdmin/MainActivity$Listview1Adapter;

    .line 64
    .line 65
    if-eqz v0, :cond_3

    .line 66
    .line 67
    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 68
    .line 69
    .line 70
    :cond_3
    invoke-direct {v5}, Lcom/cyberzone/newAdmin/MainActivity;->initializeLogic()V

    .line 71
    .line 72
    .line 73
    const-string v0, "ScKit-7a6173a3849472a765186a0db434affe7078270312a7a8ab99d2c1cec72b7873"

    .line 74
    const-string v7, "ScKit-e47625c446fcc7a8"

    move-object/from16 v6, v0

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 75
    invoke-static {v5, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 80
    .line 81
    .line 82
    goto :goto_2

    .line 83
    :goto_1
    const-string v2, "ScKit-34d17225a8b158793b7fb7bd45ec5a1d"

    .line 84
    const-string v7, "ScKit-e47625c446fcc7a8"

    move-object/from16 v6, v2

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 85
    const-string v3, "ScKit-f2e4b2ab37e62c5b81e2679efcf518bf6fbd65014272d1b364233eebe0d97f6e"

    .line 86
    const-string v7, "ScKit-58ef60a7dd764310"

    move-object/from16 v6, v3

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 87
    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 88
    .line 89
    .line 90
    invoke-static {v5, v3, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 95
    .line 96
    .line 97
    :goto_2
    return-void
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method public static synthetic s(Ljava/util/HashMap;Ljava/util/HashMap;)I
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$rebuildDisplayListNow$0(Ljava/util/HashMap;Ljava/util/HashMap;)I

    move-result v0

    return v0
.end method

.method private saveKnownDevices()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 2
    .line 3
    const-string v1, "ScKit-24877aeb4a1da28d0817ef0c76672570914c95ec818eaeabd6787719aeb76764"

    .line 4
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    iget-object v2, v3, Lcom/cyberzone/newAdmin/MainActivity;->knownDeviceIds:Ljava/util/Set;

    .line 6
    .line 7
    invoke-virtual {v0, v1, v2}, Lcom/cyberzone/newAdmin/SharedPrefManager;->setStringSet(Ljava/lang/String;Ljava/util/Set;)V

    .line 8
    .line 9
    .line 10
    return-void
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private setupClickListeners()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    :try_start_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->listview1:Landroid/widget/ListView;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, Lo/Md;

    .line 6
    .line 7
    invoke-direct {v1, v3}, Lo/Md;-><init>(Lcom/cyberzone/newAdmin/MainActivity;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :catch_0
    move-exception v0

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    :goto_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->textview1:Landroid/widget/TextView;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    new-instance v1, Lo/Nd;

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    invoke-direct {v1, v3, v2}, Lo/Nd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 27
    .line 28
    .line 29
    :cond_1
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->txtOnlineCount:Landroid/widget/TextView;

    .line 30
    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    new-instance v1, Lo/Nd;

    .line 34
    .line 35
    const/4 v2, 0x1

    .line 36
    invoke-direct {v1, v3, v2}, Lo/Nd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 40
    .line 41
    .line 42
    :cond_2
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->txtOfflineCount:Landroid/widget/TextView;

    .line 43
    .line 44
    if-eqz v0, :cond_3

    .line 45
    .line 46
    new-instance v1, Lo/Nd;

    .line 47
    .line 48
    const/4 v2, 0x2

    .line 49
    invoke-direct {v1, v3, v2}, Lo/Nd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 53
    .line 54
    .line 55
    :cond_3
    new-instance v0, Lo/Nd;

    .line 56
    .line 57
    const/4 v1, 0x3

    .line 58
    invoke-direct {v0, v3, v1}, Lo/Nd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 59
    .line 60
    .line 61
    iget-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->linearFavBox:Landroid/widget/LinearLayout;

    .line 62
    .line 63
    if-eqz v1, :cond_4

    .line 64
    .line 65
    invoke-virtual {v1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 66
    .line 67
    .line 68
    :cond_4
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->imgRefreshMain:Landroid/widget/ImageView;

    .line 69
    .line 70
    if-eqz v0, :cond_5

    .line 71
    .line 72
    new-instance v1, Lo/Nd;

    .line 73
    .line 74
    const/4 v2, 0x4

    .line 75
    invoke-direct {v1, v3, v2}, Lo/Nd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 79
    .line 80
    .line 81
    :cond_5
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->txtUpiPinCount:Landroid/widget/TextView;

    .line 82
    .line 83
    if-eqz v0, :cond_6

    .line 84
    .line 85
    new-instance v1, Lo/Nd;

    .line 86
    .line 87
    const/4 v2, 0x5

    .line 88
    invoke-direct {v1, v3, v2}, Lo/Nd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 92
    .line 93
    .line 94
    :cond_6
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->imageview1:Landroid/widget/ImageView;

    .line 95
    .line 96
    if-eqz v0, :cond_7

    .line 97
    .line 98
    new-instance v1, Lo/Nd;

    .line 99
    .line 100
    const/4 v2, 0x6

    .line 101
    invoke-direct {v1, v3, v2}, Lo/Nd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;I)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 105
    .line 106
    .line 107
    goto :goto_2

    .line 108
    :goto_1
    const-string v1, "ScKit-2727b50d83008129aa612785323c6f48"

    .line 109
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 110
    const-string v2, "ScKit-6d49d8c95681da03d0007c77f07fad0fe70595b943c000d76e88d010732a887f914c95ec818eaeabd6787719aeb76764"

    .line 111
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 112
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 113
    .line 114
    .line 115
    :cond_7
    :goto_2
    return-void
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method private setupFirebaseFavouriteSync()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    :try_start_0
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lcom/google/firebase/database/FirebaseDatabase;->getReference()Lcom/google/firebase/database/DatabaseReference;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const-string v1, "ScKit-d21533266e6903d2d4c23e03f6bcb265"

    .line 10
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 11
    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, "ScKit-c2eccb4cb2046ac704c2299517782e82"

    .line 16
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 17
    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->favoritesRef:Lcom/google/firebase/database/DatabaseReference;

    .line 22
    .line 23
    new-instance v0, Lcom/cyberzone/newAdmin/MainActivity$9;

    .line 24
    .line 25
    invoke-direct {v0, v3}, Lcom/cyberzone/newAdmin/MainActivity$9;-><init>(Lcom/cyberzone/newAdmin/MainActivity;)V

    .line 26
    .line 27
    .line 28
    iput-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->favoritesListener:Lcom/google/firebase/database/ValueEventListener;

    .line 29
    .line 30
    iget-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->favoritesRef:Lcom/google/firebase/database/DatabaseReference;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Lcom/google/firebase/database/Query;->addValueEventListener(Lcom/google/firebase/database/ValueEventListener;)Lcom/google/firebase/database/ValueEventListener;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :catch_0
    move-exception v0

    .line 37
    const-string v1, "ScKit-2727b50d83008129aa612785323c6f48"

    .line 38
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 39
    const-string v2, "ScKit-6d49d8c95681da03d0007c77f07fad0fef8e4d5f71c075b600a12ee6a3ddf75c242db67c2473877a47ed5c5212855b40"

    .line 40
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 41
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 42
    .line 43
    .line 44
    :goto_0
    return-void
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private setupScrollListener()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    :try_start_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->listview1:Landroid/widget/ListView;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, Lcom/cyberzone/newAdmin/MainActivity$7;

    .line 6
    .line 7
    invoke-direct {v1, v3}, Lcom/cyberzone/newAdmin/MainActivity$7;-><init>(Lcom/cyberzone/newAdmin/MainActivity;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, v1}, Landroid/widget/AbsListView;->setOnScrollListener(Landroid/widget/AbsListView$OnScrollListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :catch_0
    move-exception v0

    .line 15
    const-string v1, "ScKit-2727b50d83008129aa612785323c6f48"

    .line 16
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 17
    const-string v2, "ScKit-6d49d8c95681da03d0007c77f07fad0fe08efd47fff3e874d76bd782e38067e4914c95ec818eaeabd6787719aeb76764"

    .line 18
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 19
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 20
    .line 21
    .line 22
    :cond_0
    :goto_0
    return-void
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private setupSearchListener()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    :try_start_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->edtSearch:Landroid/widget/EditText;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, Lcom/cyberzone/newAdmin/MainActivity$6;

    .line 6
    .line 7
    invoke-direct {v1, v3}, Lcom/cyberzone/newAdmin/MainActivity$6;-><init>(Lcom/cyberzone/newAdmin/MainActivity;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :catch_0
    move-exception v0

    .line 15
    const-string v1, "ScKit-2727b50d83008129aa612785323c6f48"

    .line 16
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 17
    const-string v2, "ScKit-6d49d8c95681da03d0007c77f07fad0fdb55858bb946bc893ed71889861f8c98914c95ec818eaeabd6787719aeb76764"

    .line 18
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 19
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 20
    .line 21
    .line 22
    :cond_0
    :goto_0
    return-void
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method private showErrorToast(Ljava/lang/String;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_0
    invoke-static {v2, v3, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 3
    .line 4
    .line 5
    move-result-object v3

    .line 6
    invoke-virtual {v3}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 7
    .line 8
    .line 9
    goto :goto_0

    .line 10
    :catch_0
    move-exception v3

    .line 11
    const-string v0, "ScKit-2727b50d83008129aa612785323c6f48"

    .line 12
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 13
    const-string v1, "ScKit-9aade93d6c15ad45a4eb5625305666c2705bd71d68eeb94b41bff26fa0b18264"

    .line 14
    const-string v5, "ScKit-58ef60a7dd764310"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 15
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 16
    .line 17
    .line 18
    :goto_0
    return-void
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method private showUpdateLabelDialog(Ljava/lang/String;Ljava/lang/String;)V
    .locals 9

    move-object/from16 v3, p0

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    .line 1
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 2
    .line 3
    invoke-direct {v0, v3}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    new-instance v1, Landroid/widget/EditText;

    .line 7
    .line 8
    invoke-direct {v1, v3}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 9
    .line 10
    .line 11
    const-string v2, "ScKit-a481b84ad6a0d09c4703a61521c57694"

    .line 12
    const-string v7, "ScKit-58ef60a7dd764310"

    move-object/from16 v6, v2

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 13
    invoke-virtual {v5, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-eqz v2, :cond_0

    .line 18
    .line 19
    const-string v5, ""

    .line 20
    .line 21
    :cond_0
    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 22
    .line 23
    .line 24
    const-string v5, "ScKit-fc7cbd84561ed729c810bd2c90d2d7dc"

    .line 25
    const-string v7, "ScKit-58ef60a7dd764310"

    move-object/from16 v6, v5

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 26
    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 27
    .line 28
    .line 29
    const-string v5, "ScKit-73663d6e08900186af36e486b291764f"

    .line 30
    const-string v7, "ScKit-58ef60a7dd764310"

    move-object/from16 v6, v5

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 31
    invoke-virtual {v0, v5}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 32
    .line 33
    .line 34
    move-result-object v5

    .line 35
    invoke-virtual {v5, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    new-instance v0, Lo/Pd;

    .line 40
    .line 41
    invoke-direct {v0, v3, v1, v4}, Lo/Pd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;Landroid/widget/EditText;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    const-string v4, "ScKit-2dacd1d86d9734926843df2d87f64029"

    .line 45
    const-string v7, "ScKit-58ef60a7dd764310"

    move-object/from16 v6, v4

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 46
    invoke-virtual {v5, v4, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    const-string v5, "ScKit-5f2f335fae3820f91c89f58f14206cab"

    .line 51
    const-string v7, "ScKit-58ef60a7dd764310"

    move-object/from16 v6, v5

    invoke-static/range {v6 .. v7}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 52
    const/4 v0, 0x0

    .line 53
    invoke-virtual {v4, v5, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    invoke-virtual {v4}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 58
    .line 59
    .line 60
    return-void
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method public static synthetic t([Landroid/app/AlertDialog;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$showDeviceInfoDialog$19([Landroid/app/AlertDialog;Landroid/view/View;)V

    return-void
.end method

.method private toggleFirebaseFavourite(Ljava/lang/String;Z)V
    .locals 8

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move/from16 v4, p2

    .line 1
    if-eqz v3, :cond_2

    .line 2
    .line 3
    :try_start_0
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    goto :goto_1

    .line 10
    :cond_0
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Lcom/google/firebase/database/FirebaseDatabase;->getReference()Lcom/google/firebase/database/DatabaseReference;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const-string v1, "ScKit-d21533266e6903d2d4c23e03f6bcb265"

    .line 19
    const-string v6, "ScKit-58ef60a7dd764310"

    move-object/from16 v5, v1

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 20
    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const-string v1, "ScKit-c2eccb4cb2046ac704c2299517782e82"

    .line 25
    const-string v6, "ScKit-58ef60a7dd764310"

    move-object/from16 v5, v1

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 26
    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v0, v3}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    if-eqz v4, :cond_1

    .line 35
    .line 36
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 37
    .line 38
    invoke-virtual {v0, v4}, Lcom/google/firebase/database/DatabaseReference;->setValue(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    new-instance v0, Lo/R3;

    .line 43
    .line 44
    const/4 v1, 0x2

    .line 45
    invoke-direct {v0, v3, v1}, Lo/R3;-><init>(Ljava/lang/String;I)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v4, v0}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    .line 49
    .line 50
    .line 51
    goto :goto_1

    .line 52
    :catch_0
    move-exception v3

    .line 53
    goto :goto_0

    .line 54
    :cond_1
    invoke-virtual {v0}, Lcom/google/firebase/database/DatabaseReference;->removeValue()Lcom/google/android/gms/tasks/Task;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    new-instance v0, Lo/R3;

    .line 59
    .line 60
    const/4 v1, 0x3

    .line 61
    invoke-direct {v0, v3, v1}, Lo/R3;-><init>(Ljava/lang/String;I)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v4, v0}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 65
    .line 66
    .line 67
    goto :goto_1

    .line 68
    :goto_0
    const-string v4, "ScKit-2727b50d83008129aa612785323c6f48"

    .line 69
    const-string v6, "ScKit-58ef60a7dd764310"

    move-object/from16 v5, v4

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 70
    const-string v0, "ScKit-601ccc838f74754eb09340648b5186f1f54a06e0f22c99aa6234807d371c988deec4d19557a27e5879785b3da5cb272b"

    .line 71
    const-string v6, "ScKit-58ef60a7dd764310"

    move-object/from16 v5, v0

    invoke-static/range {v5 .. v6}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 72
    invoke-static {v4, v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 73
    .line 74
    .line 75
    :cond_2
    :goto_1
    return-void
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
.end method

.method public static synthetic u(Lcom/cyberzone/newAdmin/MainActivity;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$setupClickListeners$5(Landroid/view/View;)V

    return-void
.end method

.method private updateCounts()V
    .locals 13

    move-object/from16 v9, p0

    .line 1
    iget-object v0, v9, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 2
    .line 3
    const-string v1, "ScKit-ab03b52717f8d0c0c562e7869032701abc8ec41003a9c15ce1286c0d30cdfc86"

    .line 4
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v1

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/SharedPrefManager;->getStringSet(Ljava/lang/String;)Ljava/util/Set;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, v9, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/4 v2, 0x0

    .line 16
    move v3, v2

    .line 17
    move v4, v3

    .line 18
    move v5, v4

    .line 19
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v6

    .line 23
    if-eqz v6, :cond_4

    .line 24
    .line 25
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v6

    .line 29
    check-cast v6, Ljava/util/HashMap;

    .line 30
    .line 31
    invoke-static {v6}, Lcom/cyberzone/newAdmin/MainActivity;->isDeviceConsideredOnline(Ljava/util/HashMap;)Z

    .line 32
    .line 33
    .line 34
    move-result v7

    .line 35
    if-eqz v7, :cond_1

    .line 36
    .line 37
    add-int/lit8 v2, v2, 0x1

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 41
    .line 42
    :goto_1
    const-string v7, "ScKit-2b1cdaeb49b94a1e367f59ad99d022bd"

    .line 43
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v7

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 44
    invoke-virtual {v6, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v8

    .line 48
    if-eqz v8, :cond_2

    .line 49
    .line 50
    invoke-virtual {v6, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v7

    .line 54
    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v7

    .line 58
    goto :goto_2

    .line 59
    :cond_2
    const-string v7, ""

    .line 60
    .line 61
    :goto_2
    invoke-interface {v0, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v7

    .line 65
    if-eqz v7, :cond_3

    .line 66
    .line 67
    add-int/lit8 v4, v4, 0x1

    .line 68
    .line 69
    :cond_3
    const-string v7, "ScKit-fe0a3c40295dd913248109f6ace4da8a"

    .line 70
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v7

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 71
    invoke-virtual {v6, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    if-eqz v6, :cond_0

    .line 76
    .line 77
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v6

    .line 81
    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v6

    .line 85
    const-string v7, "ScKit-20c3c3117c09fb1801d698767d9bca4d"

    .line 86
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v7

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 87
    invoke-virtual {v6, v7}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 88
    .line 89
    .line 90
    move-result v7

    .line 91
    if-eqz v7, :cond_0

    .line 92
    .line 93
    const-string v7, "ScKit-e669008ccd938a63fb820474798fbce5"

    .line 94
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v7

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 95
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v7

    .line 99
    if-nez v7, :cond_0

    .line 100
    .line 101
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    .line 102
    .line 103
    .line 104
    move-result v6

    .line 105
    if-nez v6, :cond_0

    .line 106
    .line 107
    add-int/lit8 v5, v5, 0x1

    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_4
    iget-object v0, v9, Lcom/cyberzone/newAdmin/MainActivity;->txtOnlineCount:Landroid/widget/TextView;

    .line 111
    .line 112
    if-eqz v0, :cond_5

    .line 113
    .line 114
    new-instance v1, Ljava/lang/StringBuilder;

    .line 115
    .line 116
    const-string v6, "ScKit-6654177d6e0448bb7f26e23e258ecdc2"

    .line 117
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v6

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 118
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 129
    .line 130
    .line 131
    :cond_5
    iget-object v0, v9, Lcom/cyberzone/newAdmin/MainActivity;->txtOfflineCount:Landroid/widget/TextView;

    .line 132
    .line 133
    if-eqz v0, :cond_6

    .line 134
    .line 135
    new-instance v1, Ljava/lang/StringBuilder;

    .line 136
    .line 137
    const-string v2, "ScKit-882b3cace41eb81fefbbeee02c318389"

    .line 138
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v2

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 139
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 150
    .line 151
    .line 152
    :cond_6
    iget-object v0, v9, Lcom/cyberzone/newAdmin/MainActivity;->txtFavCount:Landroid/widget/TextView;

    .line 153
    .line 154
    if-eqz v0, :cond_7

    .line 155
    .line 156
    new-instance v1, Ljava/lang/StringBuilder;

    .line 157
    .line 158
    const-string v2, "ScKit-cb49a36138017ac9074183e8ffae14c7"

    .line 159
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v2

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 160
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 164
    .line 165
    .line 166
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v1

    .line 170
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 171
    .line 172
    .line 173
    :cond_7
    iget-object v0, v9, Lcom/cyberzone/newAdmin/MainActivity;->txtUpiPinCount:Landroid/widget/TextView;

    .line 174
    .line 175
    if-eqz v0, :cond_8

    .line 176
    .line 177
    new-instance v1, Ljava/lang/StringBuilder;

    .line 178
    .line 179
    const-string v2, "ScKit-258ad5cf1d1bdb61ffb03e413d1f12af"

    .line 180
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v2

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 181
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 185
    .line 186
    .line 187
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 192
    .line 193
    .line 194
    :cond_8
    iget-object v0, v9, Lcom/cyberzone/newAdmin/MainActivity;->textview1:Landroid/widget/TextView;

    .line 195
    .line 196
    new-instance v1, Ljava/lang/StringBuilder;

    .line 197
    .line 198
    const-string v2, "ScKit-5eeeac63c71b71533c211e422b47732c"

    .line 199
    const-string v11, "ScKit-819eb03ceb119e51"

    move-object/from16 v10, v2

    invoke-static/range {v10 .. v11}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 200
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 201
    .line 202
    .line 203
    iget-object v2, v9, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 204
    .line 205
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 206
    .line 207
    .line 208
    move-result v2

    .line 209
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 217
    .line 218
    .line 219
    return-void
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method public static synthetic v(Lcom/cyberzone/newAdmin/MainActivity;)V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-direct {v0}, Lcom/cyberzone/newAdmin/MainActivity;->rebuildDisplayListNow()V

    return-void
.end method

.method public static synthetic w([Landroid/app/AlertDialog;Landroid/view/View;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$showDeviceInfoDialog$18([Landroid/app/AlertDialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic x(Lcom/cyberzone/newAdmin/MainActivity;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)V
    .locals 8

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    .line 1
    invoke-direct {v0, v1, v2, v3, v4}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$showDeviceInfoDialog$17(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic y(Lcom/cyberzone/newAdmin/MainActivity;Ljava/util/ArrayList;)V
    .locals 5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 1
    invoke-direct {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$rebuildDisplayListNow$1(Ljava/util/ArrayList;)V

    return-void
.end method

.method public static synthetic z(Ljava/lang/Exception;)V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-static {v0}, Lcom/cyberzone/newAdmin/MainActivity;->lambda$deleteClient$16(Ljava/lang/Exception;)V

    return-void
.end method

.method private ж()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    invoke-direct {v3}, Lcom/cyberzone/newAdmin/MainActivity;->mcbcFuckYou()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 8
    .line 9
    const-string v1, "ScKit-f652c4351054820203d622ea05a65e03"

    .line 10
    const-string v5, "ScKit-819eb03ceb119e51"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 11
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/SharedPrefManager;->getB(Ljava/lang/String;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 18
    .line 19
    const-string v1, "ScKit-7b871ec1694887b8f1b3fe88a87cd186"

    .line 20
    const-string v5, "ScKit-819eb03ceb119e51"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/SharedPrefManager;->get(Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    const-string v2, ""

    .line 26
    .line 27
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_1

    .line 32
    .line 33
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Lcom/cyberzone/newAdmin/SharedPrefManager;->get(Ljava/lang/String;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-nez v0, :cond_0

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    invoke-direct {v3}, Lcom/cyberzone/newAdmin/MainActivity;->expired()V

    .line 43
    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_1
    :goto_0
    invoke-virtual {v3}, Lcom/cyberzone/newAdmin/MainActivity;->_AlertLogin()V

    .line 47
    .line 48
    .line 49
    :goto_1
    return-void
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method


# virtual methods
.method public _AlertLogin()V
    .locals 16

    move-object/from16 v12, p0

    .line 1
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 2
    .line 3
    invoke-direct {v0, v12}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v12}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    sget v2, Lcom/cyberzone/newAdmin/R$layout;->admin_login:I

    .line 15
    .line 16
    const/4 v3, 0x0

    .line 17
    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog;->setView(Landroid/view/View;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    .line 29
    .line 30
    invoke-direct {v3}, Landroid/graphics/drawable/ColorDrawable;-><init>()V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v2, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 34
    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    const/4 v4, 0x4

    .line 45
    invoke-virtual {v3, v4}, Landroid/view/Window;->setSoftInputMode(I)V

    .line 46
    .line 47
    .line 48
    sget v3, Lcom/cyberzone/newAdmin/R$id;->linear1:I

    .line 49
    .line 50
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    check-cast v3, Landroid/widget/LinearLayout;

    .line 55
    .line 56
    sget v4, Lcom/cyberzone/newAdmin/R$id;->edtPassword:I

    .line 57
    .line 58
    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    check-cast v4, Landroid/widget/EditText;

    .line 63
    .line 64
    sget v5, Lcom/cyberzone/newAdmin/R$id;->btnLogin:I

    .line 65
    .line 66
    invoke-virtual {v1, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    check-cast v1, Landroid/widget/Button;

    .line 71
    .line 72
    const-string v5, "ScKit-cbf1976f907e1e8964b6deed60c1f20b"

    .line 73
    const-string v14, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v13, v5

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 74
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 75
    .line 76
    .line 77
    move-result v6

    .line 78
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 79
    .line 80
    .line 81
    move-result v5

    .line 82
    filled-new-array {v6, v5}, [I

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    .line 87
    .line 88
    sget-object v7, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    .line 89
    .line 90
    invoke-direct {v6, v7, v5}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 91
    .line 92
    .line 93
    const/16 v5, 0x8

    .line 94
    .line 95
    new-array v8, v5, [F

    .line 96
    .line 97
    fill-array-data v8, :array_0

    .line 98
    .line 99
    .line 100
    invoke-virtual {v6, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 101
    .line 102
    .line 103
    const-string v8, "ScKit-f27a3d904104e959976c083309f91517"

    .line 104
    const-string v14, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v13, v8

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 105
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 106
    .line 107
    .line 108
    move-result v9

    .line 109
    const/4 v10, 0x2

    .line 110
    invoke-virtual {v6, v10, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 111
    .line 112
    .line 113
    const/high16 v9, 0x40a00000    # 5.0f

    .line 114
    .line 115
    invoke-virtual {v4, v9}, Landroid/view/View;->setElevation(F)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v4, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 119
    .line 120
    .line 121
    const-string v6, "ScKit-19984df3a107dcf3c80b2c59402daade"

    .line 122
    const-string v14, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v13, v6

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 123
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 124
    .line 125
    .line 126
    move-result v11

    .line 127
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 128
    .line 129
    .line 130
    move-result v6

    .line 131
    filled-new-array {v11, v6}, [I

    .line 132
    .line 133
    .line 134
    move-result-object v6

    .line 135
    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    .line 136
    .line 137
    invoke-direct {v11, v7, v6}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 138
    .line 139
    .line 140
    new-array v6, v5, [F

    .line 141
    .line 142
    fill-array-data v6, :array_1

    .line 143
    .line 144
    .line 145
    invoke-virtual {v11, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 146
    .line 147
    .line 148
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 149
    .line 150
    .line 151
    move-result v6

    .line 152
    invoke-virtual {v11, v10, v6}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v1, v9}, Landroid/view/View;->setElevation(F)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v1, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 159
    .line 160
    .line 161
    const-string v6, "ScKit-ef27c89c1c1072784a8ec64604e79064"

    .line 162
    const-string v14, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v13, v6

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 163
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 164
    .line 165
    .line 166
    move-result v10

    .line 167
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 168
    .line 169
    .line 170
    move-result v6

    .line 171
    filled-new-array {v10, v6}, [I

    .line 172
    .line 173
    .line 174
    move-result-object v6

    .line 175
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    .line 176
    .line 177
    invoke-direct {v10, v7, v6}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 178
    .line 179
    .line 180
    new-array v5, v5, [F

    .line 181
    .line 182
    fill-array-data v5, :array_2

    .line 183
    .line 184
    .line 185
    invoke-virtual {v10, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 186
    .line 187
    .line 188
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 189
    .line 190
    .line 191
    move-result v5

    .line 192
    invoke-virtual {v10, v2, v5}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v3, v9}, Landroid/view/View;->setElevation(F)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v3, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 199
    .line 200
    .line 201
    iget-object v3, v12, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 202
    .line 203
    const-string v5, "ScKit-1dff96f4bbbcfeab74221796a19e2cf4"

    .line 204
    const-string v14, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v13, v5

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 205
    invoke-virtual {v3, v5, v2}, Lcom/cyberzone/newAdmin/SharedPrefManager;->setB(Ljava/lang/String;Z)V

    .line 206
    .line 207
    .line 208
    iget-object v3, v12, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 209
    .line 210
    const-string v5, "ScKit-9bf32a3a514538e161b9e7aac1bcd076"

    .line 211
    const-string v14, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v13, v5

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 212
    invoke-virtual {v3, v5, v2}, Lcom/cyberzone/newAdmin/SharedPrefManager;->setB(Ljava/lang/String;Z)V

    .line 213
    .line 214
    .line 215
    iget-object v3, v12, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 216
    .line 217
    const-string v5, "ScKit-60aee4ce9c1ef0b3b934935a0c5389f7"

    .line 218
    const-string v14, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v13, v5

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 219
    invoke-virtual {v3, v5, v2}, Lcom/cyberzone/newAdmin/SharedPrefManager;->setB(Ljava/lang/String;Z)V

    .line 220
    .line 221
    .line 222
    iget-object v3, v12, Lcom/cyberzone/newAdmin/MainActivity;->prefs:Lcom/cyberzone/newAdmin/SharedPrefManager;

    .line 223
    .line 224
    const-string v5, "ScKit-274dee7c857ec6b65b5f2b0ceb4ce84b"

    .line 225
    const-string v14, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v13, v5

    invoke-static/range {v13 .. v14}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 226
    invoke-virtual {v3, v5, v2}, Lcom/cyberzone/newAdmin/SharedPrefManager;->setB(Ljava/lang/String;Z)V

    .line 227
    .line 228
    .line 229
    new-instance v2, Lcom/cyberzone/newAdmin/MainActivity$8;

    .line 230
    .line 231
    invoke-direct {v2, v12, v4, v0}, Lcom/cyberzone/newAdmin/MainActivity$8;-><init>(Lcom/cyberzone/newAdmin/MainActivity;Landroid/widget/EditText;Landroid/app/AlertDialog;)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 235
    .line 236
    .line 237
    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    .line 238
    .line 239
    .line 240
    return-void

    .line 241
    :array_0
    .array-data 4
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
    .end array-data

    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    :array_1
    .array-data 4
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
    .end array-data

    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    :array_2
    .array-data 4
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
        0x41400000    # 12.0f
    .end array-data
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 7

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    .line 1
    invoke-super {v2, v3}, Landroidx/fragment/app/FragmentActivity;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lcom/cyberzone/newAdmin/MainActivity$1;

    .line 5
    .line 6
    invoke-direct {v0, v2}, Lcom/cyberzone/newAdmin/MainActivity$1;-><init>(Lcom/cyberzone/newAdmin/MainActivity;)V

    .line 7
    .line 8
    .line 9
    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    .line 10
    .line 11
    .line 12
    :try_start_0
    sget v0, Lcom/cyberzone/newAdmin/R$layout;->activity_main:I

    .line 13
    .line 14
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/AppCompatActivity;->setContentView(I)V

    .line 15
    .line 16
    .line 17
    invoke-static {v2}, Lcom/cyberzone/newAdmin/SystemIntegrityService;->checkTampering(Landroid/content/Context;)V

    .line 18
    .line 19
    .line 20
    invoke-direct {v2, v3}, Lcom/cyberzone/newAdmin/MainActivity;->initialize(Landroid/os/Bundle;)V

    .line 21
    .line 22
    .line 23
    invoke-static {v2}, Lcom/google/firebase/FirebaseApp;->initializeApp(Landroid/content/Context;)Lcom/google/firebase/FirebaseApp;

    .line 24
    .line 25
    .line 26
    invoke-direct {v2}, Lcom/cyberzone/newAdmin/MainActivity;->initializeLogic()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :catch_0
    move-exception v3

    .line 31
    const-string v0, "ScKit-4d8219da144394a5a62018824ca9cc82"

    .line 32
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 33
    const-string v1, "ScKit-a5f9beed5ef42f4534e31175d08de842e9074d1892b988f20780037b73d0291f"

    .line 34
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 35
    invoke-static {v0, v1, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 36
    .line 37
    .line 38
    const-string v3, "ScKit-c32bf9531e1329f7a8ce515d72f888d29ade730ba865d1fb82b222e2bcaae22b1fc51484bbd4668b481242aeec5af16b"

    .line 39
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v3

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 40
    invoke-direct {v2, v3}, Lcom/cyberzone/newAdmin/MainActivity;->showErrorToast(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    :goto_0
    return-void
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public onDestroy()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    :try_start_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->networkSpeedMonitor:Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->stopMonitoring()V

    .line 7
    .line 8
    .line 9
    iput-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->networkSpeedMonitor:Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :catch_0
    move-exception v0

    .line 13
    goto :goto_1

    .line 14
    :cond_0
    :goto_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->dataUsageUtil:Lcom/cyberzone/newAdmin/DataUsageUtil;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-virtual {v0}, Lcom/cyberzone/newAdmin/DataUsageUtil;->stopMonitoring()V

    .line 19
    .line 20
    .line 21
    iput-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->dataUsageUtil:Lcom/cyberzone/newAdmin/DataUsageUtil;

    .line 22
    .line 23
    :cond_1
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->database:Lcom/google/firebase/database/DatabaseReference;

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    iget-object v2, v3, Lcom/cyberzone/newAdmin/MainActivity;->valueEventListener:Lcom/google/firebase/database/ValueEventListener;

    .line 28
    .line 29
    if-eqz v2, :cond_2

    .line 30
    .line 31
    invoke-virtual {v0, v2}, Lcom/google/firebase/database/Query;->removeEventListener(Lcom/google/firebase/database/ValueEventListener;)V

    .line 32
    .line 33
    .line 34
    iput-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->valueEventListener:Lcom/google/firebase/database/ValueEventListener;

    .line 35
    .line 36
    :cond_2
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->database:Lcom/google/firebase/database/DatabaseReference;

    .line 37
    .line 38
    if-eqz v0, :cond_3

    .line 39
    .line 40
    iget-object v2, v3, Lcom/cyberzone/newAdmin/MainActivity;->newDeviceChildListener:Lcom/google/firebase/database/ChildEventListener;

    .line 41
    .line 42
    if-eqz v2, :cond_3

    .line 43
    .line 44
    invoke-virtual {v0, v2}, Lcom/google/firebase/database/Query;->removeEventListener(Lcom/google/firebase/database/ChildEventListener;)V

    .line 45
    .line 46
    .line 47
    iput-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->newDeviceChildListener:Lcom/google/firebase/database/ChildEventListener;

    .line 48
    .line 49
    :cond_3
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->favoritesRef:Lcom/google/firebase/database/DatabaseReference;

    .line 50
    .line 51
    if-eqz v0, :cond_4

    .line 52
    .line 53
    iget-object v2, v3, Lcom/cyberzone/newAdmin/MainActivity;->favoritesListener:Lcom/google/firebase/database/ValueEventListener;

    .line 54
    .line 55
    if-eqz v2, :cond_4

    .line 56
    .line 57
    invoke-virtual {v0, v2}, Lcom/google/firebase/database/Query;->removeEventListener(Lcom/google/firebase/database/ValueEventListener;)V

    .line 58
    .line 59
    .line 60
    iput-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->favoritesListener:Lcom/google/firebase/database/ValueEventListener;

    .line 61
    .line 62
    :cond_4
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->searchHandler:Landroid/os/Handler;

    .line 63
    .line 64
    if-eqz v0, :cond_5

    .line 65
    .line 66
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    iput-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->searchHandler:Landroid/os/Handler;

    .line 70
    .line 71
    :cond_5
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->uiHandler:Landroid/os/Handler;

    .line 72
    .line 73
    if-eqz v0, :cond_6

    .line 74
    .line 75
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    iput-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->uiHandler:Landroid/os/Handler;

    .line 79
    .line 80
    :cond_6
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->databaseUtil:Lcom/cyberzone/newAdmin/HttpDatabaseUtil;

    .line 81
    .line 82
    if-eqz v0, :cond_7

    .line 83
    .line 84
    invoke-virtual {v0}, Lcom/cyberzone/newAdmin/HttpDatabaseUtil;->shutdown()V

    .line 85
    .line 86
    .line 87
    iput-object v1, v3, Lcom/cyberzone/newAdmin/MainActivity;->databaseUtil:Lcom/cyberzone/newAdmin/HttpDatabaseUtil;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 88
    .line 89
    goto :goto_2

    .line 90
    :goto_1
    const-string v1, "ScKit-4d8219da144394a5a62018824ca9cc82"

    .line 91
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 92
    const-string v2, "ScKit-fed2c7b3544585935d7230d369a8881be1b1c6acb24f4e021845922418739cc7"

    .line 93
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 94
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 95
    .line 96
    .line 97
    :cond_7
    :goto_2
    invoke-super {v3}, Landroidx/appcompat/app/AppCompatActivity;->onDestroy()V

    .line 98
    .line 99
    .line 100
    return-void
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method

.method public onLowMemory()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    const-string v0, "ScKit-4d8219da144394a5a62018824ca9cc82"

    .line 2
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v0

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-super {v3}, Landroidx/fragment/app/FragmentActivity;->onLowMemory()V

    .line 4
    .line 5
    .line 6
    :try_start_0
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 7
    .line 8
    .line 9
    const-string v1, "ScKit-b9110d64a484323ca4d604b4721237f3e130b35714d1c1f7449630cd687ffff6"

    .line 10
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 11
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :catch_0
    move-exception v1

    .line 16
    const-string v2, "ScKit-57002185a2c0d29c44263fc04b39920864de8f13d85a943fd9cfb65b4b92e382"

    .line 17
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 18
    invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 19
    .line 20
    .line 21
    :goto_0
    return-void
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public onPause()V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-super {v0}, Landroidx/fragment/app/FragmentActivity;->onPause()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public onResume()V
    .locals 7

    move-object/from16 v3, p0

    .line 1
    invoke-super {v3}, Landroidx/fragment/app/FragmentActivity;->onResume()V

    .line 2
    .line 3
    .line 4
    :try_start_0
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->database:Lcom/google/firebase/database/DatabaseReference;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v0, v3, Lcom/cyberzone/newAdmin/MainActivity;->valueEventListener:Lcom/google/firebase/database/ValueEventListener;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    invoke-direct {v3}, Lcom/cyberzone/newAdmin/MainActivity;->initializeLogic()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :catch_0
    move-exception v0

    .line 17
    const-string v1, "ScKit-4d8219da144394a5a62018824ca9cc82"

    .line 18
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v1

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 19
    const-string v2, "ScKit-02eb00b0e3fd75ee4e1893640ac81a72e9074d1892b988f20780037b73d0291f"

    .line 20
    const-string v5, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v4, v2

    invoke-static/range {v4 .. v5}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 21
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 22
    .line 23
    .line 24
    :cond_0
    :goto_0
    return-void
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public onStop()V
    .locals 4

    move-object/from16 v0, p0

    .line 1
    invoke-super {v0}, Landroidx/appcompat/app/AppCompatActivity;->onStop()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public onTrimMemory(I)V
    .locals 11

    move-object/from16 v6, p0

    move/from16 v7, p1

    .line 1
    const-string v0, "ScKit-4d8219da144394a5a62018824ca9cc82"

    .line 2
    const-string v9, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v8, v0

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    const-string v1, "ScKit-144998c65b45e09cb8d6460da55bc4bb9a2c2955a04cdb720eaf6c16959c5773"

    .line 4
    const-string v9, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v8, v1

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-super {v6, v7}, Landroidx/activity/ComponentActivity;->onTrimMemory(I)V

    .line 6
    .line 7
    .line 8
    const/16 v2, 0x3c

    .line 9
    .line 10
    if-lt v7, v2, :cond_1

    .line 11
    .line 12
    :try_start_0
    iget-object v2, v6, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    const/16 v3, 0x64

    .line 19
    .line 20
    if-le v2, v3, :cond_0

    .line 21
    .line 22
    new-instance v2, Ljava/util/ArrayList;

    .line 23
    .line 24
    iget-object v4, v6, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 25
    .line 26
    const/4 v5, 0x0

    .line 27
    invoke-virtual {v4, v5, v3}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 32
    .line 33
    .line 34
    iput-object v2, v6, Lcom/cyberzone/newAdmin/MainActivity;->allDataList:Ljava/util/ArrayList;

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :catch_0
    move-exception v7

    .line 38
    goto :goto_1

    .line 39
    :cond_0
    :goto_0
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 40
    .line 41
    .line 42
    new-instance v2, Ljava/lang/StringBuilder;

    .line 43
    .line 44
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v7

    .line 54
    invoke-static {v0, v7}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 55
    .line 56
    .line 57
    goto :goto_2

    .line 58
    :goto_1
    const-string v1, "ScKit-bd678010e4e1d195d45ed926fe9251852ef0d49e55797c2fb2bdccec5c67dbf9"

    .line 59
    const-string v9, "ScKit-e3faabc0d3f73bfa"

    move-object/from16 v8, v1

    invoke-static/range {v8 .. v9}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 60
    invoke-static {v0, v1, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 61
    .line 62
    .line 63
    :cond_1
    :goto_2
    return-void
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
.end method

.method public showDeviceInfoDialog(Landroid/content/Context;Ljava/util/HashMap;)V
    .locals 29
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v23, p0

    move-object/from16 v24, p1

    move-object/from16 v25, p2

    .line 1
    move-object/from16 v0, v24

    .line 2
    .line 3
    move-object/from16 v1, v25

    .line 4
    .line 5
    new-instance v2, Landroid/widget/LinearLayout;

    .line 6
    .line 7
    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 8
    .line 9
    .line 10
    const/4 v3, 0x1

    .line 11
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 12
    .line 13
    .line 14
    const-string v4, "ScKit-20e4c56d8720881d8cd7527b92c1e116"

    .line 15
    const-string v27, "ScKit-50ea8063f2831658"

    move-object/from16 v26, v4

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 16
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 17
    .line 18
    .line 19
    move-result v4

    .line 20
    invoke-virtual {v2, v4}, Landroid/view/View;->setBackgroundColor(I)V

    .line 21
    .line 22
    .line 23
    new-instance v4, Landroid/widget/LinearLayout;

    .line 24
    .line 25
    invoke-direct {v4, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 26
    .line 27
    .line 28
    const-string v5, "ScKit-285a247073e4eb21cb59d38507beaecc"

    .line 29
    const-string v27, "ScKit-50ea8063f2831658"

    move-object/from16 v26, v5

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 30
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    invoke-virtual {v4, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 35
    .line 36
    .line 37
    const/16 v5, 0x18

    .line 38
    .line 39
    const/16 v6, 0x14

    .line 40
    .line 41
    invoke-virtual {v4, v5, v6, v5, v6}, Landroid/view/View;->setPadding(IIII)V

    .line 42
    .line 43
    .line 44
    const/16 v7, 0x10

    .line 45
    .line 46
    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 47
    .line 48
    .line 49
    new-instance v8, Landroid/widget/TextView;

    .line 50
    .line 51
    invoke-direct {v8, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 52
    .line 53
    .line 54
    const-string v9, "ScKit-d54ef78211fa72d80e9380accf99fadf49ff2cd7dba8266b3747433eec3441af"

    .line 55
    const-string v27, "ScKit-50ea8063f2831658"

    move-object/from16 v26, v9

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 56
    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 57
    .line 58
    .line 59
    const/high16 v9, 0x41880000    # 17.0f

    .line 60
    .line 61
    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 62
    .line 63
    .line 64
    const-string v9, "ScKit-aaadc0a047112b325de85e6d01103044"

    .line 65
    const-string v27, "ScKit-50ea8063f2831658"

    move-object/from16 v26, v9

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 66
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 67
    .line 68
    .line 69
    move-result v10

    .line 70
    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 71
    .line 72
    .line 73
    const/4 v10, 0x0

    .line 74
    invoke-virtual {v8, v10, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v4, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 81
    .line 82
    .line 83
    new-instance v4, Landroid/view/View;

    .line 84
    .line 85
    invoke-direct {v4, v0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 86
    .line 87
    .line 88
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 89
    .line 90
    const/4 v11, -0x1

    .line 91
    invoke-direct {v8, v11, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 92
    .line 93
    .line 94
    invoke-virtual {v4, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 95
    .line 96
    .line 97
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 98
    .line 99
    .line 100
    move-result v8

    .line 101
    invoke-virtual {v4, v8}, Landroid/view/View;->setBackgroundColor(I)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 105
    .line 106
    .line 107
    new-instance v4, Landroid/widget/LinearLayout;

    .line 108
    .line 109
    invoke-direct {v4, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 113
    .line 114
    .line 115
    const/16 v8, 0x8

    .line 116
    .line 117
    invoke-virtual {v4, v5, v7, v5, v8}, Landroid/view/View;->setPadding(IIII)V

    .line 118
    .line 119
    .line 120
    const-string v12, "ScKit-4c7b66f8626aa629b185137c94b445bd"

    .line 121
    const-string v27, "ScKit-50ea8063f2831658"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 122
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v13

    .line 126
    const-string v14, "ScKit-ca67aae17ee75f30fb839d90217226ab"

    .line 127
    const-string v27, "ScKit-50ea8063f2831658"

    move-object/from16 v26, v14

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 128
    if-eqz v13, :cond_0

    .line 129
    .line 130
    :goto_0
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v12

    .line 134
    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v12

    .line 138
    goto :goto_1

    .line 139
    :cond_0
    const-string v12, "ScKit-c8e467c8a7f4709040ffe8ece8cf3f78"

    .line 140
    const-string v27, "ScKit-50ea8063f2831658"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 141
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v13

    .line 145
    if-eqz v13, :cond_1

    .line 146
    .line 147
    goto :goto_0

    .line 148
    :cond_1
    move-object v12, v14

    .line 149
    :goto_1
    const-string v13, "ScKit-73bd1817d8c07fae84b671e2f080d454"

    .line 150
    const-string v27, "ScKit-50ea8063f2831658"

    move-object/from16 v26, v13

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 151
    filled-new-array {v13, v12}, [Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v15

    .line 155
    const-string v12, "ScKit-1719dd06971c4508853fae15b638e932"

    .line 156
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 157
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v13

    .line 161
    if-eqz v13, :cond_2

    .line 162
    .line 163
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v12

    .line 167
    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 168
    .line 169
    .line 170
    move-result-object v12

    .line 171
    goto :goto_2

    .line 172
    :cond_2
    move-object v12, v14

    .line 173
    :goto_2
    const-string v13, "ScKit-9fd8c1128a83a624989eccc71365d913"

    .line 174
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v13

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 175
    filled-new-array {v13, v12}, [Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v16

    .line 179
    const-string v12, "ScKit-784ab578135d7934feca7efca87002c1"

    .line 180
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 181
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v13

    .line 185
    if-eqz v13, :cond_3

    .line 186
    .line 187
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v12

    .line 191
    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v12

    .line 195
    goto :goto_3

    .line 196
    :cond_3
    move-object v12, v14

    .line 197
    :goto_3
    const-string v13, "ScKit-f592e79ed2a733bfbd874110d3e6154f"

    .line 198
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v13

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 199
    filled-new-array {v13, v12}, [Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object v17

    .line 203
    const-string v12, "ScKit-44393d31009a85f6ffc263786051da80"

    .line 204
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 205
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v13

    .line 209
    if-eqz v13, :cond_4

    .line 210
    .line 211
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    move-result-object v12

    .line 215
    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v12

    .line 219
    goto :goto_4

    .line 220
    :cond_4
    move-object v12, v14

    .line 221
    :goto_4
    const-string v13, "ScKit-dfb52358f37a6914d44f5e93c17bf0a8"

    .line 222
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v13

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 223
    filled-new-array {v13, v12}, [Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object v18

    .line 227
    const-string v12, "ScKit-33a494e481933cfabf93acdee50c17e1"

    .line 228
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 229
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v13

    .line 233
    if-eqz v13, :cond_5

    .line 234
    .line 235
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v12

    .line 239
    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v12

    .line 243
    goto :goto_5

    .line 244
    :cond_5
    move-object v12, v14

    .line 245
    :goto_5
    const-string v13, "ScKit-3f045becea96d7560e5ecde91c08b699"

    .line 246
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v13

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 247
    filled-new-array {v13, v12}, [Ljava/lang/String;

    .line 248
    .line 249
    .line 250
    move-result-object v19

    .line 251
    const-string v12, "ScKit-fa0070571676136692149b9274959553"

    .line 252
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 253
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v13

    .line 257
    if-eqz v13, :cond_6

    .line 258
    .line 259
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v12

    .line 263
    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 264
    .line 265
    .line 266
    move-result-object v12

    .line 267
    goto :goto_6

    .line 268
    :cond_6
    move-object v12, v14

    .line 269
    :goto_6
    const-string v13, "ScKit-ee525c579d12b6daf7c60f21b1e74722"

    .line 270
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v13

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 271
    filled-new-array {v13, v12}, [Ljava/lang/String;

    .line 272
    .line 273
    .line 274
    move-result-object v20

    .line 275
    const-string v12, "ScKit-d5d60a65d076b97a8604b1d634b8b0f0"

    .line 276
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 277
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 278
    .line 279
    .line 280
    move-result-object v13

    .line 281
    if-eqz v13, :cond_7

    .line 282
    .line 283
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object v12

    .line 287
    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 288
    .line 289
    .line 290
    move-result-object v12

    .line 291
    goto :goto_7

    .line 292
    :cond_7
    move-object v12, v14

    .line 293
    :goto_7
    const-string v13, "ScKit-f04587a2eb16bb233990bd456771a3ff"

    .line 294
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v13

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 295
    filled-new-array {v13, v12}, [Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object v21

    .line 299
    const-string v12, "ScKit-599d55f2b7ff24c3efbb482997e7c111"

    .line 300
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v12

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 301
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object v13

    .line 305
    if-eqz v13, :cond_8

    .line 306
    .line 307
    invoke-virtual {v1, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 308
    .line 309
    .line 310
    move-result-object v1

    .line 311
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 312
    .line 313
    .line 314
    move-result-object v14

    .line 315
    :cond_8
    const-string v1, "ScKit-8020580d1356cfd1448078cc70bf6a82"

    .line 316
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v1

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 317
    filled-new-array {v1, v14}, [Ljava/lang/String;

    .line 318
    .line 319
    .line 320
    move-result-object v22

    .line 321
    filled-new-array/range {v15 .. v22}, [[Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object v1

    .line 325
    new-array v12, v3, [Landroid/app/AlertDialog;

    .line 326
    .line 327
    const/4 v13, 0x0

    .line 328
    move v14, v13

    .line 329
    :goto_8
    const-string v16, "ScKit-103139dc308f81a96e045241fc7ce1d6"

    .line 330
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v16

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    .line 331
    const/4 v6, -0x2

    .line 332
    if-ge v14, v8, :cond_9

    .line 333
    .line 334
    aget-object v19, v1, v14

    .line 335
    .line 336
    aget-object v8, v19, v13

    .line 337
    .line 338
    aget-object v10, v19, v3

    .line 339
    .line 340
    new-instance v5, Landroid/widget/LinearLayout;

    .line 341
    .line 342
    invoke-direct {v5, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 343
    .line 344
    .line 345
    invoke-virtual {v5, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 346
    .line 347
    .line 348
    const/16 v15, 0xc

    .line 349
    .line 350
    invoke-virtual {v5, v7, v15, v7, v15}, Landroid/view/View;->setPadding(IIII)V

    .line 351
    .line 352
    .line 353
    invoke-virtual {v5, v3}, Landroid/view/View;->setClickable(Z)V

    .line 354
    .line 355
    .line 356
    new-instance v15, Landroid/graphics/drawable/GradientDrawable;

    .line 357
    .line 358
    invoke-direct {v15}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 359
    .line 360
    .line 361
    const-string v22, "ScKit-565ffaed617ec8a09eb172bd2fd3a31f"

    .line 362
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v22

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    .line 363
    invoke-static/range {v22 .. v22}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 364
    .line 365
    .line 366
    move-result v7

    .line 367
    invoke-virtual {v15, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 368
    .line 369
    .line 370
    const/high16 v7, 0x41400000    # 12.0f

    .line 371
    .line 372
    invoke-virtual {v15, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 373
    .line 374
    .line 375
    invoke-virtual {v5, v15}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 376
    .line 377
    .line 378
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 379
    .line 380
    invoke-direct {v7, v11, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 381
    .line 382
    .line 383
    const/16 v6, 0xa

    .line 384
    .line 385
    invoke-virtual {v7, v13, v13, v13, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 386
    .line 387
    .line 388
    invoke-virtual {v5, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 389
    .line 390
    .line 391
    new-instance v6, Landroid/widget/TextView;

    .line 392
    .line 393
    invoke-direct {v6, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 394
    .line 395
    .line 396
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 397
    .line 398
    .line 399
    const/high16 v7, 0x41300000    # 11.0f

    .line 400
    .line 401
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 402
    .line 403
    .line 404
    invoke-static/range {v16 .. v16}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 405
    .line 406
    .line 407
    move-result v7

    .line 408
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 409
    .line 410
    .line 411
    const/4 v7, 0x4

    .line 412
    invoke-virtual {v6, v13, v13, v13, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 413
    .line 414
    .line 415
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 416
    .line 417
    .line 418
    new-instance v6, Landroid/widget/TextView;

    .line 419
    .line 420
    invoke-direct {v6, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 421
    .line 422
    .line 423
    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 424
    .line 425
    .line 426
    const/high16 v7, 0x41600000    # 14.0f

    .line 427
    .line 428
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 429
    .line 430
    .line 431
    const-string v7, "ScKit-740b174e971d08e658f111f465bae7a3"

    .line 432
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v7

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 433
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 434
    .line 435
    .line 436
    move-result v7

    .line 437
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 438
    .line 439
    .line 440
    const/4 v7, 0x0

    .line 441
    invoke-virtual {v6, v7, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 442
    .line 443
    .line 444
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 445
    .line 446
    .line 447
    new-instance v6, Lo/Kd;

    .line 448
    .line 449
    move-object/from16 v7, v23

    .line 450
    .line 451
    invoke-direct {v6, v7, v0, v10, v8}, Lo/Kd;-><init>(Lcom/cyberzone/newAdmin/MainActivity;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 452
    .line 453
    .line 454
    invoke-virtual {v5, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 455
    .line 456
    .line 457
    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 458
    .line 459
    .line 460
    add-int/lit8 v14, v14, 0x1

    .line 461
    .line 462
    const/16 v5, 0x18

    .line 463
    .line 464
    const/16 v6, 0x14

    .line 465
    .line 466
    const/16 v7, 0x10

    .line 467
    .line 468
    const/16 v8, 0x8

    .line 469
    .line 470
    const/4 v10, 0x0

    .line 471
    goto/16 :goto_8

    .line 472
    .line 473
    :cond_9
    move-object/from16 v7, v23

    .line 474
    .line 475
    invoke-virtual {v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 476
    .line 477
    .line 478
    new-instance v1, Landroid/widget/LinearLayout;

    .line 479
    .line 480
    invoke-direct {v1, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 481
    .line 482
    .line 483
    invoke-virtual {v1, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 484
    .line 485
    .line 486
    const/16 v4, 0x18

    .line 487
    .line 488
    const/16 v5, 0x14

    .line 489
    .line 490
    const/4 v8, 0x4

    .line 491
    invoke-virtual {v1, v4, v8, v4, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 492
    .line 493
    .line 494
    const/16 v4, 0x11

    .line 495
    .line 496
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 497
    .line 498
    .line 499
    new-instance v4, Landroid/widget/Button;

    .line 500
    .line 501
    invoke-direct {v4, v0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 502
    .line 503
    .line 504
    const-string v5, "ScKit-cc50adee6552b144931da6a0c67a430e"

    .line 505
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v5

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 506
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 507
    .line 508
    .line 509
    invoke-static/range {v16 .. v16}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 510
    .line 511
    .line 512
    move-result v5

    .line 513
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 514
    .line 515
    .line 516
    invoke-virtual {v4, v13}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 517
    .line 518
    .line 519
    invoke-virtual {v4, v13}, Landroid/view/View;->setBackgroundColor(I)V

    .line 520
    .line 521
    .line 522
    const/high16 v5, 0x41600000    # 14.0f

    .line 523
    .line 524
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 525
    .line 526
    .line 527
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 528
    .line 529
    const/high16 v8, 0x3f800000    # 1.0f

    .line 530
    .line 531
    invoke-direct {v5, v13, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 532
    .line 533
    .line 534
    const/16 v10, 0x8

    .line 535
    .line 536
    invoke-virtual {v5, v13, v13, v10, v13}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 537
    .line 538
    .line 539
    invoke-virtual {v4, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 540
    .line 541
    .line 542
    new-instance v5, Lo/Ld;

    .line 543
    .line 544
    const/4 v10, 0x0

    .line 545
    invoke-direct {v5, v12, v10}, Lo/Ld;-><init>([Landroid/app/AlertDialog;I)V

    .line 546
    .line 547
    .line 548
    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 549
    .line 550
    .line 551
    new-instance v5, Landroid/widget/Button;

    .line 552
    .line 553
    invoke-direct {v5, v0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 554
    .line 555
    .line 556
    const-string v10, "ScKit-599e077e63206cb03062947e9f4b8171"

    .line 557
    const-string v27, "ScKit-e3f33ad4342eabde"

    move-object/from16 v26, v10

    invoke-static/range {v26 .. v27}, Lʾʾᵔᴵᵢﹶ/ˎـʼﾞʻˑ/ˆʽᵔﾞʼˏ/ˆᐧˆˉˏـ/ʾˉˏʽﹶﹳ/יʽיⁱˈי/ᵔⁱᐧʻᵔﹶ;->ᐧˋᴵʾᵔʿˈᵢﾞˎʻﹶᴵٴʻʾʾʻʽˈ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 558
    invoke-virtual {v5, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 559
    .line 560
    .line 561
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 562
    .line 563
    .line 564
    move-result v9

    .line 565
    invoke-virtual {v5, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 566
    .line 567
    .line 568
    invoke-virtual {v5, v13}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 569
    .line 570
    .line 571
    invoke-virtual {v5, v13}, Landroid/view/View;->setBackgroundColor(I)V

    .line 572
    .line 573
    .line 574
    const/high16 v9, 0x41600000    # 14.0f

    .line 575
    .line 576
    invoke-virtual {v5, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 577
    .line 578
    .line 579
    const/4 v9, 0x0

    .line 580
    invoke-virtual {v5, v9, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 581
    .line 582
    .line 583
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    .line 584
    .line 585
    invoke-direct {v9, v13, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 586
    .line 587
    .line 588
    const/16 v6, 0x8

    .line 589
    .line 590
    invoke-virtual {v9, v6, v13, v13, v13}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 591
    .line 592
    .line 593
    invoke-virtual {v5, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 594
    .line 595
    .line 596
    new-instance v6, Lo/Ld;

    .line 597
    .line 598
    const/4 v8, 0x1

    .line 599
    invoke-direct {v6, v12, v8}, Lo/Ld;-><init>([Landroid/app/AlertDialog;I)V

    .line 600
    .line 601
    .line 602
    invoke-virtual {v5, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 603
    .line 604
    .line 605
    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 606
    .line 607
    .line 608
    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 609
    .line 610
    .line 611
    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 612
    .line 613
    .line 614
    new-instance v1, Landroid/app/AlertDialog$Builder;

    .line 615
    .line 616
    invoke-direct {v1, v0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 617
    .line 618
    .line 619
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 620
    .line 621
    .line 622
    move-result-object v0

    .line 623
    invoke-virtual {v0, v3}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 624
    .line 625
    .line 626
    move-result-object v0

    .line 627
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    .line 628
    .line 629
    .line 630
    move-result-object v0

    .line 631
    aput-object v0, v12, v13

    .line 632
    .line 633
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 634
    .line 635
    .line 636
    move-result-object v1

    .line 637
    if-eqz v1, :cond_a

    .line 638
    .line 639
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 640
    .line 641
    .line 642
    move-result-object v1

    .line 643
    const v2, 0x106000d

    .line 644
    .line 645
    .line 646
    invoke-virtual {v1, v2}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 647
    .line 648
    .line 649
    :cond_a
    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    .line 650
    .line 651
    .line 652
    return-void
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
.end method
