.class public Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$OnSpeedChangeListener;
    }
.end annotation


# instance fields
.field private handler:Landroid/os/Handler;

.field private listener:Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$OnSpeedChangeListener;

.field private previousRxBytes:J

.field private previousTime:J

.field private previousTxBytes:J

.field private speedChecker:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-wide/16 v0, 0x0

    .line 5
    .line 6
    iput-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousRxBytes:J

    .line 7
    .line 8
    iput-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousTxBytes:J

    .line 9
    .line 10
    iput-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousTime:J

    .line 11
    .line 12
    new-instance v0, Landroid/os/Handler;

    .line 13
    .line 14
    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->handler:Landroid/os/Handler;

    .line 18
    .line 19
    new-instance v0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$1;

    .line 20
    .line 21
    invoke-direct {v0, p0}, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$1;-><init>(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;)V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->speedChecker:Ljava/lang/Runnable;

    .line 25
    .line 26
    return-void
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public static bridge synthetic a(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;)Landroid/os/Handler;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->handler:Landroid/os/Handler;

    return-object p0
.end method

.method public static bridge synthetic b(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;)Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$OnSpeedChangeListener;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->listener:Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$OnSpeedChangeListener;

    return-object p0
.end method

.method public static bridge synthetic c(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousRxBytes:J

    return-wide v0
.end method

.method public static bridge synthetic d(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousTime:J

    return-wide v0
.end method

.method public static bridge synthetic e(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousTxBytes:J

    return-wide v0
.end method

.method public static bridge synthetic f(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousRxBytes:J

    return-void
.end method

.method public static bridge synthetic g(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousTime:J

    return-void
.end method

.method public static bridge synthetic h(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousTxBytes:J

    return-void
.end method


# virtual methods
.method public setSpeedListener(Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$OnSpeedChangeListener;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->listener:Lcom/cyberzone/newAdmin/NetworkSpeedMonitor$OnSpeedChangeListener;

    .line 2
    .line 3
    return-void
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public startMonitoring()V
    .locals 2

    .line 1
    invoke-static {}, Landroid/net/TrafficStats;->getTotalRxBytes()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    iput-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousRxBytes:J

    .line 6
    .line 7
    invoke-static {}, Landroid/net/TrafficStats;->getTotalTxBytes()J

    .line 8
    .line 9
    .line 10
    move-result-wide v0

    .line 11
    iput-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousTxBytes:J

    .line 12
    .line 13
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 14
    .line 15
    .line 16
    move-result-wide v0

    .line 17
    iput-wide v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->previousTime:J

    .line 18
    .line 19
    iget-object v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->handler:Landroid/os/Handler;

    .line 20
    .line 21
    iget-object v1, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->speedChecker:Ljava/lang/Runnable;

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 24
    .line 25
    .line 26
    return-void
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public stopMonitoring()V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->handler:Landroid/os/Handler;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v1, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->speedChecker:Ljava/lang/Runnable;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, Lcom/cyberzone/newAdmin/NetworkSpeedMonitor;->handler:Landroid/os/Handler;

    .line 12
    .line 13
    :cond_0
    return-void
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method
