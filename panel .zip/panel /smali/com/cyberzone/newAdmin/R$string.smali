.class public final Lcom/cyberzone/newAdmin/R$string;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static app_name:I = 0x7f10001c

.field public static firebase_database_url:I = 0x7f10003f

.field public static gcm_defaultSenderId:I = 0x7f100040

.field public static google_api_key:I = 0x7f100041

.field public static google_app_id:I = 0x7f100042

.field public static google_crash_reporting_api_key:I = 0x7f100043

.field public static google_storage_bucket:I = 0x7f100044

.field public static project_id:I = 0x7f1000b1


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
