.class public Lcom/cyberzone/newAdmin/GenInfo;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
.end method

.method public static generateIP()Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Ljava/util/Random;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Ljava/lang/StringBuilder;

    .line 7
    .line 8
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 9
    .line 10
    .line 11
    const/16 v2, 0x100

    .line 12
    .line 13
    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    const-string v3, "."

    .line 21
    .line 22
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    .line 26
    .line 27
    .line 28
    move-result v4

    .line 29
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    return-object v0
    .line 57
    .line 58
    .line 59
.end method

.method public static generateUniqueUserAgent()Ljava/lang/String;
    .locals 27

    .line 1
    const-string v17, "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Samsung Internet/14.0 Safari/537.36"

    .line 2
    .line 3
    const-string v18, "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) QQBrowser/10.8.4244.400 Safari/537.36"

    .line 4
    .line 5
    const-string v0, "Chrome/91.0.4472.124 Safari/537.36"

    .line 6
    .line 7
    const-string v1, "Firefox/89.0 Safari/537.36"

    .line 8
    .line 9
    const-string v2, "Edge/91.0.864.64 Safari/537.36"

    .line 10
    .line 11
    const-string v3, "Opera/77.0.4054.64 Safari/537.36"

    .line 12
    .line 13
    const-string v4, "Safari/537.36"

    .line 14
    .line 15
    const-string v5, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

    .line 16
    .line 17
    const-string v6, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Gecko/20100101 Firefox/89.0"

    .line 18
    .line 19
    const-string v7, "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0"

    .line 20
    .line 21
    const-string v8, "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"

    .line 22
    .line 23
    const-string v9, "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/91.0.864.64 Safari/537.36"

    .line 24
    .line 25
    const-string v10, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Opera/77.0.4054.64 Safari/537.36"

    .line 26
    .line 27
    const-string v11, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/85.0.4183.121 Safari/537.36"

    .line 28
    .line 29
    const-string v12, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/82.0 Safari/537.36"

    .line 30
    .line 31
    const-string v13, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Brave/1.14.82 Safari/537.36"

    .line 32
    .line 33
    const-string v14, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Vivaldi/3.5.2115.81 Safari/537.36"

    .line 34
    .line 35
    const-string v15, "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/92.0.902.62 Safari/537.36"

    .line 36
    .line 37
    const-string v16, "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chromium/93.0.4577.82 Safari/537.36"

    .line 38
    .line 39
    filled-new-array/range {v0 .. v18}, [Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    const-string v25, "Windows NT 6.2; Win64; x64"

    .line 44
    .line 45
    const-string v26, "iPhone; CPU iPhone OS 13_2 like Mac OS X"

    .line 46
    .line 47
    const-string v1, "Windows NT 10.0; Win64; x64"

    .line 48
    .line 49
    const-string v2, "Macintosh; Intel Mac OS X 10_15_7"

    .line 50
    .line 51
    const-string v3, "Linux; Android 11; Pixel 4"

    .line 52
    .line 53
    const-string v4, "iPhone; CPU iPhone OS 14_4 like Mac OS X"

    .line 54
    .line 55
    const-string v5, "Windows NT 6.1; WOW64"

    .line 56
    .line 57
    const-string v6, "Android 10; Pixel 2"

    .line 58
    .line 59
    const-string v7, "Linux x86_64"

    .line 60
    .line 61
    const-string v8, "Macintosh; Intel Mac OS X 10_14_6"

    .line 62
    .line 63
    const-string v9, "Windows NT 5.1; WinXP"

    .line 64
    .line 65
    const-string v10, "Linux; Ubuntu 20.04"

    .line 66
    .line 67
    const-string v11, "Linux; Android 12; OnePlus 9 Pro"

    .line 68
    .line 69
    const-string v12, "iPhone; CPU iPhone OS 13_3 like Mac OS X"

    .line 70
    .line 71
    const-string v13, "Macintosh; Intel Mac OS X 11_0_1"

    .line 72
    .line 73
    const-string v14, "Windows NT 6.3; Win64; x64"

    .line 74
    .line 75
    const-string v15, "Android 9; Pixel 3"

    .line 76
    .line 77
    const-string v16, "Windows NT 10.0; ARM64"

    .line 78
    .line 79
    const-string v17, "iPad; CPU iPad OS 15_2 like Mac OS X"

    .line 80
    .line 81
    const-string v18, "Linux; Android 9; Samsung Galaxy S10"

    .line 82
    .line 83
    const-string v19, "Macintosh; Intel Mac OS X 10_13_6"

    .line 84
    .line 85
    const-string v20, "Linux; Android 10; Samsung Galaxy Note 9"

    .line 86
    .line 87
    const-string v21, "iPhone; CPU iPhone OS 15_0 like Mac OS X"

    .line 88
    .line 89
    const-string v22, "Macintosh; Intel Mac OS X 10_12_6"

    .line 90
    .line 91
    const-string v23, "Windows NT 10.0; Win32"

    .line 92
    .line 93
    const-string v24, "Linux; Fedora 32"

    .line 94
    .line 95
    filled-new-array/range {v1 .. v26}, [Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    const-string v14, "Streaming Box"

    .line 100
    .line 101
    const-string v15, "Game Console"

    .line 102
    .line 103
    const-string v2, "Mobile"

    .line 104
    .line 105
    const-string v3, "Tablet"

    .line 106
    .line 107
    const-string v4, "Desktop"

    .line 108
    .line 109
    const-string v5, "SmartTV"

    .line 110
    .line 111
    const-string v6, "Console"

    .line 112
    .line 113
    const-string v7, "Headset"

    .line 114
    .line 115
    const-string v8, "Smartwatch"

    .line 116
    .line 117
    const-string v9, "Car"

    .line 118
    .line 119
    const-string v10, "Smart Display"

    .line 120
    .line 121
    const-string v11, "Laptop"

    .line 122
    .line 123
    const-string v12, "VR Headset"

    .line 124
    .line 125
    const-string v13, "Ebook Reader"

    .line 126
    .line 127
    filled-new-array/range {v2 .. v15}, [Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v2

    .line 131
    new-instance v3, Ljava/util/Random;

    .line 132
    .line 133
    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    .line 134
    .line 135
    .line 136
    const/16 v4, 0x13

    .line 137
    .line 138
    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    .line 139
    .line 140
    .line 141
    move-result v4

    .line 142
    aget-object v0, v0, v4

    .line 143
    .line 144
    const/16 v4, 0x1a

    .line 145
    .line 146
    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    .line 147
    .line 148
    .line 149
    move-result v4

    .line 150
    aget-object v1, v1, v4

    .line 151
    .line 152
    const/16 v4, 0xe

    .line 153
    .line 154
    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    .line 155
    .line 156
    .line 157
    move-result v3

    .line 158
    aget-object v2, v2, v3

    .line 159
    .line 160
    new-instance v3, Ljava/lang/StringBuilder;

    .line 161
    .line 162
    const-string v4, "Mozilla/5.0 ("

    .line 163
    .line 164
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 168
    .line 169
    .line 170
    const-string v1, ") AppleWebKit/537.36 (KHTML, like Gecko) "

    .line 171
    .line 172
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 176
    .line 177
    .line 178
    const-string v0, " "

    .line 179
    .line 180
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    const-string v1, " ;"

    .line 191
    .line 192
    const-string v2, ";"

    .line 193
    .line 194
    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object v0

    .line 198
    const-string v1, " ,"

    .line 199
    .line 200
    const-string v2, ","

    .line 201
    .line 202
    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    return-object v0
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
.end method
