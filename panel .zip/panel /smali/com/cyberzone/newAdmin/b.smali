.class public final synthetic Lcom/cyberzone/newAdmin/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/cyberzone/newAdmin/AppSpreadActivity$1;

.field public final synthetic b:I

.field public final synthetic c:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final synthetic d:I

.field public final synthetic e:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method public synthetic constructor <init>(Lcom/cyberzone/newAdmin/AppSpreadActivity$1;ILjava/util/concurrent/atomic/AtomicInteger;ILjava/util/concurrent/atomic/AtomicInteger;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/cyberzone/newAdmin/b;->a:Lcom/cyberzone/newAdmin/AppSpreadActivity$1;

    iput p2, p0, Lcom/cyberzone/newAdmin/b;->b:I

    iput-object p3, p0, Lcom/cyberzone/newAdmin/b;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    iput p4, p0, Lcom/cyberzone/newAdmin/b;->d:I

    iput-object p5, p0, Lcom/cyberzone/newAdmin/b;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    iget v0, p0, Lcom/cyberzone/newAdmin/b;->b:I

    iget-object v1, p0, Lcom/cyberzone/newAdmin/b;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    iget-object v2, p0, Lcom/cyberzone/newAdmin/b;->a:Lcom/cyberzone/newAdmin/AppSpreadActivity$1;

    iget v3, p0, Lcom/cyberzone/newAdmin/b;->d:I

    iget-object v4, p0, Lcom/cyberzone/newAdmin/b;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-static {v2, v0, v1, v3, v4}, Lcom/cyberzone/newAdmin/AppSpreadActivity$1;->b(Lcom/cyberzone/newAdmin/AppSpreadActivity$1;ILjava/util/concurrent/atomic/AtomicInteger;ILjava/util/concurrent/atomic/AtomicInteger;)V

    return-void
.end method
