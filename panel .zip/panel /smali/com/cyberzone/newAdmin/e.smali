.class public final synthetic Lcom/cyberzone/newAdmin/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, Lcom/cyberzone/newAdmin/e;->a:I

    iput-object p1, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    iput-object p3, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget v0, p0, Lcom/cyberzone/newAdmin/e;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v1, Lcom/cyberzone/newAdmin/MainActivity$4;

    invoke-static {v1, v0}, Lcom/cyberzone/newAdmin/MainActivity$4;->d(Lcom/cyberzone/newAdmin/MainActivity$4;Ljava/util/ArrayList;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v0, Lcom/cyberzone/newAdmin/MainActivity$4;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/firebase/database/DataSnapshot;

    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity$4;->a(Lcom/cyberzone/newAdmin/MainActivity$4;Lcom/google/firebase/database/DataSnapshot;)V

    return-void

    :pswitch_1
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v0, Lcom/cyberzone/newAdmin/MainActivity$4;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/firebase/database/DatabaseError;

    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity$4;->c(Lcom/cyberzone/newAdmin/MainActivity$4;Lcom/google/firebase/database/DatabaseError;)V

    return-void

    :pswitch_2
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v0, Lcom/cyberzone/newAdmin/MainActivity$1;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Throwable;

    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/MainActivity$1;->a(Lcom/cyberzone/newAdmin/MainActivity$1;Ljava/lang/Throwable;)V

    return-void

    :pswitch_3
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v1, Lcom/cyberzone/newAdmin/ForwardingActivity$3;

    invoke-static {v1, v0}, Lcom/cyberzone/newAdmin/ForwardingActivity$3;->a(Lcom/cyberzone/newAdmin/ForwardingActivity$3;Ljava/lang/Object;)V

    return-void

    :pswitch_4
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v1, Lcom/cyberzone/newAdmin/ForwardingActivity$2;

    invoke-static {v1, v0}, Lcom/cyberzone/newAdmin/ForwardingActivity$2;->b(Lcom/cyberzone/newAdmin/ForwardingActivity$2;Ljava/lang/String;)V

    return-void

    :pswitch_5
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v1, Lcom/cyberzone/newAdmin/ForwardingActivity$1;

    invoke-static {v1, v0}, Lcom/cyberzone/newAdmin/ForwardingActivity$1;->a(Lcom/cyberzone/newAdmin/ForwardingActivity$1;Ljava/lang/String;)V

    return-void

    :pswitch_6
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v0, Lcom/cyberzone/newAdmin/DetailsActivity$15;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/firebase/database/DataSnapshot;

    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/DetailsActivity$15;->b(Lcom/cyberzone/newAdmin/DetailsActivity$15;Lcom/google/firebase/database/DataSnapshot;)V

    return-void

    :pswitch_7
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v1, Lcom/cyberzone/newAdmin/DetailsActivity$15;

    invoke-static {v1, v0}, Lcom/cyberzone/newAdmin/DetailsActivity$15;->e(Lcom/cyberzone/newAdmin/DetailsActivity$15;Ljava/util/ArrayList;)V

    return-void

    :pswitch_8
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v0, Lcom/cyberzone/newAdmin/CardDetailsActivity$1;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/firebase/database/DataSnapshot;

    invoke-static {v0, v1}, Lcom/cyberzone/newAdmin/CardDetailsActivity$1;->c(Lcom/cyberzone/newAdmin/CardDetailsActivity$1;Lcom/google/firebase/database/DataSnapshot;)V

    return-void

    :pswitch_9
    iget-object v0, p0, Lcom/cyberzone/newAdmin/e;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/e;->b:Ljava/lang/Object;

    check-cast v1, Lcom/cyberzone/newAdmin/CardDetailsActivity$1;

    invoke-static {v1, v0}, Lcom/cyberzone/newAdmin/CardDetailsActivity$1;->b(Lcom/cyberzone/newAdmin/CardDetailsActivity$1;Ljava/util/ArrayList;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
