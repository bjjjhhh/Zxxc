.class public final synthetic Lcom/cyberzone/newAdmin/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/cyberzone/newAdmin/CardDetailsActivity$CardAdapter;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/cyberzone/newAdmin/CardDetailsActivity$CardAdapter;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/cyberzone/newAdmin/g;->a:Lcom/cyberzone/newAdmin/CardDetailsActivity$CardAdapter;

    iput-object p2, p0, Lcom/cyberzone/newAdmin/g;->b:Ljava/lang/String;

    iput-object p3, p0, Lcom/cyberzone/newAdmin/g;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/cyberzone/newAdmin/g;->c:Ljava/lang/String;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/g;->a:Lcom/cyberzone/newAdmin/CardDetailsActivity$CardAdapter;

    iget-object v2, p0, Lcom/cyberzone/newAdmin/g;->b:Ljava/lang/String;

    invoke-static {v1, v2, v0, p1}, Lcom/cyberzone/newAdmin/CardDetailsActivity$CardAdapter;->a(Lcom/cyberzone/newAdmin/CardDetailsActivity$CardAdapter;Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method
