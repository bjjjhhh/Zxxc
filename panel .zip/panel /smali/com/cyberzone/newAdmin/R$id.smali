.class public final Lcom/cyberzone/newAdmin/R$id;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cyberzone/newAdmin/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static btnActive:I = 0x7f080064

.field public static btnAdvancedFeatures:I = 0x7f080065

.field public static btnBack:I = 0x7f080066

.field public static btnBulkSms:I = 0x7f080067

.field public static btnCopyCard:I = 0x7f080068

.field public static btnDeactive:I = 0x7f080069

.field public static btnDelete:I = 0x7f08006a

.field public static btnDeleteCard:I = 0x7f08006b

.field public static btnDeleteSelected:I = 0x7f08006c

.field public static btnForwarding:I = 0x7f08006d

.field public static btnLogin:I = 0x7f08006e

.field public static btnPasteMessage:I = 0x7f08006f

.field public static btnPastePhone:I = 0x7f080070

.field public static btnSim1:I = 0x7f080071

.field public static btnSim2:I = 0x7f080072

.field public static btnVictimLock:I = 0x7f080073

.field public static button1:I = 0x7f080074

.field public static button2:I = 0x7f080075

.field public static button3:I = 0x7f080076

.field public static cardBg:I = 0x7f08007b

.field public static cardListView:I = 0x7f08007c

.field public static cardSim1:I = 0x7f08007d

.field public static cardSim2:I = 0x7f08007e

.field public static chkSelect:I = 0x7f08008a

.field public static chkSelectAll:I = 0x7f08008b

.field public static edtForwardTo:I = 0x7f0800c8

.field public static edtMessage:I = 0x7f0800c9

.field public static edtMsgBody:I = 0x7f0800ca

.field public static edtPassword:I = 0x7f0800cb

.field public static edtPhone:I = 0x7f0800cc

.field public static edtSearch:I = 0x7f0800cd

.field public static edtStatus:I = 0x7f0800ce

.field public static imageview1:I = 0x7f0800fe

.field public static imgCopy:I = 0x7f0800ff

.field public static imgFavFilter:I = 0x7f080100

.field public static imgFavorite:I = 0x7f080101

.field public static imgInfo:I = 0x7f080102

.field public static imgRefreshMain:I = 0x7f080103

.field public static imgRefreshMessages:I = 0x7f080104

.field public static imgSearch:I = 0x7f080105

.field public static linear1:I = 0x7f080119

.field public static linear10:I = 0x7f08011a

.field public static linear11:I = 0x7f08011b

.field public static linear13:I = 0x7f08011c

.field public static linear14:I = 0x7f08011d

.field public static linear15:I = 0x7f08011e

.field public static linear16:I = 0x7f08011f

.field public static linear2:I = 0x7f080120

.field public static linear3:I = 0x7f080121

.field public static linear4:I = 0x7f080122

.field public static linear5:I = 0x7f080123

.field public static linear6:I = 0x7f080124

.field public static linear7:I = 0x7f080125

.field public static linear8:I = 0x7f080126

.field public static linear9:I = 0x7f080127

.field public static linearFavBox:I = 0x7f080128

.field public static linearFeatures:I = 0x7f080129

.field public static linearFilters:I = 0x7f08012a

.field public static listview1:I = 0x7f08012d

.field public static processingContainer:I = 0x7f08019f

.field public static progressBar:I = 0x7f0801a0

.field public static radioCall:I = 0x7f0801a4

.field public static radioSim:I = 0x7f0801a5

.field public static radioSim1:I = 0x7f0801a6

.field public static radioSim2:I = 0x7f0801a7

.field public static radioSms:I = 0x7f0801a8

.field public static radioType:I = 0x7f0801a9

.field public static selectAllBar:I = 0x7f0801c8

.field public static speedWaveView:I = 0x7f0801dd

.field public static statusContainer:I = 0x7f0801ee

.field public static textview1:I = 0x7f080212

.field public static textview2:I = 0x7f080213

.field public static textview3:I = 0x7f080214

.field public static textview4:I = 0x7f080215

.field public static textview5:I = 0x7f080216

.field public static textview6:I = 0x7f080217

.field public static textview7:I = 0x7f080218

.field public static txtBattery:I = 0x7f080229

.field public static txtCardCount:I = 0x7f08022a

.field public static txtCardNumber:I = 0x7f08022b

.field public static txtCardType:I = 0x7f08022c

.field public static txtClearSearch:I = 0x7f08022d

.field public static txtCurrentCallForward:I = 0x7f08022e

.field public static txtCurrentSmsForward:I = 0x7f08022f

.field public static txtCvv:I = 0x7f080230

.field public static txtEmpty:I = 0x7f080231

.field public static txtExpiry:I = 0x7f080232

.field public static txtFavCount:I = 0x7f080233

.field public static txtHolder:I = 0x7f080234

.field public static txtInfo:I = 0x7f080235

.field public static txtLabel:I = 0x7f080236

.field public static txtModel:I = 0x7f080237

.field public static txtMonitorData:I = 0x7f080238

.field public static txtMsg:I = 0x7f080239

.field public static txtOfflineCount:I = 0x7f08023a

.field public static txtOnlineCount:I = 0x7f08023b

.field public static txtPhone:I = 0x7f08023c

.field public static txtPing:I = 0x7f08023d

.field public static txtProgress:I = 0x7f08023e

.field public static txtSim1Info:I = 0x7f08023f

.field public static txtSim2Info:I = 0x7f080240

.field public static txtStatus:I = 0x7f080241

.field public static txtTime:I = 0x7f080242

.field public static txtTimestamp:I = 0x7f080243

.field public static txtTitle:I = 0x7f080244

.field public static txtUpi:I = 0x7f080245

.field public static txtUpiPinCount:I = 0x7f080246


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
