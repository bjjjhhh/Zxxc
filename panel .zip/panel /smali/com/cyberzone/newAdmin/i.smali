.class public final synthetic Lcom/cyberzone/newAdmin/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, Lcom/cyberzone/newAdmin/i;->a:I

    iput-object p1, p0, Lcom/cyberzone/newAdmin/i;->b:Ljava/lang/Object;

    iput-object p3, p0, Lcom/cyberzone/newAdmin/i;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget v0, p0, Lcom/cyberzone/newAdmin/i;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lcom/cyberzone/newAdmin/i;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/i;->b:Ljava/lang/Object;

    check-cast v1, Lcom/cyberzone/newAdmin/DetailsActivity$14;

    invoke-static {v1, v0, p1}, Lcom/cyberzone/newAdmin/DetailsActivity$14;->b(Lcom/cyberzone/newAdmin/DetailsActivity$14;Ljava/lang/String;Landroid/view/View;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lcom/cyberzone/newAdmin/i;->c:Ljava/lang/Object;

    check-cast v0, Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/i;->b:Ljava/lang/Object;

    check-cast v1, Lcom/cyberzone/newAdmin/DetailsActivity;

    invoke-static {v1, v0, p1}, Lcom/cyberzone/newAdmin/DetailsActivity;->m(Lcom/cyberzone/newAdmin/DetailsActivity;Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;Landroid/view/View;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
