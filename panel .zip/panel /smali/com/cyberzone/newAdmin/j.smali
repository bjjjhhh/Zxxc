.class public final synthetic Lcom/cyberzone/newAdmin/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/cyberzone/newAdmin/DetailsActivity;

.field public final synthetic b:Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;


# direct methods
.method public synthetic constructor <init>(Lcom/cyberzone/newAdmin/DetailsActivity;Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/cyberzone/newAdmin/j;->a:Lcom/cyberzone/newAdmin/DetailsActivity;

    iput-object p2, p0, Lcom/cyberzone/newAdmin/j;->b:Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/cyberzone/newAdmin/j;->a:Lcom/cyberzone/newAdmin/DetailsActivity;

    iget-object v1, p0, Lcom/cyberzone/newAdmin/j;->b:Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;

    invoke-static {v0, v1, p1, p2}, Lcom/cyberzone/newAdmin/DetailsActivity;->t(Lcom/cyberzone/newAdmin/DetailsActivity;Lcom/cyberzone/newAdmin/DetailsActivity$BankBalanceInfo;Landroid/content/DialogInterface;I)V

    return-void
.end method
