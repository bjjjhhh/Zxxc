.class public final synthetic Lcom/cyberzone/newAdmin/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Lcom/cyberzone/newAdmin/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 1

    .line 1
    iget v0, p0, Lcom/cyberzone/newAdmin/d;->a:I

    check-cast p1, Ljava/util/HashMap;

    check-cast p2, Ljava/util/HashMap;

    packed-switch v0, :pswitch_data_0

    invoke-static {p1, p2}, Lcom/cyberzone/newAdmin/MainActivity$4;->b(Ljava/util/HashMap;Ljava/util/HashMap;)I

    move-result p1

    return p1

    :pswitch_0
    invoke-static {p1, p2}, Lcom/cyberzone/newAdmin/DetailsActivity$15;->a(Ljava/util/HashMap;Ljava/util/HashMap;)I

    move-result p1

    return p1

    :pswitch_1
    invoke-static {p1, p2}, Lcom/cyberzone/newAdmin/CardDetailsActivity$1;->a(Ljava/util/HashMap;Ljava/util/HashMap;)I

    move-result p1

    return p1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
