.class public final Landroidx/fragment/app/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/Of;


# instance fields
.field public final synthetic a:Landroidx/fragment/app/FragmentActivity;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/FragmentActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Landroidx/fragment/app/j;->a:Landroidx/fragment/app/FragmentActivity;

    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final a(Landroidx/activity/ComponentActivity;)V
    .locals 3

    .line 1
    iget-object p1, p0, Landroidx/fragment/app/j;->a:Landroidx/fragment/app/FragmentActivity;

    .line 2
    .line 3
    iget-object v0, p1, Landroidx/fragment/app/FragmentActivity;->mFragments:Lo/ha;

    .line 4
    .line 5
    iget-object v0, v0, Lo/ha;->a:Landroidx/fragment/app/k;

    .line 6
    .line 7
    iget-object v1, v0, Lo/ia;->d:Lo/qa;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-virtual {v1, v0, v0, v2}, Landroidx/fragment/app/o;->b(Lo/ia;Lo/ga;Landroidx/fragment/app/Fragment;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Landroidx/activity/ComponentActivity;->getSavedStateRegistry()Lo/ki;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const-string v1, "android:support:fragments"

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Lo/ki;->a(Ljava/lang/String;)Landroid/os/Bundle;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iget-object p1, p1, Landroidx/fragment/app/FragmentActivity;->mFragments:Lo/ha;

    .line 30
    .line 31
    iget-object p1, p1, Lo/ha;->a:Landroidx/fragment/app/k;

    .line 32
    .line 33
    iget-object p1, p1, Lo/ia;->d:Lo/qa;

    .line 34
    .line 35
    invoke-virtual {p1, v0}, Landroidx/fragment/app/o;->J(Landroid/os/Parcelable;)V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method
